<?php
class Template extends TemplateBase{
}
?>