<?php
RUN(normalizePath(\_::$DIRECTION));
?>