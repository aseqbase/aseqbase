	</head>
	<body>
	<?php /*"<body
		oncontextmenu="return false;" 
		unselectable="on"
		onselectstart="return false;" 
		onmousedown="return false;">*/ ?>
	<?php echo \_::$TEMPLATE->GetMain(); ?>