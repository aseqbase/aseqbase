<?php TEMPLATE("Message");
$mes = new \MiMFa\Template\Message();
$mes->WindowTitle = \_::$INFO->FullName;
$mes->WindowLogo = MiMFa\Library\Local::GetUrl(\_::$INFO->LogoPath);
$mes->SupTitle = \_::$INFO->Owner;
$mes->Title = \_::$INFO->Name;
$mes->SupDescription = "Forbidden 403";
$mes->Description = "You don't have permission to access on this server.";
$mes->Draw();
?>