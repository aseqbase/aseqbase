<style>
	.page-home {
		padding: 0px;
	}
</style>

<div class="page-home">
<?php
	//PART("slide-show");
    PART("about");
    PART("post-collection");
?>
</div>
