<div class="page page-pay">
	<?php PART("pay"); ?>
</div>