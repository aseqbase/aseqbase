<style>
	.page-home {
		padding: 10px 10px 50px;
	}
</style>

<div class="page page-service">
    <?php
	PART("small-header");
	PART("access");
	PART("service");
    ?>

</div>
