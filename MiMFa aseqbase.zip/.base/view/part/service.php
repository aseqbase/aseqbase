<?php
MODULE("RingSlide");
$module = new \MiMFa\Module\RingSlide();
$module->Image = \_::$INFO->FullLogoPath;
$module->Items = \_::$INFO->Services;
$module->Draw();
?>