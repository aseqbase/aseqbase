<?php
MiMFa\Library\HTML::$MaxDecimalPrecision = \_::$INFO->DecimalPrecision;
?>