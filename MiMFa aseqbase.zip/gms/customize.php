<?php
MiMFa\Library\HTML::$MaxDecimalPrecision = \_::$INFO->DecimalPrecision;
LIBRARY("Query");
MiMFa\Library\Query::$Sources[] = function($query){
    $qs = MiMFa\Library\Query::NormalizeForDataBaseSearch($query);
    yield from MiMFa\Library\DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."UserGroup","CONCAT('/units/',`Name`) AS 'Reference', `Title`, `Description`", "`Name` $qs OR `Title` $qs OR `Description`");
};
MiMFa\Library\Query::$Sources[] = function($query){
    $qs = MiMFa\Library\Query::NormalizeForDataBaseSearch($query);
    yield from MiMFa\Library\DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."User","CONCAT('/users/',`Signature`) AS 'Reference', `Name` AS 'Title', `Bio` AS 'Description', `Image`", "`Name` $qs OR `Bio` $qs OR `FirstName` $qs OR `LastName` $qs");
};
MiMFa\Library\Query::$Sources[] = function($query){
    $qs = MiMFa\Library\Query::NormalizeForDataBaseSearch($query);
    yield from MiMFa\Library\DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."Product","CONCAT('/products/',`Name`) AS 'Reference', `Title`, `Description`, `Image`", "`Name` $qs OR `Title` $qs OR `Description`");
};
MiMFa\Library\Query::$Sources[] = function($query){
    $qs = MiMFa\Library\Query::NormalizeForDataBaseSearch($query);
    yield from MiMFa\Library\DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."Tool","CONCAT('/tools/',`Name`) AS 'Reference', `Title`, `Description`, `Image`", "`Name` $qs OR `Title` $qs OR `Description`");
};
MiMFa\Library\Query::$Sources[] = function($query){
    $qs = MiMFa\Library\Query::NormalizeForDataBaseSearch($query);
    yield from MiMFa\Library\DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."Draft","CONCAT('/drafts/',`ID`) AS 'Reference', `Title`, `Description`, `Image`", "`Title` $qs OR `Description`");
};
?>