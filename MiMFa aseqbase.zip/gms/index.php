<?php //MiMFa aseqbase	http://aseqbase.ir
require_once(__DIR__."/initialize.php");
require_once($GLOBALS["BASE_DIR"]."index.php");
?>