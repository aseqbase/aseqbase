<?php
require_once(__DIR__."/initialize.php");
require_once($GLOBALS["BASE_DIR"]."public.php");
?>