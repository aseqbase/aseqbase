<?php
use \MiMFa\Library\HTML;
use \MiMFa\Library\Convert;
use \MiMFa\Library\User;
class Information extends InformationBase{
	public $Owner = "MiMFa";
	public $FullOwner = "Minimal Member Factory";
	public $Product = "GMS";
	public $FullProduct = "Goldsmith Management System";
	public $Name = "GMS";
	public $FullName = "MiMFa Goldsmith Management System";
	public $Slogan = "<u>A Special Goldsmith Management System";
	public $FullSlogan = "Develop websites by <u>a seq</u>uence-<u>base</u>d framework";
	public $Description = "A goldsmith management system, is special for an aseqbase website...";
	public $FullDescription = "A special framework for web development called \"aseqbase\" (a sequence-based framework) has been developed to implement safe, flexible, fast, and strong pure websites based on that, since 2018 so far.";

	public $Path = "https://aseqbase.ir";
	public $DownloadPath = null;
	public $Location = null;
	public $CountUnit = "n";
	public $WeightUnit = "g";
	public $WeightPrecision = 3;
	public $TimeUnit = "m";
	public $DecimalPrecision = 4;

	/**
     * The effective threshold for the numbers of product pieces in each draft
     * @var int
     */
	public $CountThreshold = 30;
	/**
     * The effective weight threshold of each piece in each draft
     * @var float
     */
	public $WeightThreshold = 100;
	/**
     * The effective times for each draft
     * @example 7200 minutes
     * @var int
     */
	public $TimeThreshold = 14400;

	/**
     * The effective factor to all unit coligues
     * @var float
     */
	public $UnitEffect = 0.1;

	public $WorkImpact = 0.10;
	public $SendImpact = 0.01;
	public $ReceiveImpact = 0.01;
	public $CompleteImpact = 0.01;
	public $AddImpact = 0.50;
	public $SubtractImpact = -0.50;
	public $SwarfImpact = -0.01;
	public $LoseImpact = -1;
	public $DamageImpact = 0;
	public $DamageByUnitImpact = -0.10;
	public $DamageByPersonImpact = -0.30;
	public $DamageByProductImpact = 0;
	public $DamageByToolImpact = -0.10;

	/**
     * Activate auto filling data in some fields
     * @var bool
     */
	public $AutoFill = false;
	public $TraceManagers = false;
	/**
     * Merge all similar in processing drafts
     * @var bool
     */
	public $MergeDrafts = true;

	public $DefaultFromTime = "today 00:00:00";
	public $DefaultToTime = "today 23:59:59";

	/**
     * @internal
     */
	public $MainMenus = array(
		array("Name"=>"HOME","Path"=>"/home","Image"=>"/file/symbol/home.png"),
		array("Name"=>"INBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?inbox", "Image"=>"/file/symbol/input.png"),
		array("Name"=>"CURRENTBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?currentbox", "Image"=>"/file/symbol/process.png"),
		array("Name"=>"OUTBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?outbox", "Image"=>"/file/symbol/output.png"),
		array("Name"=>"TRACE","Access"=>10,"Path"=>"/report/trace","Image"=>"/file/symbol/trace.png"),
		array("Name"=>"STATUS","Access"=>10,"Path"=>"/report/status","Image"=>"/file/symbol/status.png"),
		"Draft"=>array("Name"=>"DRAFT","Access"=>1000000,"Path"=>"/manage/drafts","Image"=>"/file/symbol/operation.png", "Items"=> array(
				array("Name"=>"INBOX","Access"=>1000000,"Path"=>"/manage/drafts?inbox", "Image"=>"/file/symbol/input.png"),
				array("Name"=>"CURRENTBOX","Access"=>1000000,"Path"=>"/manage/drafts?currentbox", "Image"=>"/file/symbol/process.png"),
				array("Name"=>"OUTBOX","Access"=>1000000,"Path"=>"/manage/drafts?outbox", "Image"=>"/file/symbol/output.png"),
				array("Name"=>"ADDBOX","Access"=>1000000,"Path"=>"/manage/drafts?addbox", "Image"=>"/file/symbol/greenflag.png"),
				array("Name"=>"SUBTRACTBOX","Access"=>1000000,"Path"=>"/manage/drafts?subtractbox", "Image"=>"/file/symbol/redflag.png"),
				array("Name"=>"FAILBOX","Access"=>1000000,"Path"=>"/manage/drafts?failbox", "Image"=>"/file/symbol/failure.png"),
				array("Name"=>"PARTIALBOX","Access"=>1000000,"Path"=>"/manage/drafts?partialbox&unit=HalfDones&status=Processing", "Image"=>"/file/symbol/partial-process.png"),
				array("Name"=>"COMPLETEBOX","Access"=>1000000,"Path"=>"/manage/drafts?completebox", "Image"=>"/file/symbol/tick.png")
		    )),
		"Edit"=>array("Name"=>"EDIT","Access"=>10,"Path"=>"/edit","Image"=>"/file/symbol/user.png", "Items"=> array(
		    	array("Name"=>"SYSTEM","Access"=>10,"Path"=>"/edit/system","Image"=>"/file/symbol/factory.png"),
		    	array("Name"=>"UNITS","Access"=>10,"Path"=>"/edit/units","Image"=>"/file/symbol/factory-unit.png"),
		    	array("Name"=>"PERSONNEL","Access"=>10,"Path"=>"/edit/users","Image"=>"/file/symbol/factory-worker.png"),
		    	array("Name"=>"PRODUCTS","Access"=>10,"Path"=>"/edit/products","Image"=>"/file/symbol/product.png"),
		    	array("Name"=>"TOOLS","Access"=>10,"Path"=>"/edit/tools","Image"=>"/file/symbol/tool.png"),
		    	array("Name"=>"DRAFTS","Access"=>10,"Path"=>"/edit/drafts","Image"=>"/file/symbol/operation.png")
		    )),
		"Report"=>array("Name"=>"REPORT","Access"=>10,"Path"=>"/report","Image"=>"/file/symbol/user.png", "Items"=> array(
		    	array("Name"=>"SYSTEM","Access"=>10,"Path"=>"/report/system","Image"=>"/file/symbol/factory.png"),
		    	array("Name"=>"UNITS","Access"=>10,"Path"=>"/report/units","Image"=>"/file/symbol/factory-unit.png"),
		    	array("Name"=>"USERS","Access"=>10,"Path"=>"/report/users","Image"=>"/file/symbol/factory-worker.png"),
		    	//array("Name"=>"PRODUCTS","Access"=>10,"Path"=>"/report/products","Image"=>"/file/symbol/product.png"),
		    	array("Name"=>"TOOLS","Access"=>10,"Path"=>"/report/tools","Image"=>"/file/symbol/tool.png"),
		    	array("Name"=>"DRAFTS","Access"=>10,"Path"=>"/report/drafts","Image"=>"/file/symbol/operation.png")
		    )),
		array("Name"=>"ABOUT","Path"=>"/about","Image"=>""),
		array("Name"=>"TUTORIAL","Path"=>"/tutorial","Image"=>"/file/symbol/chat.png")
		);

	/**
     * @internal
     */
	public $SideMenus = null;

	/**
     * @internal
     */
	public $Shortcuts = array(
		array("Name"=>"Menu","Path"=>"","Image"=>"/file/symbol/menu.png", "Attributes"=>"onclick='viewSideMenu()'"),
		array("Name"=>"Edit","Access"=>10,"Path"=>"/edit","Image"=>"/file/symbol/edit.png"),
		array("Name"=>"Inbox","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?inbox", "Image"=>"/file/symbol/input.png"),
		array("Name"=>"Dashboard","Path"=>"/sign/dashboard.php","Image"=>"/file/symbol/dashboard.png"),
		array("Name"=>"Outbox","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?outbox", "Image"=>"/file/symbol/output.png"),
		array("Name"=>"Report","Access"=>10,"Path"=>"/report","Image"=>"/file/symbol/analyze.png"),
		array("Name"=>"Trace","Access"=>10,"Path"=>"/report/trace", "Image"=>"/file/symbol/trace.png"),
		array("Name"=>"CurrentBox","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?currentbox", "Image"=>"/file/symbol/operation.png")
	);

	/**
     * @internal
     */
	public $Services = array(
		array("Name"=>"INBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?inbox", "Image"=>"/file/symbol/input.png"),
		array("Name"=>"OUTBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?outbox", "Image"=>"/file/symbol/output.png"),
		array("Name"=>"DRAFTS","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts","Image"=>"/file/symbol/operation.png"),
		array("Name"=>"TRACE","Access"=>10,"Path"=>"/report/trace","Image"=>"/file/symbol/trace.png"),
		array("Name"=>"STATUS","Access"=>10,"Path"=>"/report/status", "Image"=>"/file/symbol/status.png"),
		array("Name"=>"SYSTEM","Access"=>10,"Path"=>"/report/system","Image"=>"/file/symbol/factory.png"),
		array("Name"=>"UNITS","Access"=>10,"Path"=>"/report/units","Image"=>"/file/symbol/factory-unit.png"),
		array("Name"=>"PERSONNEL","Access"=>10,"Path"=>"/report/users","Image"=>"/file/symbol/factory-worker.png"),
		array("Name"=>"PRODUCTS","Access"=>10,"Path"=>"/report/products","Image"=>"/file/symbol/product.png"),
		array("Name"=>"TOOLS","Access"=>10,"Path"=>"/report/tools","Image"=>"/file/symbol/tool.png"),
		array("Name"=>"DRAFTS","Access"=>10,"Path"=>"/report/drafts","Image"=>"/file/symbol/operation.png")
	);

	/**
     * @internal
     */
	public $Contacts = array(
		array("Name"=>"Instagram","Path"=>"/?page=https://www.instagram.com/aseqbase","Icon"=> "fa fa-instagram"),
		array("Name"=>"Telegram","Path"=>"https://t.me/aseqbase","Icon"=> "fa fa-telegram"),
		array("Name"=>"Email","Path"=>"mailto:aseqbase@mimfa.net","Icon"=> "fa fa-envelope"),
		array("Name"=>"Github","Path"=>"http://github.com/aseqbase/ums","Icon"=> "fa fa-github"),
		array("Name"=>"Forum","Path"=>"/chat","Image"=>"/file/symbol/chat.png","Icon"=> "fa fa-comments")
	);

	/**
     * @internal
     */
	public $KeyWords = array("MiMFa","Minimal Member Factory", "UMS", "Unit Managment System", "Units Managment System");

	/**
     * @internal
     */
	public $Members = [];

	public function GetUnitValue($value, $key=null, $row=null, $column = "UnitName") { return isValid($row, $column)?HTML::Link($value, "/units/".$row[$column]):$value; }
	public function GetPersonValue($value, $key=null, $row=null, $column = "PersonName") {
		return isValid($row, $column)? HTML::Link($value, "/users/".$row[$column]):
			($column == "PersonName" && isValid($row, "Signature")? HTML::Link($value, "/users/".$row["Signature"]):$value);
    }
	public function GetPersonImage($value, $key=null, $row=null, $column = "Average", $borderSize = 5) {
        $id = "i_".getId(true);
		return $this->GetPersonValue(
			isValid($row, "Average")?
			(
				HTML::Media("", between($value, User::$DefaultImagePath), ["id"=>$id]).
				\_::$TEMPLATE->CreateScoreColorTemplate("#$id",borderSize:$borderSize, score:$row[$column])
			):$value
		, $key, $row);
    }
	public function GetProductValue($value, $key=null, $row=null, $column = "ProductName") { return isValid($row, $column)?HTML::Link($value, "/products/".$row[$column]):$value; }
	public function GetToolValue($value, $key=null, $row=null, $column = "ToolName") { return isValid($row, $column)?HTML::Link($value, "/tools/".$row[$column]):$value; }
	public function GetDraftValue($value, $key=null, $row=null, $column = "DraftName") { return isValid($row, $column)?HTML::Link($value, "/drafts/".$row[$column]):$value; }
	public function GetDraftFilterValue($value, $key=null, $row=null, $column = "DraftName", $req = "draft") {
		switch ($column)
        {
            case "UpdateTime":
            case "CreateTime":
				$value = \_::$CONFIG->ToShownFormattedDateTime($value);
				break;
        }

		return isValid($row, $column)?HTML::Link($value, "/manage/drafts?$req=".$row[$column].(isEmpty(\_::$QUERY)?"":"&".\_::$QUERY)):$value;
    }
	public function GetDraftStatus($count = null, $weight = null, $time = null, $status = "Processing") {
		if($weight == 0) return "Done";
		else return $status;
    }

	public function GetContradiction($count = 0, $weight = 0, $time = 0, $countLimit = 0, $weightLimit = 0, $timeLimit = 0) {
		$texts = [];
		$limits = [];
		$res = [];
		if($count != 0) $texts[] = HTML::Span(__("Count", styling:false)." $count ".__(\_::$INFO->CountUnit, styling:false), null, ["class"=>$count>0?"success":"error"]);
		if($weight != 0) $texts[] = HTML::Span(__("Weight", styling:false)." $weight ".__(\_::$INFO->WeightUnit, styling:false), null, ["class"=>$weight>0?"success":"error"]);
		if($time != 0) $texts[] = HTML::Span(__("Time", styling:false)." $time ".__(\_::$INFO->TimeUnit, styling:false), null, ["class"=>$time>0?"success":"error"]);
		if($countLimit != 0) $limits[] = HTML::Span(__("Count", styling:false)." $countLimit ".__(\_::$INFO->CountUnit, styling:false), null, ["class"=>$countLimit>0?"success":"error"]);
		if($weightLimit != 0) $limits[] = HTML::Span(__("Weight", styling:false)." $weightLimit ".__(\_::$INFO->WeightUnit, styling:false), null, ["class"=>$weightLimit>0?"success":"error"]);
		if($timeLimit != 0) $limits[] = HTML::Span(__("Time", styling:false)." $timeLimit ".__(\_::$INFO->TimeUnit, styling:false), null, ["class"=>$timeLimit>0?"success":"error"]);

		if(count($limits) > 0) $res[] = __("Limitation").": ".join(", ", $limits);
		if(count($texts) > 0) $res[] = __("Contradiction").": ".join(", ", $texts);

		if(count($res) > 0) return join(HTML::$NewLine, $res);
		else return null;
    }
	public function GetFilters($filters) {
		if(count($filters) > 0 && !RECEIVE(\_::$CONFIG->ViewHandlerKey))
			return HTML::Button("Filter: ","{load(`".\_::$PATH."`);}")
				.join(", ",loop($filters,
					function($k, $v){
						$url = urldecode(\_::$URL);
						$link = preg_replace("/\&?\s*".preg_quote(trim($v," \r\n\v\f\t|&"))."\s*\&?/mi","", $url);
						if($link == $url) return null;
						return
							HTML::Link(
									"&#10060; ".
									__(Convert::ToTitle(preg_find("/^[^=]*/",$v)), styling:false)
									.": ".__(preg_find("/[^=]*$/",$v), styling:false),
									$link
							);
					}
				));
		return null;
	}
}
?>