<?php
ACCESS(\_::$CONFIG->AdminAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Users Management";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(
    PART("table/users", print:false).
    PART("report/users", print:false));
?>