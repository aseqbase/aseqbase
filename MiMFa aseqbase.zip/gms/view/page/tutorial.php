<?php
ACCESS(\_::$CONFIG->AdminAccess);
MODULE("PrePage");
$module = new MiMFa\Module\PrePage();
$module->Title = "Tutorial";
$module->Draw();
MODULE("Collection");
MODULE("MediaFrame");
$module = new MiMFa\Module\Collection();
$module->MoreButtonLabel = "Show";
$module->Items = function(){
    yield new MiMFa\Module\MediaFrame(
        source:"https://www.aparat.com/embed/NmUF9?data[rnddiv]=48759566438&data[responsive]=yes",
        logo:"");
};
$module->Draw();
?>