<?php
ACCESS(\_::$CONFIG->PersonnelAccess);
MODULE("PrePage");
if(!RECEIVE(null,"post")){
    $module = new MiMFa\Module\PrePage();
    if(isset($_REQUEST["outbox"])) $module->Title = "Output Drafts Report";
    elseif(isset($_REQUEST["inbox"])) $module->Title = "Input Drafts Report";
    elseif(isset($_REQUEST["currentbox"])) $module->Title = "Current Drafts Report";
    elseif(isset($_REQUEST["addbox"])) $module->Title = "Added Drafts Report";
    elseif(isset($_REQUEST["subtractbox"])) $module->Title = "Subtracted Drafts Report";
    elseif(isset($_REQUEST["failbox"])) $module->Title = "Failed Drafts Report";
    elseif(isset($_REQUEST["partialbox"])) $module->Title = "Partial Drafts Report";
    elseif(isset($_REQUEST["completebox"])) $module->Title = "Completed Drafts Report";
    else $module->Title = "Drafts Report";
    $module->Draw();
    MODULE("PeriodPicker");
    (new MiMFa\Module\PeriodPicker(true, \_::$INFO->DefaultFromTime, \_::$INFO->DefaultToTime))->Draw();
}
echo \MiMFa\Library\HTML::Page(PART("report/drafts", print:false));
?>