<?php
ACCESS(\_::$CONFIG->AdminAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Status";
    $module->Draw();
    MODULE("PeriodPicker");
    (new MiMFa\Module\PeriodPicker(true, \_::$INFO->DefaultFromTime, \_::$INFO->DefaultToTime))->Draw();
}
echo \MiMFa\Library\HTML::Page(PART("report/status", print:false));
?>