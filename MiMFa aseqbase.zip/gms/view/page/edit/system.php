<?php
ACCESS(\_::$CONFIG->AdminAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Edit System";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(PART("system/information", print:false));
?>