<?php
ACCESS(\_::$CONFIG->PersonnelAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    if(isset($_REQUEST["outbox"])) $module->Title = "Edit Output Drafts";
    elseif(isset($_REQUEST["inbox"])) $module->Title = "Edit Input Drafts";
    elseif(isset($_REQUEST["currentbox"])) $module->Title = "Edit Current Drafts";
    elseif(isset($_REQUEST["addbox"])) $module->Title = "Edit Added Drafts";
    elseif(isset($_REQUEST["subtractbox"])) $module->Title = "Edit Subtracted Drafts";
    elseif(isset($_REQUEST["failbox"])) $module->Title = "Edit Failed Drafts";
    elseif(isset($_REQUEST["partialbox"])) $module->Title = "Edit Partial Drafts";
    elseif(isset($_REQUEST["completebox"])) $module->Title = "Edit Completed Drafts";
    else $module->Title = "Edit Drafts";
    $module->Draw();
    MODULE("PeriodPicker");
    (new MiMFa\Module\PeriodPicker(true, \_::$INFO->DefaultFromTime, \_::$INFO->DefaultToTime))->Draw();
}
echo \MiMFa\Library\HTML::Page(PART("table/drafts", print:false));
?>