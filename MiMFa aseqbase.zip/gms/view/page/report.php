<?php
ACCESS(\_::$CONFIG->AdminAccess);
MODULE("PrePage");
$module = new MiMFa\Module\PrePage();
$module->Title = "Report";
$module->Draw();
MODULE("Collection");
$module = new MiMFa\Module\Collection();
$module->MoreButtonLabel = "See Report";
$module->Items = getValid(getValid(\_::$INFO->MainMenus, "Report"),"Items");
$module->Draw();
?>