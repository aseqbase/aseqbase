<?php
ACCESS(\_::$CONFIG->AdminAccess);
MODULE("PrePage");
$module = new MiMFa\Module\PrePage();
$module->Title = "Edit";
$module->Draw();
MODULE("Collection");
$module = new MiMFa\Module\Collection();
$module->MoreButtonLabel = "Do Edit";
$module->Items = getValid(getValid(\_::$INFO->MainMenus, "Edit"),"Items");
$module->Draw();
?>