<?php
use MiMFa\Library\DataBase;
use MiMFa\Library\HTML;

ACCESS(\_::$CONFIG->PersonnelAccess);
$recMethod = "post";
$value = RECEIVE("ID", $recMethod);
$action = GRAB("action", $recMethod);
$userId = \_::$INFO->User->ID;
$groupId = \_::$INFO->User->GroupID;
$access = getAccess(\_::$CONFIG->AdminAccess);
$ifexactsource = $access?"":"((`UserID`=$userId OR `UserID` < 1) AND (`UserGroupID`=$groupId OR `UserGroupID` < 1))";
$ifsource = $access?"":"((`UserID`=$userId OR `UserGroupID`=$groupId) OR (`UserID` < 1 AND `UserGroupID` < 1))";
$ifdest = $access?"":"((`TargetUserID`=$userId OR `TargetUserGroupID`=$groupId) OR (`TargetUserID` < 1 AND `TargetUserGroupID` < 1))";

//Check errors
if(isEmpty($value)) SEND(HTML::Error("Your request is not valid!"));
$draft = DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."Draft", "*", "`ID`=:ID".($access?"":" AND ($ifsource OR $ifdest)"), [ ":ID"=>$value ]);
if(!isEmpty($draft) && count($draft)>0) $draft = $draft[0];
else SEND(HTML::Error("There could not find any drafts!"));
$datetime = \_::$CONFIG->GetFormattedDateTime();

$isexactsource = $access || (($draft["UserID"]==$userId || $draft["UserID"] < 1) && ($draft["UserGroupID"]==$groupId || $draft["UserGroupID"] < 1));
$issource = $access || (($draft["UserID"]==$userId || $draft["UserGroupID"]==$groupId) || ($draft["UserID"] < 1 && $draft["UserGroupID"] < 1));
$isdest = $access || (($draft["TargetUserID"]==$userId || $draft["TargetUserGroupID"]==$groupId) || ($draft["TargetUserID"] < 1 && $draft["TargetUserGroupID"] < 1));

$averageChange = function ($factor, $unitImpact = null, $user = null, $group = null) use($draft, $userId, $groupId){
	$res = [];
    if($user <= 0) $user = $userId;
    if($group <= 0) $group = $groupId;
	$user = between($user, $draft["UserID"], $userId);
	$group = between($group, $draft["UserGroupID"], $groupId);
    if($user <= 0) $user = $userId;
    if($group <= 0) $group = $groupId;
	$unitImpact = $unitImpact??\_::$INFO->UnitEffect;
    $avg = null;
	if($factor != 0 && !is_null($avg = \_::$INFO->User->GetValue("Average", $user))){
        $avg += $factor;
        $avg = min(1, max(0, $avg));
        if(\_::$INFO->User->SetValue("Average", $avg, $user))
            $res[] = ($factor<0?"Unfortunately, ":"Fortunately, ")."you received a '".round($factor*100,1)."%' mark due to the this work!";
    }
	if($unitImpact && $count = DataBase::GetCount(\_::$CONFIG->DataBasePrefix."User", "ID", "`GroupID`=:GroupID", [":GroupID"=>$group])){
		$unitImpact /= $count;
		$unitFactor = $factor * $unitImpact;
        if(DataBase::Update("UPDATE ".\_::$CONFIG->DataBasePrefix."User SET `Average`=LEAST(1, GREATEST(0, `Average` + $unitFactor)) WHERE `GroupID`=:GroupID", [":GroupID"=>$group]))
            $res[] = "Here added '".round($unitImpact*100,1)."%' marks to each person of your units.";
    }
    if(count($res) > 0 && $user == $userId) alert($res);
};
$factorFunc = function ($f, $t, $w, $c){
    $f = floatval($f);
    $t = intval($t);
    $w = floatval($w);
    $c = intval($c);
    return $f * (($t / \_::$INFO->TimeThreshold) + ($c / \_::$INFO->CountThreshold) + ($w / \_::$INFO->WeightThreshold)) / 3;
};
$averageEffect = function ($impact, $time, $weight, $count, $unitImpact = null, $user = null, $group = null) use ($factorFunc, $averageChange){
	if($impact === 0) return 0;
	$factor = $factorFunc($impact, $time, $weight, $count);
	$averageChange($factor, $unitImpact, $user, $group);
	return $factor;
};

foreach ($draft as $k=>$v) if($v == "NULL") $draft[$k] = null;

//Do action
$act = preg_split("/_/",$action)[0];
switch ($act) {
    case "view":
		echo HTML::Style("
			.button .image {
				display: block;
			}");
		MODULE("Form");
		$title = $draft["Title"];
		$description = $draft["Description"];
		$image = getValid($draft,"Image", null)?? DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."Product","Image","`ID`={$draft["ProductID"]}",[],null);

		$btns = null;
		$btnattr = ["class"=>"col-lg", "style"=>"padding: calc(var(--Size-0) / 2) var(--Size-1); color: #fefefe; display: block;"];
		switch ($action)
        {
            case "view_transfer":
				$uid = "unit_".getId();
				$pid = "person_".getId();
				$cid = "count_".getId();
				$wid = "weight_".getId();
                $form = new MiMFa\Module\Form(
                    method:false,
                    title:$title,
                    description:between($description,"To send this draft to next step!"),
                    image:between($image,"forward")
                );
                $usergroups = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title");
                $users = [];
				if($access){
                    $users = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
                }
                else{
                    $val = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."UserGroup", "TargetIDs", "`ID`=:ID",[":ID"=>$groupId]);
                    $cond = isEmpty($val)?[]:json_decode($val);
                    $usergroups = array_filter($usergroups, function($v,$k)use($cond){ return in_array($k, $cond);},ARRAY_FILTER_USE_BOTH);
                    $cond = isEmpty($val)?null:"GroupID IN (".join(", ", json_decode($val)).")";
                    $users = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name", $cond);
                }
                $form->Children[] = HTML::Field(key:"unit",
					type: "select",
					title:"Target Unit",
					description: "The destination unit to send this draft!",
					value: $draft["TargetUserGroupID"],
					options: $usergroups,
					attributes:["id"=>$uid]
				);
                $form->Children[] = HTML::Field(key:"person",
					type: "select",
					title: "Target Person",
					description: "The destination user to send this draft!",
					value: $draft["TargetUserID"],
					options: $users,
					attributes:["id"=>$pid]
				);
                $form->Children[] = HTML::Field(key:"count",
					type: "int",
					title:"Count",
					description:"Count of works in draft ('".\_::$INFO->CountUnit."')!",
					value: $draft["Count"],
					options:["min"=>0, "max"=>$draft["Count"]],
					attributes:["id"=>$cid, "onchange"=>"
                    if(document.hasFocus(this)){
                        let ctrl = document.getElementById('$wid');
                        let wval = parseFloat(ctrl.value);
                        let cval = parseInt(this.value);
                        if(cval == 0) ctrl.value = 0;
                        else if(cval == {$draft["Count"]}) ctrl.value = {$draft["Weight"]};
                        else ctrl.value = Math.decimals(cval*".($draft["Weight"]/$draft["Count"]).", ".\_::$INFO->WeightPrecision.");
                    }"]
				);
                $form->Children[] = HTML::Field(key:"weight",
					type: "float",
					title:"Weight",
					description:"Weight of draft ('".\_::$INFO->WeightUnit."')!",
					value: $draft["Weight"],
					options:["min"=> $draft["Count"]==1?$draft["Weight"]:0,"max"=>$draft["Weight"]],
					attributes:["id"=>$wid, "onchange"=>"
                    if(document.hasFocus(this)){
                        let ctrl = document.getElementById('$cid');
                        let wval = parseFloat(this.value);
                        let cval = parseInt(ctrl.value);
                        if(wval == 0) ctrl.value = 0;
                        else if(wval == {$draft["Weight"]}) ctrl.value = {$draft["Count"]};
                        else if(cval == 0 && wval != 0) ctrl.value = 1;
                    }"]
				);
                $form->Template = "b";
                $form->Buttons = HTML::Button(HTML::Span("Submit ").HTML::Image("forward"),
					"Modal_Management_Transfer($value, document.getElementById('$uid').value, document.getElementById('$pid').value, document.getElementById('$wid').value, document.getElementById('$cid').value);",
					["style"=>"background-color: var(--Color-1);"], $btnattr);
                $form->ResetLabel = "Reset";
                $form->SubmitLabel = null;
                $form->CancelLabel = "Close";
                $form->CancelPath = "Modal_Management_Close();";
                $form->BackLabel = "Back";
                $form->BackPath = "load();";
                SEND($form->Capture());
            case "view_change":
				$cwid = "cweight_".getId();
				$cid = "count_".getId();
				$wid = "weight_".getId();
				$unit = DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."UserGroup", "*", "`ID`=:ID",[":ID"=>$groupId])[0];
                $form = new MiMFa\Module\Form(
                    method:false,
                    title:$title,
                    description:between($description,"To set some changes on this draft!"),
                    image:between($image,"pencil")
                );
                $form->Children[] = HTML::Field(key:"weight",
					type: "float",
					title:"Changed Weight",
					description:"Weight of changed ('".\_::$INFO->WeightUnit."')!",
					value: 0,
					options:["min"=> -1 * $draft["Weight"],"max"=>$draft["Weight"]],
					attributes:["id"=>$wid, "onchange"=>"
                        if(document.hasFocus(this)) document.getElementById('$cwid').value = Math.decimals({$draft['Weight']}+parseFloat(this.value), ".\_::$INFO->WeightPrecision.");
                        if(this.value < ".($unit["WeightDownTolerance"] * $draft["Weight"])." || this.value > ".($unit["WeightUpTolerance"] * $draft["Weight"]).")
                            this.style.color = 'var(--Color-0)';
                        else this.style.color = null;
                    "]
				);
                $form->Children[] = HTML::Field(key:"currentweight",
					type: "float",
					title:"Current Weight",
					description:"Current weight of work ('".\_::$INFO->WeightUnit."')!",
					value: $draft["Weight"],
					options:["min"=>0, "max"=>2*$draft["Weight"]],
					attributes:["id"=>$cwid, "onchange"=>"
                        if(document.hasFocus(this)) document.getElementById('$wid').value = Math.decimals(parseFloat(this.value)-{$draft['Weight']}, ".\_::$INFO->WeightPrecision.");
                        if(this.value < ".($draft["Weight"]+($unit["WeightDownTolerance"] * $draft["Weight"]))." || this.value > ".($draft["Weight"]+($unit["WeightUpTolerance"] * $draft["Weight"])).")
                            this.style.color = 'var(--Color-0)';
                        else this.style.color = null;
                    "]
				);
                $form->Children[] = HTML::$HorizontalBreak;
                $form->Children[] = HTML::Field(key:"count",
					type: "int",
					title:"Changed Count",
					description:"Count of lost work ('".\_::$INFO->CountUnit."')!<br>Do not change this value without coordination!",
					value: 0,
					options:[-1 * $draft["Count"],0],
					attributes:["id"=>$cid, "style"=>"color: var(--Color-0);", "onchange"=>"
                    if(document.hasFocus(this)){
                        let ctrl = document.getElementById('$wid');
                        let cctrl = document.getElementById('$cwid');
                        let wval = parseFloat(ctrl.value);
                        let cwval = parseFloat(cctrl.value);
                        let cval = parseInt(this.value);
                        if(cval == 0) {
                            ctrl.value = 0;
                            cctrl.value = {$draft["Weight"]};
                        }
                        else if(cval == -{$draft["Count"]}) {
                            ctrl.value = -{$draft["Weight"]};
                            cctrl.value = 0;
                        }
                        else {
                            ctrl.value = Math.decimals(cval*".($draft["Weight"]/$draft["Count"]).", ".\_::$INFO->WeightPrecision.");
                            cctrl.value = {$draft["Weight"]} + ctrl.value;
                        }
                    }"]
				);
                $form->Template = "b";
                $form->Buttons = HTML::Button(HTML::Span("Submit ").HTML::Image("pencil"),
					"Modal_Management_Change($value, document.getElementById('$wid').value, document.getElementById('$cid').value);",
					["style"=>"background-color: var(--Color-3);"], $btnattr);
                $form->ResetLabel = "Reset";
                $form->SubmitLabel = null;
                $form->CancelLabel = "Close";
                $form->CancelPath = "Modal_Management_Close();";
                $form->BackLabel = "Back";
                $form->BackPath = "load();";
                SEND($form->Capture());
            case "view_swarf":
				$cwid = "cweight_".getId();
				$wid = "weight_".getId();
				$unit = DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."UserGroup", "*", "`ID`=:ID",[":ID"=>$groupId])[0];
                $form = new MiMFa\Module\Form(
                    method:false,
                    title:$title,
                    description:between($description,"To set some changes on this draft!"),
                    image:between($image,"recycle")
                );
                $form->Children[] = HTML::Field(key:"weight",
					type: "float",
					title:"Changed Weight",
					description:"Weight of changed ('".\_::$INFO->WeightUnit."')!",
					value: 0,
					options:["min"=> $unit["WeightDownTolerance"] * $draft["Weight"],"max"=>0],
					attributes:["id"=>$wid, "onchange"=>"if(document.hasFocus(this)) document.getElementById('$cwid').value = Math.decimals({$draft['Weight']}+parseFloat(this.value), ".\_::$INFO->WeightPrecision.");"]
				);
                $form->Children[] = HTML::Field(key:"currentweight",
					type: "float",
					title:"Current Weight",
					description:"Current weight of work ('".\_::$INFO->WeightUnit."')!",
					value: $draft["Weight"],
					options:["min"=>$draft["Weight"]+($unit["WeightDownTolerance"] * $draft["Weight"]), "max"=>$draft["Weight"]],
					attributes:["id"=>$cwid, "onchange"=>"if(document.hasFocus(this)) document.getElementById('$wid').value = Math.decimals(parseFloat(this.value)-{$draft['Weight']}, ".\_::$INFO->WeightPrecision.");"]
				);
                $form->Template = "b";
                $form->Buttons = HTML::Button(HTML::Span("Submit ").HTML::Image("recycle"),
					"Modal_Management_Swarf($value, document.getElementById('$wid').value);",
					["style"=>"background-color: #eeaa11;"], $btnattr);
                $form->ResetLabel = "Reset";
                $form->SubmitLabel = null;
                $form->CancelLabel = "Close";
                $form->CancelPath = "Modal_Management_Close();";
                $form->BackLabel = "Back";
                $form->BackPath = "load();";
                SEND($form->Capture());
            case "view_damage":
            case 'view_damagebyunit':
            case 'view_damagebyperson':
            case 'view_damagebyproduct':
            case 'view_damagebytool':
				$cid = "count_".getId();
				$wid = "weight_".getId();
                $dtype = last(preg_split("/_/",$action));
                $dweight = abs($draft["Weight"]);
                $dcount = abs($draft["Count"]);
                $form = new MiMFa\Module\Form(
                    method:false,
                    title:$title,
                    description:between($description,"To set this draft as $dtype!"),
                    image:between($image,"warning")
                );
                $form->Children[] = HTML::Field(key:"count",
					type: "int",
					title:"Count",
					description:"Count of damaged work ('".\_::$INFO->CountUnit."')!",
					value:-1 * $dcount,
					options:[-1 * $dcount,-1],
					attributes:["id"=>$cid, "onchange"=>"
                    if(document.hasFocus(this)){
                        let ctrl = document.getElementById('$wid');
                        let wval = parseFloat(ctrl.value);
                        let cval = parseInt(this.value);
                        if(cval == 0) ctrl.value = 0;
                        else if(cval == -{$dcount}) ctrl.value = -{$dweight};
                        else ctrl.value = Math.decimals(cval*".($dweight/$dcount).", ".\_::$INFO->WeightPrecision.");
                    }"]
				);
                $form->Children[] = HTML::Field(key:"weight",
					type: "float",
					title:"Weight",
					description:"Weight of damaged work ('".\_::$INFO->WeightUnit."')!",
					value:-1 * $dweight,
					options:[$dcount==1?-1 * $dweight:0, -1 * $dweight],
					attributes:["id"=>$wid, "onchange"=>"
                    if(document.hasFocus(this)){
                        let ctrl = document.getElementById('$cid');
                        let wval = parseFloat(this.value);
                        let cval = parseInt(ctrl.value);
                        if(wval == 0) ctrl.value = 0;
                        else if(wval <= -{$dweight}) ctrl.value = -{$dcount};
                        else if(cval == 0 && wval != 0) ctrl.value = -1;
                    }"]
				);
                $form->Template = "b";
                $form->Buttons = HTML::Button(HTML::Span("Submit ").HTML::Image("warning"),
					"Modal_Management_Damage($value, document.getElementById('$wid').value, document.getElementById('$cid').value, '$dtype');",
					["style"=>"background-color: #ff8811;"], $btnattr);
                $form->ResetLabel = "Reset";
                $form->SubmitLabel = null;
                $form->CancelLabel = "Close";
                $form->CancelPath = "Modal_Management_Close();";
                $form->BackLabel = "Back";
                $form->BackPath = "load();";
                SEND($form->Capture());
            case "view":
                switch ($draft["Status"])
                {
                    case "Transfer":
                        if($access || $draft["TargetUserGroupID"] == $groupId || $draft["TargetUserID"] == $userId){
                            $btns = HTML::Button(HTML::Span("Submit ").HTML::Image("check").HTML::Tooltip("I have Received and submitted this draft!"), "Modal_Management_Submit($value)", ["style"=>"background-color: var(--Color-1);"],$btnattr);
							if($access) $btns .= HTML::Button(HTML::Span("Return ").HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($value)", ["style"=>"background-color: #ffaa22;"],$btnattr);
                        }
						else {
                            $btns = HTML::Button(HTML::Span("Return ").HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($value)", ["style"=>"background-color: #ffaa22;"],$btnattr);
                            if($access) $btns .= HTML::Button(HTML::Span("Submit ").HTML::Image("check").HTML::Tooltip("I have Received and submitted this draft!"), "Modal_Management_Submit($value)", ["style"=>"background-color: var(--Color-1);"],$btnattr);
                        }
						break;
                    case "Processing":
                        $btns =
                            HTML::Button(HTML::Span("Transfer ").HTML::Image("forward").HTML::Tooltip("Finished processing and send this draft to the target unit!"), "Modal_Management_Transfer($value)", ["style"=>"background-color: var(--Color-1);"],$btnattr).
                            ($access?HTML::Button(HTML::Span("Complete ").HTML::Image("flag-checkered").HTML::Tooltip("Finished processing and set this draft as completed!"), "Modal_Management_Complete($value)", ["style"=>"background-color: var(--Color-2); color: #fefefe;"],$btnattr):"").
                            HTML::Button(HTML::Span("Change ").HTML::Image("pencil").HTML::Tooltip("There had some changes in this draft!"), "Modal_Management_Change($value)", ["style"=>"background-color: var(--Color-3);"],$btnattr).
							HTML::Button(HTML::Span("Swarf ").HTML::Image("recycle").HTML::Tooltip("There made some swarfs in this draft!"), "Modal_Management_Swarf($value)", ["style"=>"background-color: #eeaa11; color: #fefefe;"],$btnattr).
                            HTML::Button(HTML::Span("Damage ").HTML::Image("warning").HTML::Tooltip("To set this draft as damaged!"), "Modal_Management_Damage($value)", ["style"=>"background-color: #ff8811;"],$btnattr);
                        break;
                    case "Damaged":
                        if($access)
                            $btns = HTML::Button(HTML::Span("Return ").HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($value)", ["style"=>"background-color: #ff2222;"],$btnattr).
                            HTML::Button("Damaged By Unit", "Modal_Management_Damage($value, null, null, 'damagebyunit')", ["style"=>"background-color: #ff8811;"],$btnattr).
                            HTML::Button("Damaged By Person", "Modal_Management_Damage($value, null, null, 'damagebyperson')", ["style"=>"background-color: #ff8811;"],$btnattr).
                            HTML::Button("Damaged By Product", "Modal_Management_Damage($value, null, null, 'damagebyproduct')", ["style"=>"background-color: #ff8811;"],$btnattr).
                            HTML::Button("Damaged By Tool", "Modal_Management_Damage($value, null, null, 'damagebytool')", ["style"=>"background-color: #ff8811;"],$btnattr);
                        else $btns = HTML::Button(HTML::Span("Return ").HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($value)", ["style"=>"background-color: #ff2222;"],$btnattr);
                        break;
                    case "Swarfed":
                    case "Changed":
                    case "Lost":
                        $btns = HTML::Button(HTML::Span("Return ").HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($value)", ["style"=>"background-color: #ff2222;"],$btnattr);
                        break;
                }
				break;
        }
        $draft["Product"] = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."Product","Title","`ID`={$draft["ProductID"]}",[],$draft["ProductID"]??"");
		$draft["Source Unit"] = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."UserGroup","Title","`ID`={$draft["UserGroupID"]}",[],$draft["UserGroupID"]??"");
		$draft["Source Person"] = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."User","Name","`ID`={$draft["UserID"]}",[],$draft["UserID"]??"");
		$draft["Destination Unit"] = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."UserGroup","Title","`ID`={$draft["TargetUserGroupID"]}",[],$draft["TargetUserGroupID"??""]);
		$draft["Destination Person"] = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."User","Name","`ID`={$draft["TargetUserID"]}",[],$draft["TargetUserID"]??"");

		unset($draft["Title"]);
		unset($draft["Description"]);
		unset($draft["Image"]);
		unset($draft["ID"]);
		unset($draft["ParentID"]);
		unset($draft["AuthorID"]);
		unset($draft["EditorID"]);
		unset($draft["ProductID"]);
		unset($draft["UserGroupID"]);
		unset($draft["UserID"]);
		unset($draft["TargetUserGroupID"]);
		unset($draft["TargetUserID"]);
		unset($draft["ToolIDs"]);
		unset($draft["MetaData"]);
		unset($draft["CreateTime"]);
		unset($draft["UpdateTime"]);

		$form = new MiMFa\Module\Form(
			method:false,
			title:$title,
			description:$description,
            image:between($image,"eye"),
			children:$draft
		);
        $form->Template = "b";
		$form->Buttons = $btns;
		$form->ResetLabel = null;
		$form->SubmitLabel = null;
		$form->CancelLabel = "Close";
		$form->CancelPath = "Modal_Management_Close();";
		$form->BackLabel = "Back";
		$form->BackPath = "load();";
		SEND($form->Capture());
    case "transfer":
        if(!$isexactsource || $draft["Status"] != "Processing") SEND(HTML::Error("You do not have enough access to this action!"));
		$stime = (\_::$CONFIG->GetDateTime(between($draft["UpdateTime"], $draft["CreateTime"])))->diff(\_::$CONFIG->GetDateTime($datetime));
		$time = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."UserGroup", "IsActive", "`ID`=:ID",[":ID"=>$groupId])?
			(($stime->days * 24 * 60) + ($stime->h * 60) + $stime->i):0;
		$tugid = RECEIVE("unit", $recMethod);
		$tuid = RECEIVE("person", $recMethod);
        $weight = floatval(RECEIVE("weight", $recMethod, 0));
        $count = intval(RECEIVE("count", $recMethod, 0));
        if((!isValid($tugid) && !isValid($tuid)) || $count < 1)
			SEND(HTML::Error("Please complete all required parameters"));
		if($weight == 0 && $count !== 0)
			$weight = ($count * floatval($draft["Weight"])) / intval($draft["Count"]);
		$isfirst = $draft["LatestTime"]<1;
        if($time && !isEmpty($draft["ToolIDs"]))
            try{
			    $tools = json_decode($draft["ToolIDs"]);
			    if(!DataBase::Update("
				    UPDATE `".\_::$CONFIG->DataBasePrefix."Tool`
				    SET `UsedWorkTime`=`UsedWorkTime` + $time
				    ".($isfirst?", `UsedWorkCount`=`UsedWorkCount` + {$draft["Count"]}
				    , `UsedWorkWeight`=`UsedWorkWeight` + {$draft["Weight"]}
				    ":"")."WHERE `ID` IN (".join(", ",$tools).")"))
				    SEND(HTML::Error("Could not update tools usage!"));
            }catch(\Exception $ex){}
        $params = [
                ":ID"=>$value,
                ":TargetUserGroupID"=>$tugid,
                ":TargetUserID"=>$tuid,
                ":UserGroupID" => $access?$draft["UserGroupID"]:$groupId,
                ":UserID" => $access?$draft["UserID"]:$userId,
                ":Time"=>intval($draft["Time"])+$time,
                ":LatestTime"=>$time,
                ":Status"=>"Transfer",
				":UpdateTime"=>$datetime
            ];
        $ins = true;
        if($weight !== floatval($draft["Weight"]) || $count !== intval($draft["Count"])) {
            $ds = $draft;
            unset($ds["ID"]);
            $ds["ParentID"] = $value;
            $ds["Weight"] = $weight;
            $ds["Count"] = $count;
            $ds["ChangeCount"] = 0;
            $ds["TargetUserGroupID"] = $params[":TargetUserGroupID"];
            $ds["TargetUserID"] = $params[":TargetUserID"];
            $ds["UserGroupID"] = $params[":UserGroupID"];
            $ds["UserID"] = $params[":UserID"];
            $ds["Time"] = $params[":Time"];
            $ds["Status"] = $params[":Status"];
            $ds["CreateTime"] = $datetime;
            $ds["LatestTime"] = $params[":LatestTime"];
            $ds["UpdateTime"] = $params[":UpdateTime"];
            $ins = DataBase::DoInsert(\_::$CONFIG->DataBasePrefix."Draft", null, $ds);

            $nweight = floatval($draft["Weight"]) - $weight;
            $ncount = intval($draft["Count"]) - $count;
            $params = [
                ":ID"=>$value,
                ":Weight" => $nweight,
                ":Count" => $ncount,
                ":UserGroupID" => $access?$draft["UserGroupID"]:$groupId,
                ":UserID" => $access?$draft["UserID"]:$userId,
                ":LatestTime"=>0,
                ":Status"=>$nweight==0?"Completed":"Processing",
				":UpdateTime"=>$datetime
            ];
        }
        if($ins && DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status`='Processing'", $params)) {
            $averageEffect(\_::$INFO->SendImpact, $time, $draft["Weight"], $draft["Count"]);
			FLIP(HTML::Success("The '".between($draft["Title"], $draft["ID"])."' sent to the next unit!"));
        }
		break;
    case "return":
        if(!$isexactsource || !in_array($draft["Status"], ["Transfer", "Damaged", "Swarfed", "Changed", "Lost"])) SEND(HTML::Error("You do not have enough access to this action!"));
        $imp = -1;
        $insed = false;
        $ds = $draft;
        switch ($draft["Status"])
        {
        	case "Swarfed":
        	case "Damaged":
        	case "Lost":
                $ds["Weight"] = abs($draft["Weight"]);
                $ds["Count"] = abs($draft["Count"]);
                $ds["ChangeCount"]++;
                $ds["TargetUserGroupID"] = null;
                $ds["TargetUserID"] = null;
                $ds["Status"] = "Processing";
                $ds["UpdateTime"] = $datetime;
                $imp = 1;
                break;
        	case "Changed":
                $ds["Weight"] = -($draft["Weight"]);
                $ds["Count"] = -($draft["Count"]);
                $ds["ChangeCount"]++;
                $ds["TargetUserGroupID"] = null;
                $ds["TargetUserID"] = null;
                $ds["Status"] = "Processing";
                $ds["UpdateTime"] = $datetime;
                $imp = $draft["Weight"]<0?1:-1;
                break;
        	default:
                $ds["ChangeCount"]++;
                $ds["TargetUserGroupID"] = null;
                $ds["TargetUserID"] = null;
                $ds["Status"] = "Processing";
                $ds["UpdateTime"] = $datetime;
                $imp = -1;
                break;
        }

        if(\_::$INFO->MergeDrafts && isValid($cpd = first(DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."Draft", "*", "`ProductID`=:ProductID AND `Status`='Processing'".($access?"":" AND $ifexactsource"),
            [
                ":ProductID"=>$ds["ProductID"]
            ]))))
            $insed = DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID",
            [
                ":ID"=>$cpd["ID"],
                ":Weight"=>$cpd["Weight"]+$ds["Weight"],
                ":Count"=>$cpd["Count"]+$ds["Count"],
                ":ChangeCount"=>($cpd["ChangeCount"]??0) + $ds["ChangeCount"],
                ":UpdateTime"=>$ds["UpdateTime"]
            ]);
        else $insed = DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status`='{$draft["Status"]}'",
            [
                ":ID"=>$value,
                ":TargetUserGroupID"=>$ds["TargetUserGroupID"],
                ":TargetUserID"=>$ds["TargetUserID"],
                ":Weight" => $ds["Weight"],
                ":Count" => $ds["Count"],
                ":Status"=>$ds["Status"],
                ":ChangeCount"=>$ds["ChangeCount"],
                ":UpdateTime"=>$ds["UpdateTime"]
            ]);
        if($insed && DataBase::DoDelete(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status`='{$draft["Status"]}'",
            [
                ":ID"=>$value
            ])){
            $stime = (\_::$CONFIG->GetDateTime(between($draft["UpdateTime"], $draft["CreateTime"])))->diff(\_::$CONFIG->GetDateTime($datetime));
            $time = abs(($stime->days * 24 * 60) + ($stime->h * 60) + $stime->i);
            $averageEffect($imp * \_::$INFO->SendImpact, $time, $draft["Weight"], $draft["Count"]);
            FLIP(HTML::Success("The '".between($draft["Title"], $draft["ID"])."' returned to your current box!"));
        }
        break;
    case "submit":
        if(!$isdest || $draft["Status"] != "Transfer") SEND(HTML::Error("You do not have enough access to this action!"));
        $stime = (\_::$CONFIG->GetDateTime(between($draft["UpdateTime"], $draft["CreateTime"])))->diff(\_::$CONFIG->GetDateTime($datetime));
        $time = abs(($stime->days * 24 * 60) + ($stime->h * 60) + $stime->i);
		$ds = $draft;
		unset($ds["ID"]);
		$ds["ParentID"] = $value;
		$ds["UserGroupID"] = $access?$ds["TargetUserGroupID"]:$groupId;
		$ds["UserID"] = $access?$ds["TargetUserID"]:$userId;
		$ds["TargetUserGroupID"] = -1;
		$ds["TargetUserID"] = -1;
		$ds["ChangeCount"] = 0;
		$ds["LatestTime"] = 0;
		$ds["ToolIDs"] = null;
		$ds["Status"] = "Processing";
        $insed = false;
        if(\_::$INFO->MergeDrafts && isValid($cpd = first(DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."Draft", "*", "`ProductID`=:ProductID AND `Status`='Processing'".($access?"":" AND $ifexactsource"),
                [
                    ":ProductID"=>$ds["ProductID"]
                ]))))
            $insed = DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID",
            [
                ":ID"=>$cpd["ID"],
                ":Weight"=>$cpd["Weight"]+$ds["Weight"],
                ":Count"=>$cpd["Count"]+$ds["Count"],
                ":Time"=>max($cpd["Time"], $ds["Time"]),
                ":ChangeCount"=>($cpd["ChangeCount"]??0) + 1,
                ":UpdateTime"=>$datetime
            ]);
        else $insed = DataBase::DoInsert(\_::$CONFIG->DataBasePrefix."Draft", null, $ds);

		if($insed && DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status`='Transfer'",
            [
                ":ID"=>$value,
                ":Status"=>"Completed",
                ":UpdateTime"=>$datetime
            ])){
            $group = first(DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."UserGroup", "`WorkMaxTolerance`, `WorkMinTolerance`", "`ID`=".($draft["UserGroupID"]??$groupId)));
            if(!isEmpty($group)){
                $maxWork = $group["WorkMaxTolerance"]??0.1;
                $minWork = $group["WorkMinTolerance"]??0.01;
                $imp = ((($draft["Weight"]/max($draft["LatestTime"], 1)) - $minWork) / max($maxWork - $minWork, 1));
                $averageEffect(\_::$INFO->WorkImpact * $imp, $draft["LatestTime"], $draft["Weight"], $draft["Count"], user:$draft["UserID"], group:$draft["UserGroupID"]);
            }
            $mt = max($time,1);
            $averageEffect(\_::$INFO->ReceiveImpact, -$time, $draft["Weight"]/$mt, $draft["Count"]/$mt, user:$draft["TargetUserID"], group:$draft["TargetUserGroupID"]);
            FLIP(HTML::Success("The '".between($draft["Title"], $draft["ID"])."' received in your current box!"));
        }
		break;
    case "complete":
        if(!$issource || $draft["Status"] != "Processing") SEND(HTML::Error("You do not have enough access to this action!"));
        $stime = (\_::$CONFIG->GetDateTime(between($draft["UpdateTime"], $draft["CreateTime"])))->diff(\_::$CONFIG->GetDateTime($datetime));
        $time = abs(($stime->days * 24 * 60) + ($stime->h * 60) + $stime->i);

		if(DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status`='Processing'",
            [
                ":ID"=>$value,
                ":Status"=>"Completed",
                ":UpdateTime"=>$datetime
            ])){
            $group = first(DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."UserGroup", "`WorkMaxTolerance`, `WorkMinTolerance`", "`ID`=".($draft["UserGroupID"]??$groupId)));
            if(!isEmpty($group)){
                $maxWork = $group["WorkMaxTolerance"]??0.1;
                $minWork = $group["WorkMinTolerance"]??0.01;
                $imp = ((($draft["Weight"]/max($draft["LatestTime"], 1)) - $minWork) / max($maxWork - $minWork, 1));
                $averageEffect(\_::$INFO->WorkImpact * $imp, $draft["LatestTime"], $draft["Weight"], $draft["Count"], user:$draft["UserID"], group:$draft["UserGroupID"]);
            }
            $mt = max($time,1);
            $averageEffect(\_::$INFO->ReceiveImpact, -$time, $draft["Weight"]/$mt, $draft["Count"]/$mt, user:$draft["TargetUserID"], group:$draft["TargetUserGroupID"]);
            FLIP(HTML::Success("The '".between($draft["Title"], $draft["ID"])."' received in your current box!"));
        }
		break;
    case "change":
        if(!$isexactsource || $draft["Status"] != "Processing") SEND(HTML::Error("You do not have enough access to this action!"));
        $weight = floatval(RECEIVE("weight", $recMethod, 0));
        $count = intval(RECEIVE("count", $recMethod, 0));
        if($weight==0 && $count==0)
			SEND(HTML::Error("There is not received any changes!"));
		if($weight == 0 || $count !== 0)
			$weight = ($count * floatval($draft["Weight"])) / intval($draft["Count"]);
		$ds = null;
		$st = $count<0?"Lost":"Changed";
		if($draft["Count"] != abs($count)) {
            $ds = first(DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."Draft", "*", "`ParentID`=:ParentID AND `Status`='$st'".($access?"":" AND $ifexactsource"),
                [
                    ":ParentID"=>$value,
                ]));
            if(isEmpty($ds)) {
                $ds = $draft;
                unset($ds["ID"]);
                $ds["ParentID"] = $value;
                $ds["UserGroupID"] = $access?$draft["UserGroupID"]:$groupId;
                $ds["UserID"] = $access?$draft["UserID"]:$userId;
                $ds["Weight"] = $weight;
                $ds["Count"] = $count;
                $ds["ChangeCount"] = 0;
                $ds["CreateTime"] = $datetime;
                $ds["UpdateTime"] = $datetime;
                $ds["Status"] = $st;
            } else {
                $ds["UserGroupID"] = $access?$draft["UserGroupID"]:$groupId;
                $ds["UserID"] = $access?$draft["UserID"]:$userId;
                $ds["Weight"] += $weight;
                $ds["Count"] += $count;
                $ds["ChangeCount"] += 1;
                $ds["UpdateTime"] = $datetime;
            }
            if((
				isset($ds["ID"])?
					DataBase::DoReplace(\_::$CONFIG->DataBasePrefix."Draft", null, $ds):
					DataBase::DoInsert(\_::$CONFIG->DataBasePrefix."Draft", null, $ds)
			    ) &&
			    DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status`='Processing'",
			    [
				    ":ID"=> $value,
                    ":UserGroupID" => $access?$draft["UserGroupID"]:$groupId,
                    ":UserID" => $access?$draft["UserID"]:$userId,
				    ":Weight"=> $draft["Weight"]+$weight,
				    ":Count"=> $draft["Count"]+$count,
				    ":UpdateTime"=> $datetime
			    ])){
                if($count<0){
                    $averageEffect(\_::$INFO->LoseImpact, $draft["Time"], abs($weight), abs($count));
                }
                elseif($weight<0)
                    $averageEffect(\_::$INFO->SubtractImpact, $draft["Time"], abs($weight), 1, 0);
                else
                    $averageEffect(\_::$INFO->AddImpact, $draft["Time"], abs($weight), 1, 0);
                FLIP(HTML::Success("Your change draft for the '".between($draft["Title"], $draft["ID"])."' registered successfully!"));
            }
        }
		elseif(DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status`='Processing'",
			[
				":ID"=>$value,
                ":UserGroupID" => $access?$draft["UserGroupID"]:$groupId,
                ":UserID" => $access?$draft["UserID"]:$userId,
				":Weight"=> -abs($draft["Weight"]),
				":Count"=> -abs($draft["Count"]),
				":Status"=>"Lost",
				":UpdateTime"=>$datetime
			])){
            $averageEffect(\_::$INFO->LoseImpact, $draft["Time"], $draft["Weight"], $draft["Count"]);
            FLIP(HTML::Warning("The '".between($draft["Title"], $draft["ID"])."' lost draft, received successfully!"));
        }
		break;
    case "swarf":
        if(!$isexactsource || $draft["Status"] != "Processing") SEND(HTML::Error("You do not have enough access to this action!"));
        $weight = floatval(RECEIVE("weight", $recMethod, 0));
        if($weight==0) SEND(HTML::Error("There is not received any changes!"));
        $ds = null;
        $ds = first(DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."Draft", "*", "`ParentID`=:ParentID AND `Status`='Swarfed'".($access?"":" AND $ifexactsource"),
            [
                ":ParentID"=>$value,
            ]));
        if(isEmpty($ds)) {
            $ds = $draft;
            unset($ds["ID"]);
            $ds["ParentID"] = $value;
            $ds["UserGroupID"] = $access?$draft["UserGroupID"]:$groupId;
            $ds["UserID"] = $access?$draft["UserID"]:$userId;
            $ds["Weight"] = $weight;
            $ds["Count"] = 0;
            $ds["ChangeCount"] = 0;
            $ds["CreateTime"] = $datetime;
            $ds["UpdateTime"] = $datetime;
            $ds["Status"] = "Swarfed";
        } else {
            $ds["UserGroupID"] = $access?$draft["UserGroupID"]:$groupId;
            $ds["UserID"] = $access?$draft["UserID"]:$userId;
            $ds["Weight"] += $weight;
            $ds["ChangeCount"] += 1;
            $ds["UpdateTime"] = $datetime;
        }
		if((
			isset($ds["ID"])?
				DataBase::DoReplace(\_::$CONFIG->DataBasePrefix."Draft", null, $ds):
				DataBase::DoInsert(\_::$CONFIG->DataBasePrefix."Draft", null, $ds)
			) &&
            DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status`='Processing'",
            [
                ":ID"=>$value,
                ":UserGroupID" => $access?$draft["UserGroupID"]:$groupId,
                ":UserID" => $access?$draft["UserID"]:$userId,
                ":Weight"=> $draft["Weight"]+$weight,
                ":UpdateTime"=>$datetime
            ])){
            $averageEffect(\_::$INFO->SwarfImpact, $draft["Time"], abs($weight), 1, 0);
            FLIP(HTML::Success("Your change draft for the '".between($draft["Title"], $draft["ID"])."' registered successfully!"));
        }
		break;
    case "damage":
    case 'damagebyunit':
	case 'damagebyperson':
	case 'damagebyproduct':
    case 'damagebytool':
        if(!$isexactsource || ($draft["Status"] != "Processing" && $draft["Status"] != "Damaged")) SEND(HTML::Error("You do not have enough access to this action!"));
		$imp = \_::$INFO->DamageImpact;
		$dmg = "Damaged";
		if($access){
            $userId = $draft["UserID"];
            $groupId = $draft["UserGroupID"];
        }
		switch ($act)
        {
            case 'damagebyunit':
                $imp = \_::$INFO->DamageByUnitImpact;
                $dmg = "DamagedByUnit";
                break;
            case 'damagebyperson':
                $imp = \_::$INFO->DamageByPersonImpact;
                $dmg = "DamagedByPerson";
                break;
            case 'damagebyproduct':
                $imp = \_::$INFO->DamageByProductImpact;
                $dmg = "DamagedByProduct";
                break;
            case 'damagebytool':
                $imp = \_::$INFO->DamageByToolImpact;
                $dmg = "DamagedByTool";
                break;
        }
        $dcount = abs(intval($draft["Count"]));
        $dweight = abs(floatval($draft["Weight"]));
		$count = abs(intval(RECEIVE("count", $recMethod, $draft["Count"])));
        $weight = abs(floatval(RECEIVE("weight", $recMethod, $draft["Weight"])));
		if($count == 0) $count = $dcount;
		if($weight == 0) $weight = ($count * $dweight) / $dcount;
		if($dcount == $count){
            if(DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status` IN ('Processing', 'Damaged')",
			    [
				    ":ID"=>$value,
                    ":UserGroupID" => $access?$draft["UserGroupID"]:$groupId,
                    ":UserID" => $access?$draft["UserID"]:$userId,
				    ":Count"=>-1 * $dcount,
				    ":Weight"=>-1 * $dweight,
				    ":Status"=>$dmg,
				    ":UpdateTime"=>$datetime
			    ])){
                $averageEffect($imp, $draft["Time"], $dweight, $dcount);
                FLIP(HTML::Warning( "The '".between($draft["Title"], $draft["ID"])."' damaging draft, received successfully!"));
            }
        }
		else{
			$ds = $draft;
            unset($ds["ID"]);
            $ds["ParentID"] = $value;
            $ds["UserGroupID"] = $access?$draft["UserGroupID"]:$groupId;
            $ds["UserID"] = $access?$draft["UserID"]:$userId;
            $ds["Weight"] = -1 * $weight;
            $ds["Count"] = -1 * $count;
            $ds["CreateTime"] = $datetime;
            $ds["UpdateTime"] = $datetime;
            $ds["Status"] = $dmg;
			if(
                DataBase::DoInsert(\_::$CONFIG->DataBasePrefix."Draft", null, $ds)
                && DataBase::DoUpdate(\_::$CONFIG->DataBasePrefix."Draft", "`ID`=:ID AND `Status` IN ('Processing', 'Damaged')",
			[
				":ID"=>$value,
                ":UserGroupID" => $access?$draft["UserGroupID"]:$groupId,
                ":UserID" => $access?$draft["UserID"]:$userId,
				":Count"=>$dcount - $count,
				":Weight"=>$dweight - $weight,
				":UpdateTime"=>$datetime
			])){
                $averageEffect($imp, $draft["Time"], $weight, $count);
                FLIP(HTML::Warning("The '".between($draft["Title"], $draft["ID"])."' damaged draft, registered successfully!"));
            }
        }
		break;
	default:
		SEND(HTML::Error("There a problem is occured!"));
}
SEND(HTML::Error("There a problem is occured!"));
?>