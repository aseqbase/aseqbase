<?php
ACCESS(\_::$CONFIG->AdminAccess);
?>