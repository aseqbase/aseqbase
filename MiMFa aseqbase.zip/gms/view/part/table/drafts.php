<?php
ACCESS(\_::$CONFIG->PersonnelAccess);
MODULE("Table");

use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
use MiMFa\Library\HTML;
use MiMFa\Library\Convert;

$mod = new Table(\_::$CONFIG->DataBasePrefix."Draft");
$access = getAccess(\_::$CONFIG->AdminAccess);
$userId = \_::$INFO->User->ID;
$groupId = \_::$INFO->User->GroupID;

$selectParameters = [];
$road = [];

PART("dbfilters.php");
$mod->SelectQuery = Drafts_Create_Select_Query($selectParameters, $road)." ORDER BY Drafts.UpdateTime DESC";
$mod->SelectParameters = $selectParameters;

$mod->RowLabelsKeys = ["Image", "Title"];
$mod->IncludeColumnKeys = [ "UpdateTime", "Management", "Product", "Count", "Weight", "Status", "Source Unit", "Source Person", "Dest Unit", "Dest Person" ,"Time", "Change Count", "Title", "Description", $mod->ColumnKey, "ParentID", "CreateTime"];
$mod->Controlable =
$mod->Updatable = true;
$mod->UpdateAccess = \_::$CONFIG->PersonnelAccess;
$mod->AddAccess = 100;
$mod->RemoveAccess = \_::$CONFIG->SuperAccess;
$mod->ModifyAccess = \_::$CONFIG->PersonnelAccess;
$mod->ViewAccess = \_::$CONFIG->PersonnelAccess;

$personsId = $mod->Name."_PID";
$targetPersonsId = $mod->Name."_TPID";
$statuses = null;
if(getAccess($mod->RemoveAccess))
    $statuses = ['Transfer'=>'Transfer', 'Processing'=>'Processing',
                'Changed'=>'Changed', 'Completed'=>'Completed', 'Swarfed'=>'Swarfed', 'Damaged'=>'Damaged',
                'DamagedByUnit'=>'DamagedByUnit', 'DamagedByPerson'=>'DamagedByPerson','DamagedByProduct'=>'DamagedByProduct','DamagedByTool'=>'DamagedByTool','Lost'=>'Lost'];
elseif(getAccess(\_::$CONFIG->AdminAccess/2))
    $statuses = ['Transfer'=>'Transfer', 'Processing'=>'Processing',
                'Changed'=>'Changed', 'Completed'=>'Completed', 'Swarfed'=>'Swarfed', 'Damaged'=>'Damaged',
                'DamagedByUnit'=>'DamagedByUnit', 'DamagedByPerson'=>'DamagedByPerson','DamagedByProduct'=>'DamagedByProduct','DamagedByTool'=>'DamagedByTool'];
elseif(getAccess($mod->AddAccess))
    $statuses = ['Transfer'=>'Transfer', 'Processing'=>'Processing',
                'Changed'=>'Changed', 'Completed'=>'Completed', 'Swarfed'=>'Swarfed', 'Damaged'=>'Damaged'];
elseif(getAccess($mod->ModifyAccess))
    $statuses = ['Transfer'=>'Transfer', 'Processing'=>'Processing'];
$users = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
$usergroups = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title");

$mod->CellTypes = [
    "ParentID" => $access? function(){
        $std = new stdClass();
        $std->Title = "Parent";
        $std->Description = "The parent Draft which is related";
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
        $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."Draft", "ID", "CONCAT(`ID`, ' - ', `Title`, ' ', `CreateTime`) AS 'Name'", "`Title` IS NOT NULL ORDER BY `UpdateTime` DESC LIMIT 50");
        return $std;
    }:false,
    "AuthorID"=>$access?function($t, $v) use($users){
        $std = new stdClass();
        $std->Title = "Author";
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
        $std->Options = $users;
        if(!isValid($v)) $std->Value = \_::$INFO->User->ID;
        return $std;
    }:false,
    "EditorID"=>$access?function($t, $v) use($users){
        $std = new stdClass();
        $std->Title = "Editor";
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
        $std->Value = \_::$INFO->User->ID;
        $std->Options = $users;
        return $std;
    }:false,
    "ProductID" => getAccess($mod->AddAccess)? function(){
        $std = new stdClass();
        $std->Title = "Product";
        $std->Description = "The target Product to Process";
        $std->Type = "select";
        $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."Product", "ID", "Title");
        return $std;
    }:false,
    "ToolIDs" => function($t, $v){
        $std = new stdClass();
        $std->Title="Used Tools";
        $std->Description="Indicate all used Tools for this Draft";
        $std->Type="array";
        $std->Options = [
            "type"=>"select", "key"=>"ToolIDs",
            "options"=> DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."Tool", "ID", "Title")
        ];
        return $std;
    },
    "UserGroupID" =>$access? function($t, $v)use($access, $groupId,$personsId,$usergroups){
        $std = new stdClass();
        $std->Title = "Source Unit";
        $std->Description = "Responsible Unit";
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
        $std->Value = $v??($access?$groupId:$v);
        $std->Options = $usergroups;
        //$std->Attributes = ["onchange"=>"postData('/private/get/users.php', 'groupid='+this.value, 'form.form', (data, sel)=>document.getElementById('$personsId').innerHTML = data)"];
        return $std;
    }:false,
    "UserID" => $access? function($t, $v)use($access, $userId,$personsId,$users){
        $std = new stdClass();
        $std->Title = "Source Person";
        $std->Description = "Responsible Person";
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
        $std->Value = $v??($access?$userId:$v);
        $std->Options = $users;
        //$std->Attributes = ["id"=>$personsId];
        return $std;
    }:false,
    "TargetUserGroupID" => function() use($access, $groupId, $usergroups){
        $std = new stdClass();
        $std->Title = "Dest Unit";
        $std->Description = "Target Unit Output";
        $std->Type = "select";
        if($access) {
            $std->Options = $usergroups;
        } else {
            $val = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."UserGroup", "TargetIDs", "`ID`=:ID",[":ID"=>$groupId]);
            $val = isEmpty($val)?[]:json_decode($val);
            $std->Options = array_filter($usergroups, function($v,$k)use($val){ return in_array($k, $val);},ARRAY_FILTER_USE_BOTH);
        }
        return $std;
    },
    "TargetUserID" => function() use($access, $groupId, $users){
        $std = new stdClass();
        $std->Title = "Dest Person";
        $std->Description = "Target Person Output";
        $std->Type = "select";
        if($access) {
            $std->Options = $users;
        } else {
            $val = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."UserGroup", "TargetIDs", "`ID`=:ID",[":ID"=>$groupId]);
            $val = isEmpty($val)?null:"GroupID IN (".join(", ", json_decode($val)).")";
            $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name", $val);
        }
        return $std;
    },
    "Title"=> $access?"text":"disabled",
    "Status"=> $access?  function() use($statuses){
        $std = new stdClass();
        $std->Type = "select";
        $std->Options = $statuses;
        return $std;
    }:false,
    "Image"=>"image",
    "Description"=>"strings",
    "Count"=> $access? function(){
        $std = new stdClass();
        $std->Title = "Numbers ('".\_::$INFO->CountUnit."')";
        $std->Type = "int";
        $std->Description = "Numbers of this Work Pieces ('".\_::$INFO->CountUnit."')";
        return $std;
    }:false,
    "Weight"=> $access? function(){
        $std = new stdClass();
        $std->Title = "Weight ('".\_::$INFO->WeightUnit."')";
        $std->Type = "float";
        $std->Description = "Weight of this Work ('".\_::$INFO->WeightUnit."')";
        return $std;
    }:false,
    "Time"=> $access? function(){
        $std = new stdClass();
        $std->Title = "Time ('".\_::$INFO->TimeUnit."')";
        $std->Description = "Elapsed Time for this Work ('".\_::$INFO->TimeUnit."')";
        return $std;
    }:false,
    "Average"=> getAccess($mod->RemoveAccess)?function(){
        $std = new stdClass();
        $std->Type = "float";
        $std->Attributes = ["min"=>0,"max"=>1];
        return $std;
    }:"disabled",
    "Score"=> getAccess($mod->RemoveAccess)?function(){
        $std = new stdClass();
        $std->Type = "float";
        $std->Attributes = ["min"=>0,"max"=>100];
        return $std;
    }:"disabled",
    "LatestTime"=> false,
    "ChangeCount"=> $access,
    "MetaData"=> getAccess(\_::$CONFIG->AdminAccess)?function(){
        $std = new stdClass();
        $std->Type = "json";
        return $std;
    }:false,
    "CreateTime"=> function($t, $v){
        return getAccess(\_::$CONFIG->SuperAccess)?"calendar":(isValid($v)?"disabled":"hidden");
    },
    "UpdateTime"=>function($t, $v){
        $std = new stdClass();
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"calendar":"disabled";
        $std->Value = \_::$CONFIG->GetFormattedDateTime();
        return $std;
    }
];
$mod->CellValues = [
    "Management"=>function($v, $k, $r)use($access){
        $btns = "";
        switch (getValid($r,"Status"))
        {
            case "Transfer":
                if($access)
                    $btns = HTML::Button(HTML::Image("eye").HTML::Tooltip("To see the details of this Draft!"), "Modal_Management_View($v)", ["style"=>"background-color: var(--Color-5); color: #fefefe;"]).
                    HTML::Button(HTML::Image("check").HTML::Tooltip("I have Received and submitted this draft!"), "Modal_Management_Submit($v)", ["style"=>"background-color: var(--Color-1); color: #fefefe;"]).
                    HTML::Button(HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($v)", ["style"=>"background-color: #ffaa22; color: #fefefe;"]);
                elseif(getValid($r,"IsDestination", "false"))
                    $btns = HTML::Button(HTML::Image("eye").HTML::Tooltip("To see the details of this Draft!"), "Modal_Management_View($v)", ["style"=>"background-color: var(--Color-5); color: #fefefe;"]).
                    HTML::Button(HTML::Image("check").HTML::Tooltip("I have Received and submitted this draft!"), "Modal_Management_Submit($v)", ["style"=>"background-color: var(--Color-1); color: #fefefe;"]);
                else $btns = HTML::Button(HTML::Image("eye").HTML::Tooltip("To see the details of this Draft!"), "Modal_Management_View($v)", ["style"=>"background-color: var(--Color-5); color: #fefefe;"]).
                    HTML::Button(HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($v)", ["style"=>"background-color: #ffaa22; color: #fefefe;"]);
                break;
            case "Processing":
                $btns =
                    HTML::Button(HTML::Image("eye").HTML::Tooltip("To see the details of this Draft!"), "Modal_Management_View($v)", ["style"=>"background-color: var(--Color-5); color: #fefefe;"]).
                    HTML::Button(HTML::Image("forward").HTML::Tooltip("Finished processing and send this draft to the target unit!"), "Modal_Management_Transfer($v)", ["style"=>"background-color: var(--Color-1); color: #fefefe;"]).
                    ($access?HTML::Button(HTML::Image("flag-checkered").HTML::Tooltip("Finished processing and set this draft as completed!"), "Modal_Management_Complete($v)", ["style"=>"background-color: var(--Color-2); color: #fefefe;"]):"").
                    HTML::Button(HTML::Image("pencil").HTML::Tooltip("There had some changes in this draft!"), "Modal_Management_Change($v)", ["style"=>"background-color: var(--Color-3); color: #fefefe;"]).
                    HTML::Button(HTML::Image("recycle").HTML::Tooltip("There made some swarfs in this draft!"), "Modal_Management_Swarf($v)", ["style"=>"background-color: #eeaa11; color: #fefefe;"]).
                    HTML::Button(HTML::Image("warning").HTML::Tooltip("To set this draft as damage!"), "Modal_Management_Damage($v)", ["style"=>"background-color: #ff8811; color: #fefefe;"]);
                break;
            case "Damaged":
                if($access) $btns =
                    HTML::Button(HTML::Image("eye").HTML::Tooltip("To see the details of this Draft!"), "Modal_Management_View($v)", ["style"=>"background-color: var(--Color-5); color: #fefefe;"]).
                    HTML::Button(HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($v)", ["style"=>"background-color: #ff2222; color: #fefefe;"]).
                    HTML::Button("Damaged By Unit", "Modal_Management_Damage($v, null, null, 'damagebyunit')", ["style"=>"background-color: #ff8811;"]).
                    HTML::Button("Damaged By Person", "Modal_Management_Damage($v, null, null, 'damagebyperson')", ["style"=>"background-color: #ff8811;"]).
                    HTML::Button("Damaged By Product", "Modal_Management_Damage($v, null, null, 'damagebyproduct')", ["style"=>"background-color: #ff8811;"]).
                    HTML::Button("Damaged By Tool", "Modal_Management_Damage($v, null, null, 'damagebytool')", ["style"=>"background-color: #ff8811;"]);
                else $btns =
                    HTML::Button(HTML::Image("eye").HTML::Tooltip("To see the details of this Draft!"), "Modal_Management_View($v)", ["style"=>"background-color: var(--Color-5); color: #fefefe;"]).
                    HTML::Button(HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($v)", ["style"=>"background-color: #ff2222; color: #fefefe;"]);
                break;
            case "Swarfed":
            case "Changed":
            case "Lost":
                $btns =
                    HTML::Button(HTML::Image("eye").HTML::Tooltip("To see the details of this Draft!"), "Modal_Management_View($v)", ["style"=>"background-color: var(--Color-5); color: #fefefe;"]).
                    HTML::Button(HTML::Image("close").HTML::Tooltip("Cancel and return to the currentbox!"), "Modal_Management_Return($v)", ["style"=>"background-color: #ff2222; color: #fefefe;"]);
                break;
            default:
                $btns = HTML::Button(HTML::Image("eye").HTML::Tooltip("To see the details of this Draft!"), "Modal_Management_View($v)", ["style"=>"background-color: var(--Color-5); color: #fefefe;"]);
                break;
        }

        switch (getValid($r,"Status"))
        {
            case "Transfer":
                return HTML::Division($btns,["class"=>"management", "style"=>"border-left: 10px solid var(--Color-2);"]);
            case "Changed":
                return HTML::Division($btns,["class"=>"management", "style"=>"border-left: 10px solid var(--Color-3);"]);
            case "Swarfed":
                return HTML::Division($btns,["class"=>"management", "style"=>"border-left: 10px solid #eeaa11;"]);
            case "Damaged":
            case 'DamagedByUnit':
            case 'DamagedByPerson':
            case 'DamagedByProduct':
            case 'DamagedByTool':
                return HTML::Division($btns,["class"=>"management", "style"=>"border-left: 10px solid #ff8811;"]);
            case "Lost":
                return HTML::Division($btns,["class"=>"management", "style"=>"border-left: 10px solid var(--Color-0);"]);
            case "Processing":
                return HTML::Division($btns,["class"=>"management", "style"=>"border-left: 10px solid var(--Color-1);"]);
            case "Completed":
                return HTML::Division($btns,["class"=>"management", "style"=>"border-left: 10px solid var(--Color-4);"]);
            default:
                return HTML::Division($btns,["class"=>"management", "style"=>"border-left: 10px solid transparent;"]);
        }
    },
    $mod->ColumnKey=>function($v, $k, $r)use($mod){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, $mod->ColumnKey,"draft");},
    "ParentID"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "ParentID", "sequence");},
    "Title"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Title", "title");},
    "Description"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Description","description");},
    "Product"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "ProductName","product");},
    "Status"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Status","status");},
    "Count"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Count","count");},
    "Weight"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Weight","weight");},
    "Time"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Time","time");},
    "Source Unit"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "UnitName", "sourceUnit");},
    "Source Person"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Signature", "sourcePerson");},
    "Dest Unit"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "DUnitName", "destUnit");},
    "Dest Person"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "DSignature", "destPerson");},
    "CreateTime"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "CreateTime", "fromTime");},
    "UpdateTime"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "UpdateTime", "toTime");}
];
$updateMethod = $mod->UpdateMethod;

$mod->Draw();
if(!RECEIVE(\_::$CONFIG->ViewHandlerKey, $updateMethod)){
    echo \_::$INFO->GetFilters($road);
    //$mod->DrawModal();
    echo HTML::Style("
        .{$mod->Name} div.management{
            padding: 0px var(--Size-0);
            width: fit-content;
        }
    ");
        echo HTML::Script("
        Modal_Management_Close = function(){
		    {$mod->Modal->HideScript()}
        }
        Modal_Management_View = function(key){
            {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=view&{$mod->ColumnKey}='+key, `main`,
			    (data,selector)=>{
				    {$mod->Modal->ShowScript("null","null","data")}
			    }
		    );
        }
        Modal_Management_Transfer = function(key, unit=null, person=null, weight=null, count=null){
            if(unit==null && person==null) {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=view_transfer&{$mod->ColumnKey}='+key, `main`,
			    (data,selector)=>{
				    {$mod->Modal->ShowScript("null","null","data")}
			    }
		    );
		    else {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=transfer&{$mod->ColumnKey}='+key+`&unit=`+unit+`&person=`+person+`&weight=`+weight+`&count=`+count, `.{$mod->Modal->Name} form .group.buttons`);
        }
        Modal_Management_Submit = function(key){
            {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=submit&{$mod->ColumnKey}='+key, `main`);
        }
        Modal_Management_Return = function(key){
		    ".($mod->SevereSecure?"if(confirm(`".__("Are you sure you want to return this draft to the currentbox?", styling:false)."`))":"")."
                {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=return&{$mod->ColumnKey}='+key, `main`);
        }
        Modal_Management_Complete = function(key){
		    ".($mod->SevereSecure?"if(confirm(`".__("Are you sure you want to set this draft as completed?", styling:false)."`))":"")."
                {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=complete&{$mod->ColumnKey}='+key, `main`);
        }
        Modal_Management_Change = function(key, weight=null, count=null){
            if(weight==null && count==null) {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=view_change&{$mod->ColumnKey}='+key, `main`,
			    (data,selector)=>{
				    {$mod->Modal->ShowScript("null","null","data")}
			    }
		    );
		    else if(count == 0 || count == null ||".($mod->SevereSecure?" confirm(`".__("Are you sure you want to set this draft as lost?", styling:false)."`)":"").")
                {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=change&{$mod->ColumnKey}='+key+`&weight=`+weight+`&count=`+count, `.{$mod->Modal->Name} form .group.buttons`);
        }
        Modal_Management_Swarf = function(key, weight=null){
            if(weight==null) {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=view_swarf&{$mod->ColumnKey}='+key, `main`,
			    (data,selector)=>{
				    {$mod->Modal->ShowScript("null","null","data")}
			    }
		    );
		    else {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=swarf&{$mod->ColumnKey}='+key+`&weight=`+weight, `.{$mod->Modal->Name} form .group.buttons`);
        }
        Modal_Management_Damage = function(key, weight=null, count=null, type='damage'){
            if(weight==null && count==null) {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action=view_'+type+'&{$mod->ColumnKey}='+key, `main`,
			    (data,selector)=>{
				    {$mod->Modal->ShowScript("null","null","data")}
			    }
		    );
		    else ".($mod->SevereSecure?"if(confirm(`".__("Are you sure you want to set this draft as damaged?", styling:false)."`))":"")."
            {$updateMethod}Data('/value/drafts', '".\_::$CONFIG->ViewHandlerKey."=value&action='+type+'&{$mod->ColumnKey}='+key+`&weight=`+weight+`&count=`+count, `.{$mod->Modal->Name} form .group.buttons`);
        }
    ");
}
?>