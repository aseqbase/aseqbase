<?php
ACCESS(\_::$CONFIG->AdminAccess);
use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
MODULE("Table");
$mod = new Table(\_::$CONFIG->DataBasePrefix."Product");
$table1 = \_::$CONFIG->DataBasePrefix."User";
$mod->SelectQuery = "
    SELECT A.{$mod->ColumnKey}, B.Signature, B.Name AS 'Author', A.Name AS 'ProductName', A.Image, A.Title, A.Description, A.UpdateTime
    FROM {$mod->Table} AS A
    LEFT OUTER JOIN $table1 AS B ON A.AuthorID=B.ID;
";
$mod->RowLabelsKeys = ["Image", "Title"];
$mod->IncludeColumnKeys = ["Author", "Image", "Title", "Description", "UpdateTime"];
$mod->Updatable = true;
$mod->UpdateAccess = \_::$CONFIG->AdminAccess;
$access = getAccess(\_::$CONFIG->SuperAccess);
$users =  DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
$mod->CellTypes = [
    "AuthorID"=>$access?function($t, $v) use($users){
        $std = new stdClass();
        $std->Title = "Author";
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
        $std->Options = $users;
        if(!isValid($v)) $std->Value = \_::$INFO->User->ID;
        return $std;
    }:false,
    "ID"=>$access?"disabled":false,
    "TagIDs"=>false,
    "Access"=>function(){
        $std = new stdClass();
        $std->Type="number";
        $std->Attributes=["min"=>\_::$CONFIG->BanAccess,"max"=>\_::$CONFIG->UserAccess];
        return $std;
    },
    "Status"=>false,
    "Image"=>"image",
    "Description"=>"strings",
    "Content"=>"content",
    "MetaData"=> getAccess(\_::$CONFIG->AdminAccess)?function(){
        $std = new stdClass();
        $std->Type = "json";
        return $std;
    }:false,
    "CreateTime"=>function($t, $v){
        return getAccess(\_::$CONFIG->SuperAccess)?"calendar":(isValid($v)?"disabled":"hidden");
    },
    "UpdateTime"=>function($t, $v){
        $std = new stdClass();
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"calendar":"hidden";
        $std->Value = \_::$CONFIG->GetFormattedDateTime();
        return $std;
    }
    ];
$mod->CellValues = [
    "Author"=>function($v, $k, $r){ return \_::$INFO->GetPersonValue($v, $k, $r);},
    "Title"=>function($v, $k, $r){ return \_::$INFO->GetProductValue($v, $k, $r);},
    "CreateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);},
    "UpdateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);}
];
$mod->Draw();
?>