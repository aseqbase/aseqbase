<?php
ACCESS(\_::$CONFIG->AdminAccess);
use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
use MiMFa\Library\HTML;
MODULE("Table");
$mod = new Table(\_::$CONFIG->DataBasePrefix."User");
$table1 = \_::$CONFIG->DataBasePrefix."UserGroup";

PART("dbfilters.php");
$mod->SelectQuery = Users_Create_Select_Query();
$mod->RowLabelsKeys = ["Name", "Unit"];
$mod->ExcludeColumnKeys = ["UnitName", "Signature", "MetaData"];
$mod->Updatable = true;
$mod->UpdateAccess = \_::$CONFIG->AdminAccess;
$mod->CellTypes = [
    "ID"=>"number",
    "GroupID"=> function(){
        $std = new stdClass();
        $std->Title = "Unit";
        $std->Type = "select";
        $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title");
        return $std;
    },
    "Gender"=>["Male"=>"Male","Female"=>"Female","X"=>"X"],
    "Status"=>[-1=>"Blocked",0=>"Deactivated",1=>"Activated"],
    "Image"=>"image",
    "Bio"=>"strings",
    "Contact"=>"tel",
    "Email"=>"email",
    "Password"=>"password",
    "Average"=>getAccess(\_::$CONFIG->SuperAccess)?"float":"disabled",
    "Score"=>getAccess(\_::$CONFIG->AdminAccess)?"float":"disabled",
    "MetaData"=> getAccess(\_::$CONFIG->AdminAccess)?function(){
        $std = new stdClass();
        $std->Type = "json";
        return $std;
    }:false,
    "CreateTime"=>function($t, $v){
        return getAccess(\_::$CONFIG->SuperAccess)?"calendar":(isValid($v)?"disabled":"hidden");
    },
    "UpdateTime"=>function($t, $v){
        $std = new stdClass();
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"calendar":"hidden";
        $std->Value = \_::$CONFIG->GetFormattedDateTime();
        return $std;
    }
];
$mod->CellValues = [
    "Unit"=>function($v, $k, $r){ return \_::$INFO->GetUnitValue($v, $k, $r);},
    "Image"=>function($v, $k, $r){ return \_::$INFO->GetPersonImage($v, $k, $r);},
    "Average"=>function($v, $k, $r){ return round($v*100, \_::$INFO->DecimalPrecision);},
    "Name"=>function($v, $k, $r){ return \_::$INFO->GetPersonValue($v, $k, $r);},
    "CreateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);},
    "UpdateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);}
];

$selector2 = ".FormModal";
$mod->Draw();
echo \_::$TEMPLATE->CreateScoreColorTemplate("$selector2 .header .media", 10);
echo HTML::Script("
    try{
        score = parseFloat($(`$selector2 .content input[name='Average']`).val());
        $(`$selector2 .header .media`).attr('style','border-size: 5px; border-color: ".(\_::$TEMPLATE->CreateScoreColorJS("score","'"))."; outline-color: ".(\_::$TEMPLATE->CreateScoreColorJS("score","'", 0.5)).";');
    }catch{}
");

?>