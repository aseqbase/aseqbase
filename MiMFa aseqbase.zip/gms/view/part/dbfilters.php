<?php

function Units_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"UserGroups.ID=$groupId";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = $ifsource;

    $table = \_::$CONFIG->DataBasePrefix."UserGroup";
    $table1 = \_::$CONFIG->DataBasePrefix."User";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "
        SELECT ".($columns??"
            UserGroups.ID,
            UserGroups.Name AS 'UnitName',
            UserGroups.Title,
            UserGroups.Description,
            UserGroups.Access,
            ROUND(AVG(Users.Average) * 100, ".\_::$INFO->DecimalPrecision.") AS 'Average',
            ROUND(AVG(Users.Score), ".\_::$INFO->DecimalPrecision.")  AS 'Score',
            COUNT(Users.ID) AS 'Users'
        ")."
        FROM $table1 AS Users
        RIGHT OUTER JOIN $table AS UserGroups
        ON UserGroups.ID=Users.GroupID
        GROUP BY UserGroups.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource"));
}

function Users_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $userId = \_::$INFO->User->ID;
    $ifsource = $access?"TRUE":"Users.ID=$userId";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = $ifsource;

    $table = \_::$CONFIG->DataBasePrefix."User";
    $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "
    SELECT
        Users.ID,
        UserGroups.Name AS 'UnitName',
        UserGroups.Title AS 'Unit',
        Users.Image,
        Users.Name,
        Users.Signature,
        Users.Bio,
        Users.Signature,
        Users.Average AS 'Average',
        ROUND(Users.Score, ".\_::$INFO->DecimalPrecision.")  AS 'Score',
        Users.Status,
        Users.CreateTime
    FROM $table AS Users
    LEFT OUTER JOIN $table1 AS UserGroups ON Users.GroupID=UserGroups.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource"));
}

function Tools_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $userId = \_::$INFO->User->ID;
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"(Tools.UserGroupID=$groupId OR Tools.UserID=$userId)";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = $ifsource;

    $table = \_::$CONFIG->DataBasePrefix."Tool";
    $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
    $table2 = \_::$CONFIG->DataBasePrefix."User";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "
    SELECT Tools.Name As 'ToolName', UserGroups.Name As 'UnitName', Users.Signature As 'Signature',
        Tools.ID, UserGroups.Title AS 'Unit', Users.Name AS 'Person', Tools.Image, Tools.Title, Tools.Description,
        GREATEST(0,ROUND((100 * Tools.UsedWorkCount) / Tools.UsageWorkCount, ".\_::$INFO->DecimalPrecision.")) AS 'Used Count (%)',
        GREATEST(0,ROUND((100 * Tools.UsedWorkWeight) / Tools.UsageWorkWeight, ".\_::$INFO->WeightPrecision.")) AS 'Used Weight (%)',
        GREATEST(0,ROUND((100 * Tools.UsedWorkTime) / Tools.UsageWorkTime, ".\_::$INFO->DecimalPrecision.")) AS 'Used Time (%)',
        Tools.UpdateTime
    FROM $table AS Tools
    LEFT OUTER JOIN $table1 AS UserGroups ON Tools.UserGroupID=UserGroups.ID
    LEFT OUTER JOIN $table2 AS Users ON Tools.UserID=Users.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource"));
}

function Drafts_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null, $conditions = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $userId = \_::$INFO->User->ID;
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"((UserGroups.ID=$groupId OR Users.ID=$userId) OR (UserGroups.ID < 1 AND Users.ID < 1))";
    $ifdest = $access?"TRUE":"((TargetUserGroups.ID=$groupId OR TargetUsers.ID=$userId) OR (TargetUserGroups.ID < 1 AND TargetUsers.ID < 1))";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = "($ifsource OR $ifdest)";
    if(!isEmpty($conditions)) $andConditions[] = $conditions;

    $addOrCondition = function($request, $condition) use(&$orConditions, &$selectParameters, &$road){
        if($id = isset($_REQUEST[$request])?getValid($_REQUEST, $request, true):false){
            $road[] = "$request";
            if(is_integer($id)){
                $road[] = "=$id";
                $condition .= " AND (Drafts.ID=:{$request}id OR Drafts.ParentID=:{$request}pid)";
                $selectParameters[":{$request}id"] = $id;
                $selectParameters[":{$request}pid"] = $id;
            }
            $orConditions[] = "($condition)";
        }
    };
    $addAndCondition = function($request, $column) use(&$andConditions, &$selectParameters, &$road){
        if($val = getValid($_REQUEST, $request)){
            $road[] = "$request=$val";
            $selectParameters[":{$request}"] = $val;
            $andConditions[] = "$column=:{$request}";
        }
    };
    $addConditions = function($request, $evaluation, ...$columns) use(&$andConditions, &$orConditions, &$selectParameters, &$road){
        if($val = getValid($_REQUEST, $request)){
            $road[] = "$request=$val";
            $iconditions = [];
            foreach ($columns as $column)
            {
                $req = $request.getId();
                $selectParameters[":{$req}"] = $val;
                $iconditions[] = "$column{$evaluation}:{$req}";
            }
            $andConditions[] = "(".join(" OR ", $iconditions).")";
        }
    };

    $addOrCondition("outbox", "($ifsource) AND Drafts.Status='Transfer'");
    $addOrCondition("inbox", "($ifdest) AND Drafts.Status='Transfer'");
    $addOrCondition("currentbox", "($ifsource OR $ifdest) AND Drafts.Status IN ('Transfer', 'Processing')");
    $addOrCondition("failbox", "($ifsource) AND (Drafts.Status IN ('Lost', 'Swarfed') OR Drafts.Status LIKE 'Damaged%')");
    $addOrCondition("completebox", "($ifsource) AND Drafts.Status='Completed'");
    $addOrCondition("addbox", "($ifsource) AND Drafts.Status='Changed' AND (Drafts.Weight>0 OR Drafts.Count>0)");
    $addOrCondition("subtractbox", "($ifsource) AND Drafts.Status='Changed' AND (Drafts.Weight<0 OR Drafts.Count<0)");

    $addAndCondition("sequence", "Drafts.ParentID");
    $addAndCondition("status", "Drafts.Status");
    $addAndCondition("title", "Drafts.Title");
    $addAndCondition("count", "Drafts.Count");
    $addAndCondition("weight", "Drafts.Weight");
    $addAndCondition("time", "Drafts.Time");
    $addAndCondition("description", "Drafts.Description");
    $addAndCondition("product", "Products.Name");
    $addAndCondition("sourceUnit", "UserGroups.Name");
    $addAndCondition("sourcePerson", "Users.Signature");
    $addAndCondition("destUnit", "TargetUserGroups.Name");
    $addAndCondition("destPerson", "TargetUsers.Signature");

    $addConditions("draft", "=", "Drafts.ID", "Drafts.ParentID");
    $addConditions("fromTime", ">=", "Drafts.UpdateTime", "Drafts.CreateTime");
    $addConditions("toTime", "<=", "Drafts.UpdateTime", "Drafts.CreateTime");
    $addConditions("unit", "=", "UserGroups.Name", "TargetUserGroups.Name");
    $addConditions("user", "=", "Users.Signature", "TargetUsers.Signature");

    $table = \_::$CONFIG->DataBasePrefix."Draft";
    $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
    $table2 = \_::$CONFIG->DataBasePrefix."User";
    $table3 = \_::$CONFIG->DataBasePrefix."Product";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "
    SELECT
        ".($columns??"UserGroups.Name AS 'UnitName',
        Users.Signature AS 'Signature',
        TargetUserGroups.Name AS 'DUnitName',
        TargetUsers.Signature AS 'DSignature',
        Products.Name AS 'ProductName',
        IF($ifsource,TRUE,FALSE) AS 'IsSource',
        IF($ifdest,TRUE,FALSE) AS 'IsDestination',
        Drafts.ID AS Management,
        Drafts.ID,
        Drafts.ParentID,
        Products.Title AS 'Product',
        UserGroups.Title AS 'Source Unit',
        Users.Name AS 'Source Person',
        TargetUserGroups.Title AS 'Dest Unit',
        TargetUsers.Name AS 'Dest Person',
        Drafts.Title,
        Drafts.Description,
        Drafts.Status,
        Drafts.Image,
        Drafts.Count,
        Drafts.Weight,
        Drafts.Time,
        Drafts.ChangeCount AS 'Change Count',
        Drafts.UpdateTime,
        Drafts.CreateTime")."
    FROM $table AS Drafts
    LEFT OUTER JOIN $table1 AS UserGroups ON Drafts.UserGroupID=UserGroups.ID
    LEFT OUTER JOIN $table2 AS Users ON Drafts.UserID=Users.ID
    LEFT OUTER JOIN $table1 AS TargetUserGroups ON Drafts.TargetUserGroupID=TargetUserGroups.ID
    LEFT OUTER JOIN $table2 AS TargetUsers ON Drafts.TargetUserID=TargetUsers.ID
    LEFT OUTER JOIN $table3 AS Products ON Drafts.ProductID=Products.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource OR $ifdest"));
}

function Drafts_Create_Trace_Query(&$selectParameters=[], &$road=null, $columns = null, $conditions = null){
    return Drafts_Create_Select_Query($selectParameters, $road, $columns??"
        UserGroups.Name AS 'UnitName',
        Users.Signature AS 'Signature',
        TargetUserGroups.Name AS 'DUnitName',
        TargetUsers.Signature AS 'DSignature',
        Products.Name AS 'ProductName',
        Drafts.ID,
        Drafts.ParentID,
        Users.ID AS 'UserID',
        TargetUsers.ID AS 'TargetUserID',
        UserGroups.ID AS 'UserGroupID',
        TargetUserGroups.ID AS 'TargetUserGroupID',
        Products.Title AS 'Product',
        UserGroups.Title AS 'Source Unit',
        Users.Name AS 'Source Person',
        TargetUserGroups.Title AS 'Dest Unit',
        TargetUsers.Name AS 'Dest Person',
        Drafts.Title,
        Drafts.Status,
        Drafts.Count,
        Drafts.Weight,
        Drafts.Time,
        Drafts.ChangeCount AS 'Change Count',
        Drafts.UpdateTime,
        Drafts.CreateTime", $conditions);
}
?>