<?php
if(RECEIVE(null,"post") || RECEIVE(\_::$CONFIG->ViewHandlerKey)) return;
ACCESS(\_::$CONFIG->PersonnelAccess);
use MiMFa\Library\DataBase;
use MiMFa\Library\HTML;
$selectParameters = [];
$road = [];

PART("dbfilters.php");
$selectQuery = Drafts_Create_Select_Query($selectParameters, $road, columns:"Drafts.Weight, Drafts.Time, Drafts.Status, Drafts.UpdateTime")." ORDER BY Drafts.UpdateTime";
$drafts = DataBase::Select($selectQuery, $selectParameters);
$statuses = [];
foreach ($drafts as $value){
    $k = $value["Status"];
    if($k == "Changed"){
            $v = first($value);
            if($v<0) $k = "Subtracted";
            elseif($v>0) $k = "Added";
            else $k = "Changed";
            if(isset($statuses[$k]))
                $statuses[$k] += $v;
            else $statuses[$k] = $v;
    }elseif(startsWith($k,"Damaged"))
        if(isset($statuses[$k]))
            $statuses["Damaged"] += first($value);
        else $statuses["Damaged"] = first($value);
    elseif(isset($statuses[$k]))
        $statuses[$k] += first($value);
    else $statuses[$k] = first($value);
}
foreach ($statuses as $k=>$v){
    $c = "#888888";
    switch($k){
        case "Changed":
            $c = "#888888";
            break;
        case "Swarfed":
            $c = "#eeaa11";
            break;
        case "Added":
            $c = "#dd33dd";
            break;
        case "Subtracted":
            $c = "#dd3333";
            break;
        case "Lost":
            $c = "#ff2222";
            break;
        case 'Transfer':
            $c = "#22dd99";
            break;
        case 'Processing':
            $c = "#22dd22";
            break;
        case 'Done':
            $c = "#22dddd";
            break;
        case 'Completed':
            $c = "#3333dd";
            break;
        case 'Damaged':
        case 'DamagedByUnit':
        case 'DamagedByPerson':
        case 'DamagedByProduct':
        case 'DamagedByTool':
            $c = "#ff8811";
            break;
        default:
            $c = "#888888";
            break;
    }
    $statuses[$k] = "$v, label:`".__($k, styling:false)."`, color:`$c`, indexLabelFontColor:`$c`";
}

$attrs = ["class"=>"chart-report"];
$options = "";

echo HTML::Style("
.chart-report{
    margin: var(--Size-1);
}
");

echo HTML::LargeRack([
    HTML::Chart(
        type:"doughnut",
        content:loop($statuses, function($k,$v){ if($k == "Done") return null; else return $v; }, nullValues:false),
        //title:"Weight Status",
        axisXTitle:"Status",
        axisYTitle:"Weight",
        foreColor:\_::$TEMPLATE->ForeColor(0),
        backColor:"transparent",
        font:\_::$TEMPLATE->Font(0),
        options:$options,
        attributes:$attrs
    ),
    HTML::Chart(
        type:"column",
        content:loop($drafts, function($k,$v,$i){ if(count($v)>0) return [$i/*"(new Date(`".last($v)."`))"*/,$v["Weight"]];}, nullValues:false),
        title:"Weight Sequences",
        axisXBegin:0,
        axisXInterval:1,
        axisXTitle:"Order",
        axisYTitle:"Weight",
        color:"#dd22dd",
        foreColor:\_::$TEMPLATE->ForeColor(0),
        backColor:"transparent",
        font:\_::$TEMPLATE->Font(0),
        options:$options,
        attributes:$attrs
    )
]).
    HTML::Chart(
        type:"splineArea",
        content:loop($drafts, function($k,$v,$i){ if(count($v)>1) return [$i/*"(new Date(`".last($v)."`))"*/,$v["Time"]];}, nullValues:false),
        title:"Time Sequences",
        axisXBegin:0,
        axisXInterval:1,
        axisXTitle:"Order",
        axisYTitle:"Time",
        color:"#22dddd",
        foreColor:\_::$TEMPLATE->ForeColor(0),
        backColor:"transparent",
        font:\_::$TEMPLATE->Font(0),
        options:$options,
        attributes:$attrs
    );
?>