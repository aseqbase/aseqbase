<?php
if(RECEIVE(null,"post") || RECEIVE(\_::$CONFIG->ViewHandlerKey)) return;
ACCESS(\_::$CONFIG->PersonnelAccess);
use MiMFa\Library\DataBase;
use MiMFa\Library\HTML;
$selectParameters = [];
$road = [];

PART("dbfilters.php");
$selectQuery = Tools_Create_Select_Query($selectParameters, $road);
$report = DataBase::Select($selectQuery, $selectParameters);

$attrs = ["class"=>"chart-report"];
$options = "";

echo HTML::Style("
.chart-report{
    margin: var(--Size-1);
}
");

echo
    HTML::Chart(
        type:"column",
        content:loop($report,
            function($k,$v,$i){
                if($v["Used Count (%)"])
                    return "{$v["Used Count (%)"]}, label:`{$v["Title"]}`";
            }, nullValues:false),
        title:"Tools Count",
        axisXBegin:0,
        axisXInterval:1,
        axisXTitle:"Tools",
        axisYTitle:"Used Count",
        color:"#2222dd",
        foreColor:\_::$TEMPLATE->ForeColor(0),
        backColor:"transparent",
        font:\_::$TEMPLATE->Font(0),
        options:$options,
        attributes:$attrs
    ).
    HTML::Chart(
        type:"column",
        content:loop($report,
            function($k,$v,$i){
                if($v["Used Weight (%)"])
                    return "{$v["Used Weight (%)"]}, label:`{$v["Title"]}`";
            }, nullValues:false),
        title:"Tools Weight",
        axisXBegin:0,
        axisXInterval:1,
        axisXTitle:"Tools",
        axisYTitle:"Used Weight",
        color:"#22dd22",
        foreColor:\_::$TEMPLATE->ForeColor(0),
        backColor:"transparent",
        font:\_::$TEMPLATE->Font(0),
        options:$options,
        attributes:$attrs
    ).
    HTML::Chart(
        type:"column",
        content:loop($report,
            function($k,$v,$i){
                if($v["Used Time (%)"])
                    return "{$v["Used Time (%)"]}, label:`{$v["Title"]}`";
            }, nullValues:false),
        title:"Tools Time",
        axisXBegin:0,
        axisXInterval:1,
        axisXTitle:"Tools",
        axisYTitle:"Used Time",
        color:"#dddd22",
        foreColor:\_::$TEMPLATE->ForeColor(0),
        backColor:"transparent",
        font:\_::$TEMPLATE->Font(0),
        options:$options,
        attributes:$attrs
    );
?>