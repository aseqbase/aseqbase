<?php
ACCESS(\_::$CONFIG->AdminAccess);
MODULE("Table");
MODULE("Collection");

use MiMFa\Module\Table;
use MiMFa\Module\Collection;
use MiMFa\Library\DataBase;
use MiMFa\Library\HTML;

$road = [];
$collection = new Collection();
$collection->MaximumColumns = 3;
$collection->Class = "container-fluid";
echo HTML::Style("
    .{$collection->Name} .header{
        text-align: center;
        margin-bottom: 2vmax;
    }
    .{$collection->Name} :is(h3, h4){
        text-align: initial;
        padding: 0px !important;
        margin: 0px !important;
    }
    .{$collection->Name} .header .media{
        display: inline-block;
        min-width: 75px;
    }
");
$cellValues = [
    "ID"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "ID","draft");},
    "ParentID"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "ParentID", "sequence");},
    "Title"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Title", "title");},
    "Description"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Description","description");},
    "Product"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "ProductName","product");},
    "Status"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Status","status");},
    "Count"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Count","count");},
    "Weight"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Weight","weight");},
    "Time"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Time","time");},
    "Source Unit"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "UnitName", "sourceUnit");},
    "Source Person"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Signature", "sourcePerson");},
    "Dest Unit"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "DUnitName", "destUnit");},
    "Dest Person"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "DSignature", "destPerson");},
    "CreateTime"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "CreateTime", "fromTime");},
    "UpdateTime"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "UpdateTime", "toTime");}
];
$gettable = function() use($cellValues){
    $mod = new Table();
    $mod->Controlable =
    $mod->Updatable =
    $mod->AllowEntriesInfo =
    $mod->AllowSearching =
    $mod->AllowCache =
    $mod->AllowPaging =
        false;
    $mod->CellValues = $cellValues;
    $mod->RowLabelsKeys = ["Title"];
    $mod->ColumnKeysAsLabels = true;
    $mod->Options[] = "'columnDefs': [{ 'targets': 0, 'orderable': false }]";
    return $mod;
};
$getsamplerow = function($title, $rows){
    if(isset($rows->Items[$title]) && !is_null($rows->Items[$title])) return $rows->Items[$title];
    return $rows->Items[$title] = [
        "Title" => $title,
        "Count" => 0,
        "Weight" => 0,
        "Time" => 0,
        "Change" => 0
    ];
};
$totalTable = $gettable();
//foreach ($totalTable->Items as $k=>$v)
//    $totalTable->Items[$k] = $getsamplerow($k, $totalTable);

$collection->Items = [];
PART("dbfilters.php");
$persons = DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."User","`ID`, `GroupID`, `Name`, `Bio`, `Image`, `Average`", \_::$INFO->TraceManagers? null: "`GroupID` >= 10 ORDER BY GroupID");
foreach ($persons as $user) {
    $uid = $user["ID"];
    $gid = $user["GroupID"];
    $inputreport = ["Count"=>0,"Weight"=>0];
    $currentreport = ["Count"=>0,"Weight"=>0];
    $outputreport = ["Count"=>0,"Weight"=>0];
    $selectParameters = [];
    $selectQuery = Drafts_Create_Trace_Query($selectParameters, $road, conditions:"((Users.ID=$uid OR TargetUsers.ID=$uid) OR (UserGroups.ID=$gid OR TargetUserGroups.ID=$gid))")." ORDER BY UserGroups.ID, TargetUserGroups.ID, Drafts.CreateTime ASC";
    $items = DataBase::Select($selectQuery, $selectParameters);

    $mod = $gettable();
    $mod->Items = [
        "Received" => null,
        "Processing" => null,
        "Transfering" => null,
        "Completed" => null,
        "Sent" => null,
        "Added" => null,
        "Subtracted" => null,
        "Swarfed" => null,
        "Damaged" => null,
        "Lost" => null
    ];

    foreach ($items as $item){
        if($item["Status"] == "Done" && ($item["TargetUserID"] == $uid || (isEmpty($item["TargetUserID"]) && $item["TargetUserGroupID"] == $gid))){
            $row = $getsamplerow("Received", $mod);
            $row["Count"] += $item["Count"];
            $row["Weight"] += $item["Weight"];
            $row["Time"] += $item["Time"];
            $row["Change"]++;
            $mod->Items["Received"] = $row;
            $inputreport["Count"] += $item["Count"];
            $inputreport["Weight"] += $item["Weight"];
        }
        elseif($item["Status"] == "Processing" && ($item["UserID"] == $uid || (isEmpty($item["UserID"]) && $item["UserGroupID"] == $gid))){
            $row = $getsamplerow("Processing", $mod);
            $row["Count"] += $item["Count"];
            $row["Weight"] += $item["Weight"];
            $row["Time"] += $item["Time"];
            $row["Change"]++;
            $mod->Items["Processing"] = $row;
            $currentreport["Count"] += $item["Count"];
            $currentreport["Weight"] += $item["Weight"];
        }
        elseif($item["Status"] != "Processing" && ($item["UserID"] == $uid || (isEmpty($item["UserID"]) && $item["UserGroupID"] == $gid))){
            $status = $item["Status"];
            $c = $item["Count"];
            $w = $item["Weight"];
            switch (strtolower($status))
            {
                case "completed":
                case "complete":
                    $status = "Completed";
                    break;
                case "done":
                    $status = "Sent";
                    break;
                case "transfer":
                case "transfering":
                case "transfered":
                    $status = "Transfering";
                    break;
                case "swarf":
                case "swarfed":
                    $status = "Swarfed";
                    $c = -$c;
                    $w = -$w;
                    break;
                case "lost":
                    $status = "Lost";
                    $c = -$c;
                    $w = -$w;
                    break;
                case "change":
                case "changed":
                    if($item["Weight"] > 0) $status = "Added";
                    else $status = "Subtracted";
                    $c = -$c;
                    $w = -$w;
                    break;
                case "damage":
                case 'damagebyunit':
                case 'damagebyperson':
                case 'damagebyproduct':
                case 'damagebytool':
                case "damaged":
                case 'damagedbyunit':
                case 'damagedbyperson':
                case 'damagedbyproduct':
                case 'damagedbytool':
                    $status = "Damaged";
                    $c = abs($c);
                    $w = abs($w);
                    break;
            }
            if(isValid($status)){
                $row = $getsamplerow($status, $mod);
                $row["Count"] += $item["Count"];
                $row["Weight"] += $item["Weight"];
                $row["Time"] += $item["Time"];
                $row["Change"]++;
                $mod->Items[$status] = $row;
                $outputreport["Count"] += $c;
                $outputreport["Weight"] += $w;
            }
        }
    }


    foreach ($mod->Items as $k=>$v)
        if(is_null($v)) unset($mod->Items[$k]);
        elseif(isset($totalTable->Items[$k]))
            foreach ($v as $sk=>$sv){
                if(is_numeric($sv)) $totalTable->Items[$k][$sk] += $sv;
            }
        else $totalTable->Items[$k] = $v;

    $group = first(DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."UserGroup", "`Title`,`HasCountError`,`HasWeightError`","`ID`=$gid"));
    $ct = getValid($group, "HasCountError", 0)>0?(($currentreport["Count"] + $outputreport["Count"]) - $inputreport["Count"]):0;
    $wt = getValid($group, "HasWeightError", 0)>0?round(($currentreport["Weight"] + $outputreport["Weight"]) - $inputreport["Weight"],\_::$INFO->WeightPrecision):0;
    $id = "p_".getId();
    $collection->Items[] = [
        "Description"=>
            HTML::Rack(
                (isValid($user["Image"])?HTML::Slot(HTML::Media(null,$user["Image"],["id"=>$id, "style"=>"aspect-ratio: 1; min-height: 100%; max-width: 150px;"]), ["class"=>"col-lg-4 header"]):"").
                HTML::LargeSlot(
                    HTML::Heading(getValid($group, "Title").":").
                    HTML::SubHeading($user["Name"]).
                    HTML::Paragraph($user["Bio"]).
                    HTML::Paragraph(\_::$INFO->GetContradiction($ct, $wt), null ,["class"=>"error"]). \_::$TEMPLATE->CreateScoreColorTemplate("#$id", 5, score:$user["Average"])
                )
            ,["style"=>"text-align: center;"]).
            (count($mod->Items)>0?$mod->Capture():"")
        ];
}
$totalTable->Style = new \MiMFa\Library\Style();
$totalTable->Style->Width = "auto";
echo HTML::Division(
        HTML::Heading("Total").
        (count($totalTable->Items)>0?$totalTable->Capture():"")
    ,["style"=>"
        text-align: center;
        display: flex;
        align-content: space-around;
        align-items: center;
        flex-wrap: wrap;
        flex-direction: column;
        justify-content: space-evenly;
    "]).
    HTML::$NewLine.
    HTML::$HorizontalBreak.
    HTML::$NewLine;
$collection->Draw();
echo \_::$INFO->GetFilters($road);
?>