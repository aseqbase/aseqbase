<?php
ACCESS(\_::$CONFIG->AdminAccess);
MODULE("Table");

use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
use MiMFa\Library\HTML;

$access = getAccess(\_::$CONFIG->AdminAccess);
$userId = \_::$INFO->User->ID;
$groupId = \_::$INFO->User->GroupID;

$cellValues = [
    "ID"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "ID","draft");},
    "ParentID"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "ParentID", "sequence");},
    "Title"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Title", "title");},
    "Description"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Description","description");},
    "CreateTime"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "CreateTime", "fromTime");},
    "UpdateTime"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "UpdateTime", "toTime");},
    "Product"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "ProductName","product");},
    "Status"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Status","status");},
    "Count"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Count","count");},
    "Weight"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Weight","weight");},
    "Time"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Time","time");},
    "Source Unit"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "UnitName", "sourceUnit");},
    "Source Person"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "Signature", "sourcePerson");},
    "Dest Unit"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "DUnitName", "destUnit");},
    "Dest Person"=>function($v, $k, $r){ return \_::$INFO->GetDraftFilterValue($v, $k, $r, "DSignature", "destPerson");}
];
echo HTML::Style("
.stickyHeading{
    position: sticky;
    top: 0px;
    margin-bottom: 0px;
}
h3.stickyHeading{
    background-color: var(--BackColor-1);
    color: var(--ForeColor-1);
    top: 0px;
    z-index: 2;
}
h4.stickyHeading{
    text-shadow: 0px 0px 5px var(--BackColor-1);
    color: var(--ForeColor-1);
    top: var(--Size-3);
    z-index: 1;
    padding: calc(var(--Size-0) / 2);
    margin-top: 0px;
}");
$road = [];
PART("dbfilters.php");
$persons = DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."User","`ID`, `GroupID`, `Name`", \_::$INFO->TraceManagers? null: "`GroupID` >= 10 ORDER BY GroupID");
foreach ($persons as $user)
{
    $uid = $user["ID"];
    $gid = $user["GroupID"];
    $input = $current = $output = "";
    $inputreport = ["Count"=>0,"Weight"=>0,"Time"=>0];
    $currentreport = ["Count"=>0,"Weight"=>0,"Time"=>0];
    $outputreport = ["Count"=>0,"Weight"=>0,"Time"=>0, "Change"=>0];
    $selectParameters = [];
    $selectQuery = Drafts_Create_Trace_Query($selectParameters, $road, conditions:"((Users.ID=$uid OR TargetUsers.ID=$uid) OR (UserGroups.ID=$gid OR TargetUserGroups.ID=$gid))")." ORDER BY UserGroups.ID, TargetUserGroups.ID, Drafts.CreateTime ASC";
    $items = DataBase::Select($selectQuery, $selectParameters);
    {
        $mod = new Table();
        $mod->Controlable =
        $mod->Updatable =
        $mod->AllowEntriesInfo =
        $mod->AllowSearching =
        $mod->AllowCache =
        $mod->AllowPaging =
            false;
        $mod->CellValues = $cellValues;

        $mod->Items = [];
        foreach ($items as $item)
            if($item["Status"] == "Done" && ($item["TargetUserID"] == $uid || (isEmpty($item["TargetUserID"]) && $item["TargetUserGroupID"] == $gid))){
                $row = [];
                $row["Count"] = $item["Count"];
                $row["Weight"] = $item["Weight"];
                $row["Time"] = $item["Time"];
                $row["Status"] = $item["Status"];
                $row["Product"] = $item["Product"];
                $row["Source Unit"] = $item["Source Unit"];
                $row["Source Person"] = $item["Source Person"];
                $row["CreateTime"] = $item["CreateTime"];
                $inputreport["Count"] += $row["Count"];
                $inputreport["Weight"] += $row["Weight"];
                $inputreport["Time"] += $row["Time"];
                $mod->Items[] = $row;
            }
        if(count($mod->Items)>0){
            $row = [];
            foreach ($mod->Items[0] as $k=>$v)
                $row[$k] = getValid($inputreport,$k,null);
            $mod->Items[] = $row;
        }
        $input = $mod->Capture();
    }
    {
        $mod = new Table();
        $mod->Controlable =
        $mod->Updatable =
        $mod->AllowEntriesInfo =
        $mod->AllowSearching =
        $mod->AllowCache =
        $mod->AllowPaging =
            false;
        $mod->CellValues = $cellValues;

        $mod->Items = [];
        foreach ($items as $item)
            if($item["Status"] == "Processing" && ($item["UserID"] == $uid || (isEmpty($item["UserID"]) && $item["UserGroupID"] == $gid))){
                $row = [];
                $row["Count"] = $item["Count"];
                $row["Weight"] = $item["Weight"];
                $row["Time"] = $item["Time"];
                $row["Status"] = $item["Status"];
                $row["Product"] = $item["Product"];
                $row["Source Unit"] = $item["Source Unit"];
                $row["Source Person"] = $item["Source Person"];
                $row["CreateTime"] = $item["CreateTime"];
                $currentreport["Count"] += $row["Count"];
                $currentreport["Weight"] += $row["Weight"];
                $currentreport["Time"] += $row["Time"];
                $mod->Items[] = $row;
            }
        if(count($mod->Items)>0){
            $row = [];
            foreach ($mod->Items[0] as $k=>$v)
                $row[$k] = getValid($currentreport,$k,null);
            $mod->Items[] = $row;
        }
        $current = $mod->Capture();
    }
    {
        $mod = new Table();
        $mod->Controlable =
        $mod->Updatable =
        $mod->AllowEntriesInfo =
        $mod->AllowSearching =
        $mod->AllowCache =
        $mod->AllowPaging =
            false;
        $mod->CellValues = $cellValues;
        $mod->Items = [];
        foreach ($items as $item)
            if($item["Status"] != "Processing" && ($item["UserID"] == $uid || (isEmpty($item["UserID"]) && $item["UserGroupID"] == $gid))){
                $row = [];
                $row["Count"] = $item["Count"];
                $row["Weight"] = $item["Weight"];
                $row["Time"] = $item["Time"];
                $row["Status"] = $item["Status"];
                $row["Product"] = $item["Product"];
                $row["Change"] = $item["Change Count"];
                $row["Dest Unit"] = $item["Dest Unit"];
                $row["Dest Person"] = $item["Dest Person"];
                $row["CreateTime"] = $item["CreateTime"];
                switch ($item["Status"])
                {
                	case "Changed":
                	case "Swarfed":
                	case "Lost":
                        $outputreport["Count"] += -$row["Count"];
                        $outputreport["Weight"] += -$row["Weight"];
                        break;
                	default:
                        if(startsWith($item["Status"],"Damage")){
                            $outputreport["Count"] += abs($row["Count"]);
                            $outputreport["Weight"] += abs($row["Weight"]);
                        }
                        else {
                            $outputreport["Count"] += $row["Count"];
                            $outputreport["Weight"] += $row["Weight"];
                        }
                        break;
                }
                $outputreport["Time"] += $row["Time"];
                $outputreport["Change"] = $row["Change"];
                $mod->Items[] = $row;
            }
        if(count($mod->Items)>0){
            $row = [];
            foreach ($mod->Items[0] as $k=>$v)
                $row[$k] = getValid($outputreport,$k,null);
            $mod->Items[] = $row;
        }
        $output = $mod->Capture();
    }
    $group = first(DataBase::DoSelect(\_::$CONFIG->DataBasePrefix."UserGroup", "`Title`,`HasCountError`,`HasWeightError`","`ID`=$gid"));
    $ct = getValid($group, "HasCountError", 0)>0?(($currentreport["Count"] + $outputreport["Count"]) - $inputreport["Count"]):0;
    $wt = getValid($group, "HasWeightError", 0)>0?round(($currentreport["Weight"] + $outputreport["Weight"]) - $inputreport["Weight"],\_::$INFO->WeightPrecision):0;
    echo HTML::Frame(
        HTML::Heading(
            HTML::Strong(getValid($group, "Title").":").$user["Name"]
            ,null, ["class"=>"stickyHeading"]
        ).
        HTML::Center(\_::$INFO->GetContradiction($ct, $wt) ,["class"=>"error"])
        .
        HTML::Rack(
            HTML::MediumSlot(HTML::SubHeading("Input", null, ["class"=>"stickyHeading"]).$input, ["class"=>"col-md-4"]).
            HTML::MediumSlot(HTML::SubHeading("Current", null, ["class"=>"stickyHeading"]).$current, ["class"=>"col-md-4"]).
            HTML::MediumSlot(HTML::SubHeading("Output", null, ["class"=>"stickyHeading"]).$output, ["class"=>"col-md-4"])
        )
    );
}
echo \_::$INFO->GetFilters($road);
?>