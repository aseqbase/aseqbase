<?php
PART("sign/view", fromSeq:1);
echo \_::$TEMPLATE->CreateScoreColorTemplate(".page .header .media", 15);
?>