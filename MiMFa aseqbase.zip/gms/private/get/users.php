<?php
use \MiMFa\Library\DataBase;
$gid = $_POST["groupid"];
if(empty($gid)) return;
echo json_encode(DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name", "`GroupID`=:gid",[":gid"=>$gid]));
?>