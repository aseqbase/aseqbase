<?php
class Configuration extends ConfigurationBase {
    //public $Encoding = "utf-8";
    public $DateTimeZone = "Asia/Tehran";
    /**
     * Date Time Stamp Seconds Offset (TSO)
     * @var int
     * @category General
     */
    public $TimeStampOffset = -19603974600;
    //public $SecretKey = '~a!s@e#q$b%a^s&e*';
    //public $DisplayError = 1;
    //public $DisplayStartupError = 1;
    //public $ReportError = E_ALL;
    //public $DataBaseError = 1;

    //public $AllowCache = false;
    //public $AllowReduceSize = true;
    //public $AllowEncryptNames = true;

    ///**
    // * The status of all server response: 400, 404, 500, etc.
    // * @var mixed
    // */
    //public $StatusMode = null;
    ///**
    // * The accessibility mode: 1 for whitelisted IPs, -1 for blacklisted IPs
    // * @var mixed
    // */
    //public $AccessMode = 0;
    //public $AccessPatterns = array();
    //public $RestrictionContent = "Unfortunately, you have no access to the site now!<br>Please try a few minutes later...";
    public $UserAccess = 1000000000;
    public $PersonnelAccess = 999999999;
    public $VisitAccess = 999999999;
    public $AllowSigning = true;
    //public $AllowCache = false;
	public $AllowTranslate = true;
	public $DefaultLanguage = null;
    public $DefaultDirection = null;

    //public $DataBaseEncoding = "utf8";
    //public $DataBaseType = 'mysql';
    //public $DataBaseHost = 'localhost';
    //public $DataBaseUser = null;
    //public $DataBasePassword = null;
    //public $DataBaseName = 'localhost';
    //public $DataBasePrefix = 'aseq_';
    //public $DataBaseAddNameToPrefix = false;

    public function __construct(){
        parent::__construct();
        $this->Handlers["/^users(\/|\?|$)/i"] = "users";
        $this->Handlers["/^units(\/|\?|$)/i"] = "units";
        $this->Handlers["/^products(\/|\?|$)/i"] = "products";
        $this->Handlers["/^tools(\/|\?|$)/i"] = "tools";
        $this->Handlers["/^drafts(\/|\?|$)/i"] = "drafts";
    }
}
?>