<?php
RUN("AseqTemplate");
class Template extends AseqTemplate {
}
?>