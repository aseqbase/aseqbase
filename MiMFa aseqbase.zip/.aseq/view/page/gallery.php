<?php
	MODULE("PrePage");
	$module = new MiMFa\Module\PrePage();
	$module->Title = "Gallery";
	$module->Draw();

	PART("gallery");
?>

