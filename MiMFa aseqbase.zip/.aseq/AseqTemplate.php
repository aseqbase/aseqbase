<?php
class AseqTemplate extends TemplateBase {
}
?>