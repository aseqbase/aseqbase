<?php
RUN("AseqInformation");
class Information extends AseqInformation{
}
?>