<?php
use \MiMFa\Library\HTML;
    echo HTML::Button("Next (Database)", "/install/database.php");
?>