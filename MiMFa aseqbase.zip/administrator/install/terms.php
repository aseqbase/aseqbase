<?php
use \MiMFa\Library\HTML;
    echo HTML::Button("Finish", "/install/installation.php");
?>