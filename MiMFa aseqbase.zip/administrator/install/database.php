<?php
use \MiMFa\Library\HTML;
    echo HTML::Button("Confirm all terms and START installation!");
?>