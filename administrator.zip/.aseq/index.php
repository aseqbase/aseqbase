<?php //MiMFa aseqbase	http://aseqbase.ir
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//ini_set('display_startup_errors', E_ALL);
require_once(__DIR__."/initialize.php");
require_once($GLOBALS["BASE_DIR"]."index.php");
?>