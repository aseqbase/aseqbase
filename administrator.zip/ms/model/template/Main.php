<?php
namespace MiMFa\Template;
use MiMFa\Library\HTML;
TEMPLATE("General");
class Main extends General{
	public $AllowTopMenu = true;
	public $AllowSideMenu = true;
	public $AllowBarMenu = true;

	public function DrawInitial(){
		parent::DrawInitial();
        echo HTML::Style("
            body {
                background-color: var(--BackColor-1);
            }
            main {
                width: calc(100% - 8vmin) !important;
                background-color: var(--BackColor-0);
                color: var(--ForeColor-0);
                padding: var(--Size-0) 0px;
                margin: 2vmin 4vmin 4vmin;
            }
            footer {
                background-color: var(--BackColor-2);
                color: var(--ForeColor-2);
                padding-bottom: var(--Size-5);
                margin-bottom: calc(-1 * var(--Size-4));
                box-shadow: var(--Shadow-5);
            }
        ");
    }
	public function DrawHeader(){
		parent::DrawHeader();
		if($this->AllowTopMenu) PART("main-menu");
		if($this->AllowSideMenu) PART("side-menu");
    }
	public function DrawFooter(){
			parent::DrawFooter();
			if($this->AllowBarMenu) PART("bar-menu");
    }
} ?>