<?php
RUN("MSTemplate");
class Template extends MSTemplate{
}
?>