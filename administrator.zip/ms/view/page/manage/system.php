<?php
ACCESS(\_::$CONFIG->AdminAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "System Management";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(
    PART("system/information", print:false).
    PART("report/system", print:false));
?>