<?php
ACCESS(\_::$CONFIG->PersonnelAccess);
if(!RECEIVE(null,"post")) {
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    if(isset($_REQUEST["outbox"])) $module->Title = "Output Statements";
    elseif(isset($_REQUEST["inbox"])) $module->Title = "Input Statements";
    elseif(isset($_REQUEST["currentbox"])) $module->Title = "Current Statements";
    elseif(isset($_REQUEST["addbox"])) $module->Title = "Added Statements";
    elseif(isset($_REQUEST["subtractbox"])) $module->Title = "Subtracted Statements";
    elseif(isset($_REQUEST["failbox"])) $module->Title = "Failed Statements";
    elseif(isset($_REQUEST["partialbox"])) $module->Title = "Partial Statements";
    elseif(isset($_REQUEST["completebox"])) $module->Title = "Completed Statements";
    else $module->Title = "Statements";
    $module->Draw();
    MODULE("PeriodPicker");
    (new MiMFa\Module\PeriodPicker(true, \_::$INFO->DefaultFromTime, \_::$INFO->DefaultToTime))->Draw();
}
echo \MiMFa\Library\HTML::Page(PART("table/statements", print:false));
?>