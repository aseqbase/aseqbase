<?php
ACCESS(\_::$CONFIG->AdminAccess);
use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
MODULE("Table");
$mod = new Table(\_::$CONFIG->DataBasePrefix."Product");
$table1 = \_::$CONFIG->DataBasePrefix."User";
$mod->SelectQuery = "
    SELECT A.{$mod->KeyColumn}, B.Signature, B.Name AS 'Author', A.Name AS 'ProductName', A.Image, A.Title, A.Description, A.UpdateTime
    FROM {$mod->Table} AS A
    LEFT OUTER JOIN $table1 AS B ON A.AuthorID=B.ID;
";
$mod->KeyColumns = ["Image", "Title"];
$mod->IncludeColumns = ["Author", "Image", "Title", "Description", "UpdateTime"];
$mod->Updatable = true;
$mod->AllowServerSide = true;
$mod->UpdateAccess = \_::$CONFIG->AdminAccess;
$access = getAccess(\_::$CONFIG->SuperAccess);
$users =  DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
$mod->CellsTypes = [
    "ID"=>$access?"disabled":false,
    "Name"=>"string",
    "Title"=>"string",
    "Image"=>"image",
    "Description"=>"strings",
    "Content"=>"content",
    "Path"=>"string",
    "Access"=>function(){
        $std = new stdClass();
        $std->Type="number";
        $std->Attributes=["min"=>\_::$CONFIG->BanAccess,"max"=>\_::$CONFIG->UserAccess];
        return $std;
    },
    "AuthorID"=>$access?function($t, $v) use($users){
        $std = new stdClass();
        $std->Title = "Author";
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
        $std->Options = $users;
        if(!isValid($v)) $std->Value = \_::$INFO->User->ID;
        return $std;
    }:false,
    "MetaData"=> getAccess(\_::$CONFIG->AdminAccess)?function(){
        $std = new stdClass();
        $std->Type = "json";
        return $std;
    }:false,
    "UpdateTime"=>function($t, $v){
        $std = new stdClass();
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"calendar":"hidden";
        $std->Value = \_::$CONFIG->GetFormattedDateTime();
        return $std;
    },
    "CreateTime"=>function($t, $v){
        return getAccess(\_::$CONFIG->SuperAccess)?"calendar":(isValid($v)?"hidden":false);
    }
];
$mod->CellsValues = [
    "Author"=>function($v, $k, $r){ return \_::$INFO->GetPersonValue($v, $k, $r);},
    "Title"=>function($v, $k, $r){ return \_::$INFO->GetProductValue($v, $k, $r);},
    "CreateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);},
    "UpdateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);}
];
$mod->Draw();
?>