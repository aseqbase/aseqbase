<?php
function Units_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"UserGroups.ID=$groupId";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = $ifsource;

    $table = \_::$CONFIG->DataBasePrefix."UserGroup";
    $table1 = \_::$CONFIG->DataBasePrefix."User";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "SELECT ".($columns??"
            UserGroups.ID,
            UserGroups.Image,
            UserGroups.Name AS 'UnitName',
            UserGroups.Title,
            UserGroups.Description,
            UserGroups.Access,
            ROUND(AVG(Users.Average) * 100, ".\_::$INFO->DecimalPrecision.") AS 'Average',
            ROUND(AVG(Users.Score), ".\_::$INFO->DecimalPrecision.")  AS 'Score',
            COUNT(Users.ID) AS 'Personnel'
        ")."
        FROM $table1 AS Users
        RIGHT OUTER JOIN $table AS UserGroups
        ON UserGroups.ID=Users.GroupID
        GROUP BY UserGroups.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource"));
}

function Users_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $userId = \_::$INFO->User->ID;
    $ifsource = $access?"TRUE":"Users.ID=$userId";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = $ifsource;

    $table = \_::$CONFIG->DataBasePrefix."User";
    $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "SELECT ".($columns??"
        Users.ID,
        UserGroups.Name AS 'UnitName',
        UserGroups.Title AS 'Unit',
        Users.Image,
        Users.Name,
        Users.Signature,
        Users.Bio,
        Users.Signature,
        Users.Average AS 'Average',
        ROUND(Users.Score, ".\_::$INFO->DecimalPrecision.")  AS 'Score',
        Users.Status,
        Users.CreateTime
        ")."
    FROM $table AS Users
    LEFT OUTER JOIN $table1 AS UserGroups ON Users.GroupID=UserGroups.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource"));
}

function Tools_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $userId = \_::$INFO->User->ID;
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"(Tools.UserGroupID=$groupId OR Tools.UserID=$userId)";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = $ifsource;

    $table = \_::$CONFIG->DataBasePrefix."Tool";
    $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
    $table2 = \_::$CONFIG->DataBasePrefix."User";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "SELECT ".($columns??"
        Tools.Name As 'ToolName', UserGroups.Name As 'UnitName', Users.Signature As 'Signature',
        Tools.ID, UserGroups.Title AS 'Unit', Users.Name AS 'Person', Tools.Image, Tools.Title, Tools.Description,
        GREATEST(0,ROUND((100 * Tools.UsedWorkCount) / Tools.UsageWorkCount, ".\_::$INFO->DecimalPrecision.")) AS 'Used Count (%)',
        GREATEST(0,ROUND((100 * Tools.UsedWorkWeight) / Tools.UsageWorkWeight, ".\_::$INFO->WeightPrecision.")) AS 'Used Weight (%)',
        GREATEST(0,ROUND((100 * Tools.UsedWorkTime) / Tools.UsageWorkTime, ".\_::$INFO->DecimalPrecision.")) AS 'Used Time (%)',
        Tools.UpdateTime
        ")."
    FROM $table AS Tools
    LEFT OUTER JOIN $table1 AS UserGroups ON Tools.UserGroupID=UserGroups.ID
    LEFT OUTER JOIN $table2 AS Users ON Tools.UserID=Users.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource"));
}

function Drafts_Create_Query($query, &$selectParameters=[], &$road=null, $conditions = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $userId = \_::$INFO->User->ID;
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"((UserGroups.ID=$groupId OR Users.ID=$userId) OR (UserGroups.ID < 1 AND Users.ID < 1))";
    $ifdest = $access?"TRUE":"((TargetUserGroups.ID=$groupId OR TargetUsers.ID=$userId) OR (TargetUserGroups.ID < 1 AND TargetUsers.ID < 1))";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = $selectParameters??[];
    $road = $road??[];

    if(!$access) $andConditions[] = "($ifsource OR $ifdest)";
    if(!isEmpty($conditions)) $andConditions[] = "($conditions)";

    $addOrCondition = function($request, $condition) use(&$orConditions, &$selectParameters, &$road){
        if($id = isset($_REQUEST[$request])?getValid($_REQUEST, $request, true):false){
            $road[] = "$request";
            if(is_integer($id)){
                $uid = "_".getId()."_";
                $road[count($road)-1] = "=$id";
                $condition .= " AND (Drafts.ID=:{$request}{$uid}id OR Drafts.ParentID=:{$request}{$uid}pid)";
                $selectParameters[":{$request}{$uid}id"] = $id;
                $selectParameters[":{$request}{$uid}pid"] = $id;
            }
            $orConditions[] = "($condition)";
        }
    };
    $addAndCondition = function($request, $column) use(&$andConditions, &$selectParameters, &$road){
        if($val = getValid($_REQUEST, $request)){
            $uid = "_".getId()."_";
            $road[] = "$request=$val";
            $selectParameters[":{$request}{$uid}"] = $val;
            $andConditions[] = "$column=:{$request}{$uid}";
        }
    };
    $addConditions = function($request, $evaluation, ...$columns) use(&$andConditions, &$orConditions, &$selectParameters, &$road){
        if($val = getValid($_REQUEST, $request)){
            $uid = "_".getId()."_";
            $road[] = "$request=$val";
            $iconditions = [];
            foreach ($columns as $column)
            {
                $req = $request.getId();
                $selectParameters[":{$req}{$uid}"] = $val;
                $iconditions[] = "$column{$evaluation}:{$req}{$uid}";
            }
            $andConditions[] = "(".join(" OR ", $iconditions).")";
        }
    };

    $addOrCondition("outbox", "($ifsource) AND Drafts.Status IN ('Transfer','Done','Completed')");
    $addOrCondition("inbox", "($ifdest) AND Drafts.Status IN ('Transfer','Done','Completed')");
    $addOrCondition("currentbox", "($ifsource OR $ifdest) AND Drafts.Status IN ('Transfer', 'Processing', 'Paused')");
    $addOrCondition("partialbox", "($ifsource OR $ifdest) AND Drafts.Status = 'Paused'");
    $addOrCondition("failbox", "($ifsource) AND (Drafts.Status IN ('Lost', 'Swarfed') OR Drafts.Status LIKE 'Damaged%')");
    $addOrCondition("completebox", "($ifsource) AND Drafts.Status IN ('Done','Completed')");
    $addOrCondition("addbox", "($ifsource) AND Drafts.Status='Changed' AND (Drafts.Weight>0 OR Drafts.Count>0)");
    $addOrCondition("subtractbox", "($ifsource) AND Drafts.Status='Changed' AND (Drafts.Weight<0 OR Drafts.Count<0)");
    $addOrCondition("registerbox", "($ifsource OR $ifdest) AND Drafts.Status IN ('Registered')");

    $addAndCondition("status", "Drafts.Status");
    $addAndCondition("title", "Drafts.Title");
    $addAndCondition("time", "Drafts.Time");
    $addAndCondition("description", "Drafts.Description");
    $addAndCondition("product", "Products.Name");
    $addAndCondition("sourceUnit", "UserGroups.Name");
    $addAndCondition("sourcePerson", "Users.Signature");
    $addAndCondition("destUnit", "TargetUserGroups.Name");
    $addAndCondition("destPerson", "TargetUsers.Signature");

    $addConditions("draft", "=", "Drafts.ID", "Drafts.ParentID");
    $addConditions("sequence", "=", "Drafts.ID", "Drafts.ParentID");
    $addConditions("fromTime", ">=", "Drafts.UpdateTime", "Drafts.CreateTime");
    $addConditions("toTime", "<=", "Drafts.UpdateTime", "Drafts.CreateTime");
    $addConditions("user", "=", "Users.Signature", "TargetUsers.Signature");
    $addConditions("unit", "=", "UserGroups.Name", "TargetUserGroups.Name");
    $addConditions("person", "=", "Users.Signature", "TargetUsers.Signature");

    if($val = getValid($_REQUEST, "score")){
        if($val < 0) $addConditions("score", ">=", "Drafts.Score");
        elseif($val > 0) $addConditions("score", "<=", "Drafts.Score");
        else $addConditions("score", "=", "Drafts.Score");
    }
    if($val = getValid($_REQUEST, "count")){
        if($val < 0) $addConditions("count", ">=", "Drafts.Count");
        elseif($val > 0) $addConditions("count", "<=", "Drafts.Count");
        else $addConditions("count", "=", "Drafts.Count");
    }
    if($val = getValid($_REQUEST, "weight")){
        if($val < 0) $addConditions("weight", ">=", "Drafts.Weight");
        elseif($val > 0) $addConditions("weight", "<=", "Drafts.Weight");
        else $addConditions("weight", "=", "Drafts.Weight");
    }

    $table = \_::$CONFIG->DataBasePrefix."Draft";
    $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
    $table2 = \_::$CONFIG->DataBasePrefix."User";
    $table3 = \_::$CONFIG->DataBasePrefix."Product";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return between($query,"
        SELECT UserGroups.Name AS 'UnitName',
        Users.Signature AS 'Signature',
        TargetUserGroups.Name AS 'DUnitName',
        TargetUsers.Signature AS 'DSignature',
        Products.Name AS 'ProductName',
        IF($ifsource,TRUE,FALSE) AS 'IsSource',
        IF($ifdest,TRUE,FALSE) AS 'IsDestination',
        Drafts.ID AS Management,
        Drafts.ID,
        Drafts.ParentID,
        Products.Title AS 'Product',
        UserGroups.Title AS 'Source Unit',
        Users.Name AS 'Source Person',
        TargetUserGroups.Title AS 'Dest Unit',
        TargetUsers.Name AS 'Dest Person',
        Drafts.Title,
        Drafts.Description,
        Drafts.Status,
        Drafts.Image,
        Drafts.Count,
        Drafts.Weight,
        Drafts.Time,
        Drafts.Delay,
        Drafts.Score,
        Drafts.ChangeCount AS 'Change Count',
        Drafts.UpdateTime,
        Drafts.CreateTime
    FROM $table AS Drafts
    ")."
    LEFT OUTER JOIN $table1 AS UserGroups ON Drafts.UserGroupID=UserGroups.ID
    LEFT OUTER JOIN $table2 AS Users ON Drafts.UserID=Users.ID
    LEFT OUTER JOIN $table1 AS TargetUserGroups ON Drafts.TargetUserGroupID=TargetUserGroups.ID
    LEFT OUTER JOIN $table2 AS TargetUsers ON Drafts.TargetUserID=TargetUsers.ID
    LEFT OUTER JOIN $table3 AS Products ON Drafts.ProductID=Products.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource OR $ifdest"));
}

function Drafts_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null, $conditions = null, $join = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $userId = \_::$INFO->User->ID;
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"((UserGroups.ID=$groupId OR Users.ID=$userId) OR (UserGroups.ID < 1 AND Users.ID < 1))";
    $ifdest = $access?"TRUE":"((TargetUserGroups.ID=$groupId OR TargetUsers.ID=$userId) OR (TargetUserGroups.ID < 1 AND TargetUsers.ID < 1))";
    $table = \_::$CONFIG->DataBasePrefix."Draft";
    return Drafts_Create_Query("
    SELECT
        ".between($columns,"
        UserGroups.Name AS 'UnitName',
        Users.Signature AS 'Signature',
        TargetUserGroups.Name AS 'DUnitName',
        TargetUsers.Signature AS 'DSignature',
        Products.Name AS 'ProductName',
        IF($ifsource,TRUE,FALSE) AS 'IsSource',
        IF($ifdest,TRUE,FALSE) AS 'IsDestination',
        Drafts.ID AS Management,
        Drafts.ID,
        Drafts.ParentID,
        Products.Title AS 'Product',
        UserGroups.Title AS 'Source Unit',
        Users.Name AS 'Source Person',
        TargetUserGroups.Title AS 'Dest Unit',
        TargetUsers.Name AS 'Dest Person',
        Drafts.Title,
        Drafts.Description,
        Drafts.Status,
        Drafts.Image,
        Drafts.Count,
        Drafts.Weight,
        Drafts.Time,
        Drafts.Delay,
        Drafts.Score,
        Drafts.ChangeCount AS 'Change Count',
        Drafts.UpdateTime,
        Drafts.CreateTime")."
    FROM $table AS Drafts
    $join", $selectParameters, $road, $conditions);
}

function Drafts_Create_Trace_Query(&$selectParameters=[], &$road=null, $columns = null, $conditions = null, $join = null){
    return Drafts_Create_Select_Query($selectParameters, $road, $columns??"
        UserGroups.Name AS 'UnitName',
        Users.Signature AS 'Signature',
        TargetUserGroups.Name AS 'DUnitName',
        TargetUsers.Signature AS 'DSignature',
        Products.Name AS 'ProductName',
        Drafts.ID,
        Drafts.ParentID,
        Users.ID AS 'UserID',
        TargetUsers.ID AS 'TargetUserID',
        UserGroups.ID AS 'UserGroupID',
        TargetUserGroups.ID AS 'TargetUserGroupID',
        Products.Title AS 'Product',
        UserGroups.Title AS 'Source Unit',
        Users.Name AS 'Source Person',
        TargetUserGroups.Title AS 'Dest Unit',
        TargetUsers.Name AS 'Dest Person',
        Drafts.Title,
        Drafts.Status,
        Drafts.Count,
        Drafts.Weight,
        Drafts.Time,
        Drafts.Delay,
        (Drafts.Score * 100) AS 'Score',
        Drafts.ChangeCount AS 'Change Count',
        Drafts.UpdateTime,
        Drafts.CreateTime", $conditions, $join);
}

function Statements_Create_Select_Query(&$selectParameters=[], &$road=null){
    $table1 = \_::$CONFIG->DataBasePrefix."Draft";
    $road = $road??[];
    $nroad = [];
    $columns =
                "UserGroups.Name AS 'UnitName',
                Users.Signature AS 'Signature',
                TargetUserGroups.Name AS 'DUnitName',
                TargetUsers.Signature AS 'DSignature',
                Products.Name AS 'ProductName',
                Drafts.ID AS Management,
                Drafts.ID,
                Drafts.ParentID,
                Products.Title AS 'Product',
                Drafts.Title,
                Drafts.Description,
                Drafts.Status,
                Drafts.Image,
                Drafts.Time,
                Drafts.Delay,
                Drafts.Score,
                Drafts.ChangeCount AS 'Change Count',
                Drafts.UpdateTime,
                Drafts.CreateTime";
    $runit = isset($_REQUEST["unit"])?$_REQUEST["unit"]:false;
    $rperson = isset($_REQUEST["person"])?$_REQUEST["person"]:false;
    if($runit!==false) $selectParameters[":Unit"] = $selectParameters[":TUnit"] = $runit;
    if($rperson!==false) $selectParameters[":Person"] = $selectParameters[":TPerson"] = $rperson;
    return Drafts_Create_Query(
            "SELECT $columns,
                TargetUserGroups.Title AS 'Unit',
                TargetUsers.Name AS 'Person',
                ABS(Drafts.Weight) AS 'Credit Weight',
                NULL AS 'Debit Weight',
                ABS(Drafts.Count) AS 'Credit Count',
                NULL AS 'Debit Count',
                0 AS 'IsSource'
            FROM $table1 AS Drafts",
        $selectParameters, $road, "
            (
                (
                    (Drafts.TargetUserID>-1 OR Drafts.TargetUserGroupID>-1)
                    AND Drafts.Status IN ('Done','Completed','Transfer')
                ) OR (
                    Drafts.Status='Changed'
                    AND (Drafts.Weight > 0 OR Drafts.Count > 0)
                )
            )
        ".($runit===false&&$rperson===false?"":"
            AND NOT (
                Drafts.Status IN ('Done','Completed','Transfer')
                AND (".join(" OR ", [
                    ...($runit===false?[]:["UserGroups.Name=:Unit"]),
                    ...($rperson===false?[]:["Users.Signature=:Person"])
                ]).")
            )"))."
        UNION ALL
        ".Drafts_Create_Query(
            "SELECT $columns,
                UserGroups.Title AS 'Unit',
                Users.Name AS 'Person',
                NULL AS 'Credit Weight',
                ABS(Drafts.Weight) AS 'Debit Weight',
                NULL AS 'Credit Count',
                ABS(Drafts.Count) AS 'Debit Count',
                1 AS 'IsSource'
            FROM $table1 AS Drafts",
        $selectParameters, $nroad, "
            (
                (Drafts.UserID>-1 OR Drafts.UserGroupID>-1)
                AND (
                    Drafts.Status!='Changed'
                    OR (Drafts.Weight < 0 OR Drafts.Count < 0)
                )
            )".($runit===false&&$rperson===false?"":"
            AND NOT (
                Drafts.Status IN ('Done','Completed','Transfer')
                AND (".join(" OR ", [
                    ...($runit===false?[]:["TargetUserGroups.Name=:TUnit"]),
                    ...($rperson===false?[]:["TargetUsers.Signature=:TPerson"])
                ]).")
            )"));
}
?>