<?php
TEMPLATE("Main");
$templ = new \MiMFa\Template\Main();
$templ->Draw();
?>
