<?php
RUN("AseqConfiguration");
class Configuration extends AseqConfiguration {
}
?>