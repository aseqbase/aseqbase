<?php
RUN("MSTemplate");
class Template extends MSTemplate{
	public $ForeColorPalette = array("#101010","#050505","#151515","#151515","#101010","#202020");
	public $BackColorPalette = array("#fbfbfb","#fefefe","#eeae2c","#fdfdfd","#ffffff","#fece2c");
	public $FontPalette = array("'dubai','b yekan', sans-serif");
	public $SizePalette = array("10pt", "12pt","15pt","19pt","25pt","32pt","40pt");

	public function CreateScoreColorJS($parameterName = "score", $quote = "'", $alpha = 1){
        //return "rgba($quote+(250-($parameterName*250))+$quote, 25, $quote+($parameterName*250)+$quote, $alpha);";
        return "rgb($quote+(250-($parameterName*250))+$quote, $quote+($parameterName*250)+$quote, 25, $alpha);";
    }
	public function CreateScoreColorCSS($score = 0.5, $alpha = 1){
        //return "rgba(".(250-($score*250)).", 25, ".($score*250).", $alpha);";
        return "rgb(".(250-($score*250)).", ".($score*250).", 25, $alpha);";
    }
}
?>