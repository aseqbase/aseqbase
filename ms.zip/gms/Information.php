<?php
RUN("MSInformation");
class Information extends MSInformation{
	public $Owner = "MiMFa";
	public $FullOwner = "Minimal Member Factory";
	public $Product = "GMS";
	public $FullProduct = "Goldsmith Management System";
	public $Name = "GMS";
	public $FullName = "MiMFa Goldsmith Management System";
	public $Slogan = "A Special Goldsmith Management System";
	public $FullSlogan = "Develop websites by <u>a seq</u>uence-<u>base</u>d framework";
	public $Description = "A goldsmith management system, is special for an aseqbase website...";
	public $FullDescription = "A special framework for web development called \"aseqbase\" (a sequence-based framework) has been developed to implement safe, flexible, fast, and strong pure websites based on that, since 2018 so far.";

	public $Path = "https://gms.mimfa.net";
	/**
     * Activate auto filling data in some fields
     * @var bool
     */
	public $AutoFill = false;
	public $TraceManagers = false;
	/**
     * Merge all similar in processing drafts
     * @var bool
     */
	public $MergeDrafts = true;

	public $DefaultFromTime = "1 week ago";
	public $DefaultToTime = "today 23:59:59";

}
?>