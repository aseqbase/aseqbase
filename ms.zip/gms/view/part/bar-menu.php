<?php MODULE("BarMenu");
$module = new \MiMFa\Module\BarMenu();
$module->Items = \_::$INFO->Shortcuts;
$module->Draw();
echo \_::$TEMPLATE->CreateScoreColorTemplate(":not(.page, .header, .footer, .content) .button.middle", 4, hoverable:false);
?>