<?php
PAGE(normalizePath(\_::$DIRECTION), variables:$_REQUEST);
?>
