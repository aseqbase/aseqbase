<?php MODULE("Copyright");
$module = new \MiMFa\Module\Copyright();
$module->Draw();
?>