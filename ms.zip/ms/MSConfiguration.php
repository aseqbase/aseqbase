<?php
class MSConfiguration extends ConfigurationBase {
    public $UserAccess = 1000000000;
    public $PersonnelAccess = 999999999;
    public $VisitAccess = 999999999;
    public $AllowSigning = true;
    public $AllowCache = false;
	public $AllowTranslate = true;
	public $DefaultLanguage = null;
    public $DefaultDirection = null;


    public function __construct(){
        parent::__construct();
        $this->Handlers["/^users(\/|\?|$)/i"] = "users";
        $this->Handlers["/^units(\/|\?|$)/i"] = "units";
        $this->Handlers["/^products(\/|\?|$)/i"] = "products";
        $this->Handlers["/^tools(\/|\?|$)/i"] = "tools";
        $this->Handlers["/^drafts(\/|\?|$)/i"] = "drafts";
    }
}
?>