<?php
class MSTemplate extends TemplateBase{
	public $ForeColorPalette = array("#252525", "#151515","#2060cc");
	public $BackColorPalette = array("#fefefe","#fbfbfb","#fcfcfc");
	public $FontPalette = array("'dubai', sans-serif","'dubai', sans-serif","'dubai', sans-serif");
	public $SizePalette = array("12pt","15pt","19pt","25pt","32pt","40pt","50pt");
    public $ShadowPalette = array("none","4px 7px 20px #00000005","4px 7px 20px #00000015","4px 7px 20px #00000025","5px 10px 25px #00000030","0px 0px 20px #00000030","0px 0px 20px #00000050");
    public $BorderPalette = array("1px solid","1px solid","2px solid","5px solid","10px solid","25px solid");

	public function CreateScoreColorJS($parameterName = "score", $quote = "'", $alpha = 1){
        return "rgba($quote+(250-($parameterName*250))+$quote, 25, $quote+($parameterName*250)+$quote, $alpha);";
        //return "rgb($quote+(250-($parameterName*250))+$quote, $quote+($parameterName*250)+$quote, 25, $alpha);";
    }
	public function CreateScoreColorCSS($score = 0.5, $alpha = 1){
        return "rgba(".(250-($score*250)).", 25, ".($score*250).", $alpha);";
        //return "rgb(".(250-($score*250)).", ".($score*250).", 25, $alpha);";
    }

	public function CreateScoreColorTemplate($imageSelector = ".page .header .media", $borderSize = 15, $hoverable = true, $signature = null, $score = null){
        if(is_null($score)) $score = \_::$INFO->User->GetValue("Average", $signature);
        return MiMFa\Library\HTML::Style("
            $imageSelector{
                border-radius: 100%;
                border: {$borderSize}px solid ".$this->CreateScoreColorCSS($score).";
                outline: ".($borderSize/2)."px solid ".$this->CreateScoreColorCSS($score, 0.5).";
	            ".MiMFa\Library\Style::UniversalProperty("transition",\_::$TEMPLATE->Transition(1))."
            }".($hoverable?"
            $imageSelector:hover{
                outline-width: ".($borderSize*2)."px;
	            ".MiMFa\Library\Style::UniversalProperty("transition",\_::$TEMPLATE->Transition(1))."
            }":""));
    }
}
?>