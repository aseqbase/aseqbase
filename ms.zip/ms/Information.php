<?php
RUN("MSInformation");
class Information extends MSInformation{
}
?>