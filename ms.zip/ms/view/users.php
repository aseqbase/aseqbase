<?php
use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
$path = \_::$PAGE;
TEMPLATE("Main");
$templ = new \MiMFa\Template\Main();
if(!isValid($path))
    $templ->Content = function(){
        PAGE("home");
    };
else
    $templ->Content = function() use($path){
        ACCESS(\_::$CONFIG->UserAccess);
        MODULE("Table");
        $mod = new Table(\_::$CONFIG->DataBasePrefix."User");
        $mod->KeyColumn = "Signature";
        $mod->Updatable = false;
        $access = getAccess($mod->UpdateAccess = \_::$CONFIG->AdminAccess);
        $mod->CellsTypes = [
            "Name"=>"string",
            "Image"=>"image",
            "Bio"=>"strings",
            "Signature"=>$access,
            "FirstName"=>$access,
            "MiddleName"=>$access,
            "LastName"=>$access,
            "Gender"=>["Male"=>"Male","Female"=>"Female","X"=>"X"],
            "Contact"=>$access,
            "Address"=>$access,
            "Email"=>$access,
            "Score"=>$access,
            "Rate"=>$access,
            "GroupID"=> function(){
                $std = new stdClass();
                $std->Title = "Unit";
                $std->Type = "select";
                $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title");
                return $std;
            },
            "Status"=>$access,
            "MetaData"=> $access?"json":$access,
            "UpdateTime"=>$access,
            "CreateTime"=>$access
        ];
        return MiMFa\Library\HTML::Container($mod->DoAction($path));
    };
$templ->Draw();
?>