<?php
ACCESS(\_::$CONFIG->PersonnelAccess);
use MiMFa\Library\DataBase;
use MiMFa\Module\Table;
MODULE("Table");
$mod = new Table(\_::$CONFIG->DataBasePrefix."Tool");
$table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
$table2 = \_::$CONFIG->DataBasePrefix."User";

PART("dbfilters.php");
$mod->SelectQuery = Tools_Create_Select_Query();
$mod->KeyColumns = ["Image", "Title"];
$mod->IncludeColumns = [$mod->KeyColumn, "Unit", "Person", "Image", "Title", "Description", 'Used Count (%)', 'Used Weight (%)', 'Used Time (%)', "UpdateTime"];
$mod->Updatable = true;
$mod->AllowServerSide = true;
$mod->UpdateAccess = \_::$CONFIG->AdminAccess;
$access = getAccess(\_::$CONFIG->SuperAccess);
$users =  DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
$mod->CellsTypes = [
    "ID"=>$access?"disabled":false,
    "Name"=>"string",
    "Title"=>"string",
    "Image"=>"image",
    "Description"=>"strings",
    "UserGroupID" => function(){
        $std = new stdClass();
        $std->Title = "Responsible Unit";
        $std->Type = "select";
        $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title");
        return $std;
    },
    "UserID" => function() use($users){
        $std = new stdClass();
        $std->Title = "Responsible Person";
        $std->Type = "select";
        $std->Options = $users;
        return $std;
    },
    "Count"=> function(){
        $std = new stdClass();
        $std->Title = "Numbers (".\_::$INFO->CountUnit.")";
        $std->Description = "Numbers of this Tool (".\_::$INFO->CountUnit.")";
        return $std;
    },
    "UsageWorkCount"=> function(){
        $std = new stdClass();
        $std->Title = "Numbers of Works (".\_::$INFO->CountUnit.")";
        $std->Description = "Minimum Numbers of Products to Use this Tool (".\_::$INFO->CountUnit.")";
        return $std;
    },
    "UsedWorkCount"=> function(){
        $std = new stdClass();
        $std->Title = "Numbers of Used (".\_::$INFO->CountUnit.")";
        $std->Description = "Numbers of Products Used this Tool (".\_::$INFO->CountUnit.")";
        return $std;
    },
    "Weight"=> function(){
        $std = new stdClass();
        $std->Title = "Weight (".\_::$INFO->WeightUnit.")";
        $std->Description = "Weight of this Tool (".\_::$INFO->WeightUnit.")";
        return $std;
    },
    "UsageWorkWeight"=> function(){
        $std = new stdClass();
        $std->Title = "Weight of Works (".\_::$INFO->WeightUnit.")";
        $std->Description = "Minimum Weight of Products to Use this Tool  (".\_::$INFO->WeightUnit.")";
        return $std;
    },
    "UsedWorkWeight"=> function(){
        $std = new stdClass();
        $std->Title = "Weight of Used (".\_::$INFO->WeightUnit.")";
        $std->Description = "Weight of Products Used this Tool (".\_::$INFO->WeightUnit.")";
        return $std;
    },
    "Time"=> function(){
        $std = new stdClass();
        $std->Title = "Time (".\_::$INFO->TimeUnit.")";
        $std->Description = "Time of this Tool (".\_::$INFO->TimeUnit.")";
        return $std;
    },
    "UsageWorkTime"=> function(){
        $std = new stdClass();
        $std->Title = "Time of Works (".\_::$INFO->TimeUnit.")";
        $std->Description = "Minimum Time of Products to Use this Tool (".\_::$INFO->TimeUnit.")";
        return $std;
    },
    "UsedWorkTime"=> function(){
        $std = new stdClass();
        $std->Title = "Time of Used (".\_::$INFO->TimeUnit.")";
        $std->Description = "Time of Products Used this Tool (".\_::$INFO->TimeUnit.")";
        return $std;
    },
    "Path"=>"string",
    "AuthorID"=>$access?function($t, $v) use($users){
        $std = new stdClass();
        $std->Title = "Author";
        $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
        $std->Options = $users;
        if(!isValid($v)) $std->Value = \_::$INFO->User->ID;
        return $std;
    }:false,
    "MetaData"=> getAccess(\_::$CONFIG->AdminAccess)?function(){
        $std = new stdClass();
        $std->Type = "json";
        return $std;
    }:false,
    "UpdateTime"=>function($t, $v) use($access){
        $std = new stdClass();
        $std->Type = $access?"calendar":"hidden";
        $std->Value = \_::$CONFIG->GetFormattedDateTime();
        return $std;
    },
    "CreateTime"=>function($t, $v){
        return getAccess(\_::$CONFIG->SuperAccess)?"calendar":(isValid($v)?"hidden":false);
    }
];
$mod->CellsValues = [
    "Unit"=>function($v, $k, $r){ return \_::$INFO->GetUnitValue($v, $k, $r);},
    "Person"=>function($v, $k, $r){ return \_::$INFO->GetPersonValue($v, $k, $r);},
    "Title"=>function($v, $k, $r){ return \_::$INFO->GetToolValue($v, $k, $r);},
    "CreateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);},
    "UpdateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);}
];
$mod->Draw();
?>