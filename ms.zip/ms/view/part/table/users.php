<?php
ACCESS(\_::$CONFIG->AdminAccess);
use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
use MiMFa\Library\HTML;
MODULE("Table");
$mod = new Table(\_::$CONFIG->DataBasePrefix."User");
$table1 = \_::$CONFIG->DataBasePrefix."UserGroup";

PART("dbfilters.php");
$mod->SelectQuery = Users_Create_Select_Query();
$mod->KeyColumns = ["Name", "Unit"];
$mod->ExcludeColumns = ["UnitName", "Signature", "MetaData"];
$mod->Updatable = true;
$mod->AllowServerSide = true;
$mod->UpdateAccess = \_::$CONFIG->AdminAccess;
$mod->CellsTypes = [
    "ID"=>"number",
    "GroupID"=> function(){
        $std = new stdClass();
        $std->Title = "Unit";
        $std->Type = "select";
        $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title");
        return $std;
    },
    "Name"=>"string",
    "Image"=>"image",
    "Bio"=>"strings",
    "Email"=>"email",
    "Signature"=>"string",
    "Password"=>"password",
    "FirstName"=>"string",
    "MiddleName"=>"string",
    "LastName"=>"string",
    "Gender"=>["Male"=>"Male","Female"=>"Female"],
    "Contact"=>"tel",
    "Organization"=>"string",
    "Address"=>"string",
    "Path"=>"string",
    "Score"=> getAccess(\_::$CONFIG->AdminAccess)?function($t, $v){
        $std = new stdClass();
        $std->Type = "float";
        $std->Attributes = ["min"=>0,"max"=>999999999];
        $std->Value = round($v??0,\_::$INFO->DecimalPrecision);
        return $std;
    }:"disabled",
    "Rate"=>getAccess(\_::$CONFIG->SuperAccess)?"float":"disabled",
    "Status"=>[-1=>"Blocked",0=>"Deactivated",1=>"Activated"],
    "UpdateTime"=>function($t, $v){
        $std = new stdClass();
        $std->Type = getAccess(\_::$CONFIG->AdminAccess)?"calendar":"hidden";
        $std->Value = \_::$CONFIG->GetFormattedDateTime();
        return $std;
    },
    "CreateTime"=>function($t, $v){
        return getAccess(\_::$CONFIG->SuperAccess)?"calendar":(isValid($v)?"hidden":false);
    },
    "MetaData"=> getAccess(\_::$CONFIG->AdminAccess)?function(){
        $std = new stdClass();
        $std->Type = "json";
        return $std;
    }:false
];
$mod->CellsValues = [
    "Unit"=>function($v, $k, $r){ return \_::$INFO->GetUnitValue($v, $k, $r);},
    "Image"=>function($v, $k, $r){ return \_::$INFO->GetPersonImage($v, $k, $r);},
    "Score"=>function($v, $k, $r){ return round($v*100, \_::$INFO->DecimalPrecision);},
    "Name"=>function($v, $k, $r){ return \_::$INFO->GetPersonValue($v, $k, $r);},
    "CreateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);},
    "UpdateTime"=>function($v, $k, $r){ return \_::$CONFIG->ToShownFormattedDateTime($v);}
];

$selector2 = ".FormModal";
$mod->Draw();
echo \_::$TEMPLATE->CreateScoreColorTemplate("$selector2 .header .media", 10);
echo HTML::Script("
    try{
        score = parseFloat($(`$selector2 .content input[name='Score']`).val());
        $(`$selector2 .header .media`).attr('style','border-size: 5px; border-color: ".(\_::$TEMPLATE->CreateScoreColorJS("score","'"))."; outline-color: ".(\_::$TEMPLATE->CreateScoreColorJS("score","'", 0.5)).";');
    }catch{}
");

?>