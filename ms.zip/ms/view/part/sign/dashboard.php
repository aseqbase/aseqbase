<?php
use MiMFa\Library\User;
use MiMFa\Library\HTML;
use MiMFa\Library\Style;
$dir = MiMFa\Library\Translate::$Direction === "RTL"?"right":"left";
echo HTML::Style("
.page.dashboard header.header.introduction {
	text-align: center;
	margin: var(--Size-1);
	margin-bottom: var(--Size-5);
}
.page.dashboard header.header.introduction *{
	text-align: center;
}
.page.dashboard header.header.introduction .media {
	aspect-ratio: 1;
	width: 50%;
	max-width: 300px;
	border-radius: 100%;
	display: inline-flex;
}
.page.dashboard header.header.introduction .span {
    aspect-ratio: 1;
    background-color: var(--BackColor-3);
    border-radius: 100%;
    display: block;
    width: fit-content;
    font-weight: bold;
    font-size: var(--Size-3);
    line-height: 200%;
    margin-top: -8vh;
    margin-$dir: 55%;
    padding: calc(var(--Size-0) / 2);
    position: relative;
    vertical-align: middle;
    align-items: center;
}
.page.dashboard .container {
    gap: var(--Size-2);
}
.page.dashboard .rack {
    margin-top: var(--Size-2);
    margin-bottom: var(--Size-2);
    gap: var(--Size-2);
}
.page.dashboard .special.button {
    text-align: center;
    display: block;
    padding: var(--Size-0);
    margin: 0px;
    border: var(--Border-1) transparent;
    border-radius: var(--Radius-1);
	".Style::UniversalProperty("transition",\_::$TEMPLATE->Transition(1))."
}
.page.dashboard .special.button:hover {
    font-weight: bolder;
    color: var(--ForeColor-2);
    border-color: var(--ForeColor-2);
	".Style::UniversalProperty("transition",\_::$TEMPLATE->Transition(1))."
}
.page.dashboard .special.button img.image {
    height: calc(var(--Size-5) * 1.5 - var(--Size-0) / 2);
    display: inline-block;
    margin: var(--Size-0);
	".Style::UniversalProperty("transition",\_::$TEMPLATE->Transition(1))."
}
.page.dashboard .special.button:hover img.image {
    height: calc(var(--Size-5) * 1.5 + var(--Size-0) / 2);
    margin: calc(var(--Size-0) / 2);
	".Style::UniversalProperty("transition",\_::$TEMPLATE->Transition(1))."
}
.page.dashboard .special.button span {
    display: block;
}
.page.dashboard .heading{
    text-align: center;
    width: 100%;
    color: var(--ForeColor-2);
    border-bottom: var(--Border-1) var(--BackColor-4);
    margin: var(--Size-3) var(--Size-5) 0px;
}");
$score = \_::$INFO->User->GetValue("Score");
$group = MiMFa\Library\DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup","Name", "Title", "`ID`=:ID",[":ID"=>\_::$INFO->User->GroupID]);
$header = HTML::Header(
			HTML::Link(HTML::Media(between(\_::$INFO->User->Image, User::$DefaultImagePath)), User::$EditHandlerPath).
			HTML::Span(round($score*100)."%").
			HTML::ExternalHeading(\_::$INFO->User->Name).
			HTML::SubHeading(array_values($group)[0], "/units/".array_keys($group)[0]).
			HTML::Paragraph(\_::$INFO->User->GetValue("Bio")).
            HTML::$HorizontalBreak
		,["class"=>"introduction"]);
echo "<div class='page dashboard'>";
$headingAttr = [];
$profileMenu = [
                HTML::Button("Show Profile", User::$ViewHandlerPath),
                HTML::Button("Edit Profile", User::$EditHandlerPath),
                HTML::Button("Reset Password", User::$RecoverHandlerPath),
                HTML::Button("Sign Out", User::$OutHandlerPath)
            ];
$draftsMenu = [];
foreach (\_::$INFO->MainMenus["Edit"]["Items"]["Draft"]["Items"] as $item)
	if(getAccess(getValid($item,"Access",\_::$CONFIG->VisitAccess)))
        $draftsMenu[] = HTML::Button([HTML::Image(getBetween($item, "Image", "Icon")), HTML::Span(getBetween($item, "Title", "Name"))], str_replace("/edit/drafts","/manage/drafts",getBetween($item, "Path", "Link")), ["class"=>"special"]);
if(ACCESS(\_::$CONFIG->AdminAccess, assign:false, die:false))
    echo HTML::Center(
        $header.
        HTML::Container([
            HTML::Heading("Drafts", null, $headingAttr),
            $draftsMenu,
            HTML::Heading("Management", null, $headingAttr),
            [
                HTML::Button([HTML::Image("/file/symbol/factory.png"), HTML::Span("Entire Management")], "/manage/system.php", ["class"=>"special"]),
                HTML::Button([HTML::Image("/file/symbol/factory-unit.png"), HTML::Span("Units Management")], "/manage/units.php", ["class"=>"special"]),
                HTML::Button([HTML::Image("/file/symbol/factory-worker.png"), HTML::Span("Users Management")], "/manage/users.php", ["class"=>"special"]),
                HTML::Button([HTML::Image("/file/symbol/product.png"), HTML::Span("Products Management")], "/manage/products.php", ["class"=>"special"]),
                HTML::Button([HTML::Image("/file/symbol/tool.png"), HTML::Span("Tools Management")], "/manage/tools.php", ["class"=>"special"]),
                HTML::Button([HTML::Image("/file/symbol/operation.png"), HTML::Span("Drafts Management")], "/manage/drafts.php", ["class"=>"special"])
            ],
            HTML::Heading("Account", null, $headingAttr),
            $profileMenu
        ])
    );
elseif(ACCESS(\_::$CONFIG->PersonnelAccess, assign:false, die:false))
    echo HTML::Center(
        $header.
        HTML::Container([
            HTML::Heading("Drafts", null, $headingAttr),
            $draftsMenu,
            HTML::Heading("Management", null, $headingAttr),
            [
                HTML::Button([HTML::Image("/file/symbol/analyze.png"), HTML::Span("Works Status")], "/manage/drafts.php", ["class"=>"special"]),
                HTML::Button([HTML::Image("/file/symbol/tool.png"), HTML::Span("Tools Status")], "/manage/tools.php", ["class"=>"special"])
            ],
            HTML::Heading("Account", null, $headingAttr),
            $profileMenu
        ])
    );
elseif(ACCESS(\_::$CONFIG->UserAccess))
    echo HTML::Center(
        $header.
        HTML::Container([$profileMenu])
    );
echo "</div>";
echo \_::$TEMPLATE->CreateScoreColorTemplate(".page header.header.introduction .media", 15, score:$score);
echo \_::$TEMPLATE->CreateScoreColorTemplate(".page header.header.introduction .span", 5, score:$score);
?>