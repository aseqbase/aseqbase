<?php
function Units_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"UserGroups.ID=$groupId";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = $ifsource;

    $table = \_::$CONFIG->DataBasePrefix."UserGroup";
    $table1 = \_::$CONFIG->DataBasePrefix."User";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "SELECT ".($columns??"
            UserGroups.ID,
            UserGroups.Image,
            UserGroups.Name AS 'UnitName',
            UserGroups.Title,
            UserGroups.Description,
            UserGroups.Access,
            ROUND(AVG(Users.Score) * 100, ".\_::$INFO->DecimalPrecision.") AS 'Score',
            ROUND(AVG(Users.Rate), ".\_::$INFO->DecimalPrecision.")  AS 'Rate',
            COUNT(Users.ID) AS 'Personnel'
        ")."
        FROM $table1 AS Users
        RIGHT OUTER JOIN $table AS UserGroups
        ON UserGroups.ID=Users.GroupID
        GROUP BY UserGroups.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource"));
}

function Users_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $userId = \_::$INFO->User->ID;
    $ifsource = $access?"TRUE":"Users.ID=$userId";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = $ifsource;

    $table = \_::$CONFIG->DataBasePrefix."User";
    $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "SELECT ".($columns??"
        Users.ID,
        UserGroups.Name AS 'UnitName',
        UserGroups.Title AS 'Unit',
        Users.Image,
        Users.Name,
        Users.Signature,
        Users.Bio,
        Users.Signature,
        Users.Rate,
        ROUND(Users.Score, ".\_::$INFO->DecimalPrecision.")  AS 'Score',
        UserGroups.Access,
        Users.Status,
        Users.CreateTime
        ")."
    FROM $table AS Users
    LEFT OUTER JOIN $table1 AS UserGroups ON Users.GroupID=UserGroups.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource"));
}

function Tools_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null){
    $access = getAccess(\_::$CONFIG->AdminAccess);
    $userId = \_::$INFO->User->ID;
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"(Tools.UserGroupID=$groupId OR Tools.UserID=$userId)";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = [];
    $road = [];

    if(!$access) $andConditions[] = $ifsource;

    $table = \_::$CONFIG->DataBasePrefix."Tool";
    $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
    $table2 = \_::$CONFIG->DataBasePrefix."User";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return "SELECT ".($columns??"
        Tools.Name As 'ToolName', UserGroups.Name As 'UnitName', Users.Signature As 'Signature',
        Tools.ID, UserGroups.Title AS 'Unit', Users.Name AS 'Person', Tools.Image, Tools.Title, Tools.Description,
        GREATEST(0,ROUND((100 * Tools.UsedWorkCount) / Tools.UsageWorkCount, ".\_::$INFO->DecimalPrecision.")) AS 'Used Count (%)',
        GREATEST(0,ROUND((100 * Tools.UsedWorkWeight) / Tools.UsageWorkWeight, ".\_::$INFO->WeightPrecision.")) AS 'Used Weight (%)',
        GREATEST(0,ROUND((100 * Tools.UsedWorkTime) / Tools.UsageWorkTime, ".\_::$INFO->DecimalPrecision.")) AS 'Used Time (%)',
        Tools.UpdateTime
        ")."
    FROM $table AS Tools
    LEFT OUTER JOIN $table1 AS UserGroups ON Tools.UserGroupID=UserGroups.ID
    LEFT OUTER JOIN $table2 AS Users ON Tools.UserID=Users.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource"));
}

function Drafts_Create_Query($query, &$selectParameters=[], &$road=null, $conditions = null){
    $access = getAccess(\_::$CONFIG->AdminAccess/2);
    $userId = \_::$INFO->User->ID;
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"((UserGroups.ID=$groupId OR Users.ID=$userId) OR (UserGroups.ID < 1 AND Users.ID < 1))";
    $ifdest = $access?"TRUE":"((TargetUserGroups.ID=$groupId OR TargetUsers.ID=$userId) OR (TargetUserGroups.ID < 1 AND TargetUsers.ID < 1))";

    $orConditions = [];
    $andConditions = [];
    $selectParameters = $selectParameters??[];
    $road = $road??[];

    if(!$access) $andConditions[] = "($ifsource OR $ifdest)";
    if(!isEmpty($conditions)) $andConditions[] = "($conditions)";

    $addBoxCondition = function($request, $condition) use(&$orConditions, &$selectParameters, &$road){
        if(isset($_REQUEST[$request])){
            $val = getValid($_REQUEST, $request);
            $road[] = $request;
            if(is_integer($val)){
                $uid = "_".getId()."_";
                $road[count($road)-1] = "=$val";
                $condition .= " AND (Drafts.ID=:{$request}{$uid}id OR Drafts.ParentID=:{$request}{$uid}pid)";
                $selectParameters[":{$request}{$uid}id"] = $val;
                $selectParameters[":{$request}{$uid}pid"] = $val;
            }
            $orConditions[] = "($condition)";
        }
    };
    $addAndCondition = function($request, $column) use(&$andConditions, &$selectParameters, &$road){
        if(isset($_REQUEST[$request])){
            $val = getValid($_REQUEST, $request);
            $uid = "_".getId()."_";
            $road[] = "$request=$val";
            $selectParameters[":{$request}{$uid}"] = $val;
            $andConditions[] = "$column=:{$request}{$uid}";
        }
    };
    $addEvaluation = function($request, $evaluation, ...$columns) use(&$andConditions, &$orConditions, &$selectParameters, &$road){
        if(isset($_REQUEST[$request])){
            $val = getValid($_REQUEST, $request);
            $road[] = "$request=$val";
            $iconditions = [];
            foreach ($columns as $column)
            {
                $req = $request.getId();
                $selectParameters[":{$req}"] = $val;
                $iconditions[] = ":{$req}{$evaluation}$column";
            }
            $andConditions[] = "(".join(" OR ", $iconditions).")";
        }
    };
    $addConditions = function($request, ...$conditions) use(&$andConditions, &$orConditions, &$selectParameters, &$road){
        if(isset($_REQUEST[$request])){
            $val = getValid($_REQUEST, $request);
            $road[] = "$request=$val";
            $andConditions[] = "(".join(" OR ", $conditions).")";
        }
    };

    $addBoxCondition("outbox", "($ifsource) AND Drafts.Status IN ('Transfer','Done','Completed')");
    $addBoxCondition("inbox", "($ifdest) AND Drafts.Status IN ('Transfer','Done','Completed')");
    $addBoxCondition("currentbox", "($ifsource OR $ifdest) AND Drafts.Status IN ('Transfer', 'Processing', 'Paused')");
    $addBoxCondition("partialbox", "($ifsource OR $ifdest) AND Drafts.Status = 'Paused'");
    $addBoxCondition("failbox", "($ifsource) AND (Drafts.Status='Swarfed' OR Drafts.Status LIKE 'Damaged%')");
    $addBoxCondition("completebox", "($ifsource) AND Drafts.Status='Completed'");
    $addBoxCondition("changebox", "($ifsource) AND Drafts.Status IN ('Lost', 'Changed')");
    $addBoxCondition("addbox", "($ifsource) AND Drafts.Status='Changed' AND (Drafts.Weight>0 OR Drafts.Count>0)");
    $addBoxCondition("subtractbox", "($ifsource) AND Drafts.Status IN ('Lost', 'Changed') AND (Drafts.Weight<0 OR Drafts.Count<0)");
    $addBoxCondition("registerbox", "($ifsource OR $ifdest) AND Drafts.Status IN ('Registered')");

    $addAndCondition("status", "Drafts.Status");
    $addAndCondition("title", "Drafts.Title");
    $addAndCondition("description", "Drafts.Description");
    $addAndCondition("product", "Products.Name");
    $addAndCondition("sourceUnit", "UserGroups.Name");
    $addAndCondition("sourcePerson", "Users.Signature");
    $addAndCondition("destUnit", "TargetUserGroups.Name");
    $addAndCondition("destPerson", "TargetUsers.Signature");

    $addEvaluation("draft", "=", "Drafts.ID", "Drafts.ParentID");
    $addEvaluation("sequence", "=", "Drafts.ID", "Drafts.ParentID");
    $addEvaluation("fromTime", "<=", "Drafts.UpdateTime", "Drafts.CreateTime");
    $addEvaluation("toTime", ">=", "Drafts.UpdateTime", "Drafts.CreateTime");
    $addEvaluation("user", "=", "Users.Signature", "TargetUsers.Signature");
    $addEvaluation("unit", "=", "UserGroups.Name", "TargetUserGroups.Name");
    $addEvaluation("person", "=", "Users.Signature", "TargetUsers.Signature");

    if(isset($_REQUEST["score"])){
        $val = getValid($_REQUEST, "score", 0);
        if($val < 0) $addConditions("score", "Drafts.Score<=0");
        elseif($val > 0) $addConditions("score", "Drafts.Score>=0");
        else $addConditions("score", "Drafts.Score=0");
    }
    if(isset($_REQUEST["count"])){
        $val = getValid($_REQUEST, "count", 0);
        if($val < 0) $addConditions("count", "Drafts.Count<=0");
        elseif($val > 0) $addConditions("count", "Drafts.Count>=0");
        else $addConditions("count", "Drafts.Count=0");
    }
    if(isset($_REQUEST["weight"])){
        $val = getValid($_REQUEST, "weight", 0);
        if($val < 0) $addConditions("weight", "Drafts.Weight<=0");
        elseif($val > 0) $addConditions("weight", "Drafts.Weight>=0");
        else $addConditions("weight", "Drafts.Weight=0");
    }
    if(isset($_REQUEST["time"])){
        $val = getValid($_REQUEST, "time", 0);
        $req1 = ":time_".getId();
        $req2 = ":time_".getId();
        $selectParameters[$req1] = $val;
        $selectParameters[$req2] = $val;
        $addConditions("time", "Drafts.Time BETWEEN $req1 * 0.25 AND $req2 * 1.25");
    }
    if(isset($_REQUEST["delay"])){
        $val = getValid($_REQUEST, "delay", 0);
        $req1 = ":delay_".getId();
        $req2 = ":delay_".getId();
        $selectParameters[$req1] = $val;
        $selectParameters[$req2] = $val;
        $addConditions("time", "Drafts.Delay BETWEEN $req1 * 0.25 AND $req2 * 1.25");
    }
    if(isset($_REQUEST["change"])){
        $val = getValid($_REQUEST, "change", 0);
        $req1 = ":change_".getId();
        $req2 = ":change_".getId();
        $selectParameters[$req1] = $val;
        $selectParameters[$req2] = $val;
        $addConditions("time", "Drafts.ChangeCount BETWEEN $req1 * 0.25 AND $req2 * 1.25");
    }

    $table = \_::$CONFIG->DataBasePrefix."Draft";
    $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
    $table2 = \_::$CONFIG->DataBasePrefix."User";
    $table3 = \_::$CONFIG->DataBasePrefix."Product";
    $conds = [];
    if(count($andConditions))
        $conds[] = join(" AND ", $andConditions);
    if(count($orConditions))
        $conds[] = join(" OR ", $orConditions);
    return between($query,"
        SELECT UserGroups.Name AS 'UnitName',
        Users.Signature AS 'Signature',
        TargetUserGroups.Name AS 'DUnitName',
        TargetUsers.Signature AS 'DSignature',
        Products.Name AS 'ProductName',
        IF($ifsource,TRUE,FALSE) AS 'IsSource',
        IF($ifdest,TRUE,FALSE) AS 'IsDestination',
        UserGroups.ID AS 'UserGroupID',
        TargetUserGroups.ID AS 'TargetUserGroupID',
        Drafts.ID AS Management,
        Drafts.ID,
        Drafts.ParentID,
        Products.Title AS 'Product',
        UserGroups.Title AS 'Source Unit',
        Users.Name AS 'Source Person',
        TargetUserGroups.Title AS 'Dest Unit',
        TargetUsers.Name AS 'Dest Person',
        Drafts.Title,
        Drafts.Description,
        Drafts.Status,
        Drafts.Image,
        Drafts.Count,
        ROUND(Drafts.Weight, ".\_::$INFO->WeightPrecision.") AS 'Weight',
        Drafts.Time,
        Drafts.Delay,
        ROUND(Drafts.Score * 100, ".\_::$INFO->DecimalPrecision.") AS 'Score',
        Drafts.ChangeCount AS 'Change Count',
        Drafts.UpdateTime,
        Drafts.CreateTime
    FROM $table AS Drafts
    ")."
    LEFT OUTER JOIN $table1 AS UserGroups ON Drafts.UserGroupID=UserGroups.ID
    LEFT OUTER JOIN $table2 AS Users ON Drafts.UserID=Users.ID
    LEFT OUTER JOIN $table1 AS TargetUserGroups ON Drafts.TargetUserGroupID=TargetUserGroups.ID
    LEFT OUTER JOIN $table2 AS TargetUsers ON Drafts.TargetUserID=TargetUsers.ID
    LEFT OUTER JOIN $table3 AS Products ON Drafts.ProductID=Products.ID
    ".(count($conds)?(" WHERE (".join(") AND (",$conds).")"):($access?"":" WHERE $ifsource OR $ifdest"));
}

function Drafts_Create_Select_Query(&$selectParameters=[], &$road=null, $columns = null, $conditions = null, $join = null){
    $access = getAccess(\_::$CONFIG->AdminAccess/2);
    $userId = \_::$INFO->User->ID;
    $groupId = \_::$INFO->User->GroupID;
    $ifsource = $access?"TRUE":"((UserGroups.ID=$groupId OR Users.ID=$userId) OR (UserGroups.ID < 1 AND Users.ID < 1))";
    $ifdest = $access?"TRUE":"((TargetUserGroups.ID=$groupId OR TargetUsers.ID=$userId) OR (TargetUserGroups.ID < 1 AND TargetUsers.ID < 1))";
    $table = \_::$CONFIG->DataBasePrefix."Draft";
    return Drafts_Create_Query("
    SELECT
        ".between($columns,"
        UserGroups.Name AS 'UnitName',
        Users.Signature AS 'Signature',
        TargetUserGroups.Name AS 'DUnitName',
        TargetUsers.Signature AS 'DSignature',
        Products.Name AS 'ProductName',
        IF($ifsource,TRUE,FALSE) AS 'IsSource',
        IF($ifdest,TRUE,FALSE) AS 'IsDestination',
        UserGroups.ID AS 'UserGroupID',
        TargetUserGroups.ID AS 'TargetUserGroupID',
        Drafts.ID AS Management,
        Drafts.ID,
        Drafts.ParentID,
        Products.Title AS 'Product',
        UserGroups.Title AS 'Source Unit',
        Users.Name AS 'Source Person',
        TargetUserGroups.Title AS 'Dest Unit',
        TargetUsers.Name AS 'Dest Person',
        Drafts.Title,
        Drafts.Description,
        Drafts.Status,
        Drafts.Image,
        Drafts.Count,
        ROUND(Drafts.Weight, ".\_::$INFO->WeightPrecision.") AS 'Weight',
        Drafts.Time,
        Drafts.Delay,
        ROUND(Drafts.Score * 100, ".\_::$INFO->DecimalPrecision.") AS 'Score',
        Drafts.ChangeCount AS 'Change Count',
        Drafts.UpdateTime,
        Drafts.CreateTime")."
    FROM $table AS Drafts
    $join", $selectParameters, $road, $conditions);
}

function Drafts_Create_Trace_Query(&$selectParameters=[], &$road=null, $columns = null, $conditions = null, $join = null){
    return Drafts_Create_Select_Query($selectParameters, $road, $columns??"
        UserGroups.Name AS 'UnitName',
        Users.Signature AS 'Signature',
        TargetUserGroups.Name AS 'DUnitName',
        TargetUsers.Signature AS 'DSignature',
        Products.Name AS 'ProductName',
        Drafts.ID,
        Drafts.ParentID,
        Users.ID AS 'UserID',
        TargetUsers.ID AS 'TargetUserID',
        UserGroups.ID AS 'UserGroupID',
        TargetUserGroups.ID AS 'TargetUserGroupID',
        Products.Title AS 'Product',
        UserGroups.Title AS 'Source Unit',
        Users.Name AS 'Source Person',
        TargetUserGroups.Title AS 'Dest Unit',
        TargetUsers.Name AS 'Dest Person',
        Drafts.Title,
        Drafts.Status,
        Drafts.Count,
        ROUND(Drafts.Weight, ".\_::$INFO->WeightPrecision.") AS 'Weight',
        Drafts.Time,
        Drafts.Delay,
        ROUND(Drafts.Score * 100, ".\_::$INFO->DecimalPrecision.") AS 'Score',
        Drafts.ChangeCount AS 'Change Count',
        Drafts.UpdateTime,
        Drafts.CreateTime", $conditions, $join);
}

function Statements_Create_Select_Query(&$selectParameters=[], &$road=null){
    $table1 = \_::$CONFIG->DataBasePrefix."Draft";
    $road = $road??[];
    $nroad = [];
    $columns =
                "UserGroups.Name AS 'UnitName',
                Users.Signature AS 'Signature',
                TargetUserGroups.Name AS 'DUnitName',
                TargetUsers.Signature AS 'DSignature',
                UserGroups.ID AS 'UserGroupID',
                TargetUserGroups.ID AS 'TargetUserGroupID',
                Products.Name AS 'ProductName',
                Drafts.ID AS Management,
                Drafts.ID,
                Drafts.ParentID,
                Products.Title AS 'Product',
                Drafts.Title,
                Drafts.Description,
                Drafts.Status,
                Drafts.Count,
                ROUND(Drafts.Weight, ".\_::$INFO->WeightPrecision.") AS 'Weight',
                Drafts.Image,
                Drafts.Time,
                Drafts.Delay,
                ROUND(Drafts.Score * 100, ".\_::$INFO->DecimalPrecision.") AS 'Score',
                Drafts.ChangeCount AS 'Change Count',
                Drafts.UpdateTime,
                Drafts.CreateTime";
    $runit = isset($_REQUEST["unit"])?$_REQUEST["unit"]:false;
    $rperson = isset($_REQUEST["person"])?$_REQUEST["person"]:false;
    if($runit!==false) $selectParameters[":Unit"] = $selectParameters[":TUnit"] = $runit;
    if($rperson!==false) $selectParameters[":Person"] = $selectParameters[":TPerson"] = $rperson;
    return Drafts_Create_Query(
            "SELECT $columns,
                IF(TargetUserGroups.Title IS NOT NULL,TargetUserGroups.Title,UserGroups.Title) AS 'Unit',
                IF(TargetUsers.Name IS NOT NULL,TargetUsers.Name,Users.Name) AS 'Person',
                NULL AS 'Credit Weight',
                ROUND(ABS(Drafts.Weight), ".\_::$INFO->WeightPrecision.") AS 'Debit Weight',
                NULL AS 'Credit Count',
                ABS(Drafts.Count) AS 'Debit Count',
                0 AS 'IsSource'
            FROM $table1 AS Drafts",
        $selectParameters, $road, "
            (
                (
                    (Drafts.TargetUserID>-1 OR Drafts.TargetUserGroupID>-1)
                    AND Drafts.Status IN ('Registered','Done','Completed','Transfer')
                ) OR (
                    Drafts.Status='Changed'
                    AND (Drafts.Weight > 0 OR Drafts.Count > 0)
                )
            )
        ".($runit===false&&$rperson===false?"":"
            AND NOT (
                Drafts.Status IN ('Registered','Done','Completed','Transfer')
                AND (".join(" OR ", [
                    ...($runit===false?[]:["UserGroups.Name=:Unit"]),
                    ...($rperson===false?[]:["Users.Signature=:Person"])
                ]).")
            )"))."
        UNION ALL
        ".Drafts_Create_Query(
            "SELECT $columns,
                UserGroups.Title AS 'Unit',
                Users.Name AS 'Person',
                ROUND(ABS(Drafts.Weight), ".\_::$INFO->WeightPrecision.") AS 'Credit Weight',
                NULL AS 'Debit Weight',
                ABS(Drafts.Count) AS 'Credit Count',
                NULL AS 'Debit Count',
                1 AS 'IsSource'
            FROM $table1 AS Drafts",
        $selectParameters, $nroad, "
            (
                (Drafts.UserID>-1 OR Drafts.UserGroupID>-1)
                AND (
                    Drafts.Status!='Changed'
                    OR (Drafts.Weight < 0 OR Drafts.Count < 0)
                )
            )".($runit===false&&$rperson===false?"":"
            AND NOT (
                Drafts.Status IN ('Registered','Done','Completed','Transfer')
                AND (".join(" OR ", [
                    ...($runit===false?[]:["TargetUserGroups.Name=:TUnit"]),
                    ...($rperson===false?[]:["TargetUsers.Signature=:TPerson"])
                ]).")
            )"));
}
?>