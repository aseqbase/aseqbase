<?php
ACCESS(\_::$CONFIG->PersonnelAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Tools Management";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(
    PART("table/tools", print:false).
    PART("report/tools", print:false));
?>