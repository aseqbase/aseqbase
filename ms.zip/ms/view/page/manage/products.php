<?php
ACCESS(\_::$CONFIG->AdminAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Products Management";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(
    PART("table/products", print:false).
    PART("report/products", print:false));
?>