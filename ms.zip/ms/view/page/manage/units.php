<?php
ACCESS(\_::$CONFIG->AdminAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Units Management";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(
    PART("table/usergroups", print:false).
    PART("report/units", print:false));
?>