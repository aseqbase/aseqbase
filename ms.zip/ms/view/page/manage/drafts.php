<?php
ACCESS(\_::$CONFIG->PersonnelAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    if(isset($_REQUEST["outbox"])) $module->Title = "Output Drafts";
    elseif(isset($_REQUEST["inbox"])) $module->Title = "Input Drafts";
    elseif(isset($_REQUEST["currentbox"])) $module->Title = "Current Drafts";
    elseif(isset($_REQUEST["changebox"])) $module->Title = "Changed Drafts";
    elseif(isset($_REQUEST["addbox"])) $module->Title = "Added Drafts";
    elseif(isset($_REQUEST["subtractbox"])) $module->Title = "Subtracted Drafts";
    elseif(isset($_REQUEST["failbox"])) $module->Title = "Failed Drafts";
    elseif(isset($_REQUEST["partialbox"])) $module->Title = "Partial Drafts";
    elseif(isset($_REQUEST["completebox"])) $module->Title = "Completed Drafts";
    elseif(isset($_REQUEST["registerbox"])) $module->Title = "Registered Drafts";
    else $module->Title = "Drafts Management";
    $module->Draw();
    MODULE("PeriodPicker");
    (new MiMFa\Module\PeriodPicker(true, \_::$INFO->DefaultFromTime, \_::$INFO->DefaultToTime))->Draw();
}
echo \MiMFa\Library\HTML::Page(
    PART("table/drafts", print:false).
    PART("report/drafts", print:false));
?>