<?php
ACCESS(\_::$CONFIG->AdminAccess);
MODULE("PrePage");
$module = new MiMFa\Module\PrePage();
$module->Title = "View";
$module->Draw();
MODULE("Collection");
$module = new MiMFa\Module\Collection();
$module->MoreButtonLabel = "See this View";
$module->Items = getValid(getValid(\_::$INFO->MainMenus, "View"),"Items");
$module->Draw();
?>