<?php
ACCESS(\_::$CONFIG->AdminAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Tools Report";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(PART("report/tools", print:false));
?>