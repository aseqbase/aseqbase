<?php
use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
$path = \_::$PAGE;
TEMPLATE("Main");
$templ = new \MiMFa\Template\Main();
if(!isValid($path))
    $templ->Content = function(){
        PAGE("home");
    };
else
    $templ->Content = function() use($path){
        ACCESS(\_::$CONFIG->UserAccess);
        MODULE("Table");
        $mod = new Table(\_::$CONFIG->DataBasePrefix."Draft");
        $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
        $table2 = \_::$CONFIG->DataBasePrefix."User";
        $table3 = \_::$CONFIG->DataBasePrefix."Product";
        $access = getAccess($mod->UpdateAccess = \_::$CONFIG->AdminAccess);
        $userId = \_::$INFO->User->ID;
        $groupId = \_::$INFO->User->GroupID;
        $ifsource = $access?"TRUE":"B.ID=$groupId OR C.ID=$userId";
        $ifdest = $access?"TRUE":"D.ID=$groupId OR E.ID=$userId";
        $mod->SelectQuery = "
            SELECT
                B.Name As 'UnitName',
                C.Signature As 'Signature',
                D.Name As 'DUnitName',
                E.Signature As 'DSignature',
                F.Name As 'ProductName',
                A.{$mod->KeyColumn},
                F.Name AS 'Product',
                B.Title AS 'Source Unit',
                C.Name AS 'Source Person',
                D.Title AS 'Destination Unit',
                E.Name AS 'Destination Person',
                A.Title,
                A.Description,
                A.Status,
                A.Image,
                A.Count,
                A.Weight,
                A.Time,
                A.UpdateTime,
                A.CreateTime
            FROM {$mod->Table} AS A
            LEFT OUTER JOIN $table1 AS B ON A.UserGroupID=B.ID
            LEFT OUTER JOIN $table2 AS C ON A.UserID=C.ID
            LEFT OUTER JOIN $table1 AS D ON A.TargetUserGroupID=D.ID
            LEFT OUTER JOIN $table2 AS E ON A.TargetUserID=E.ID
            LEFT OUTER JOIN $table3 AS F ON A.ProductID=F.ID
            ".($access?";":" WHERE $ifsource OR $ifdest");
        $mod->Updatable = false;
        $mod->AddAccess = 100;
        $mod->RemoveAccess = \_::$CONFIG->SuperAccess;
        $mod->ModifyAccess = \_::$CONFIG->PersonnelAccess;

        $users = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
        $usergroups = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title");
        $mod->ColumnsTypes = [
            "ID"=>false,
            "AuthorID"=>$access?function($t, $v) use($users){
                $std = new stdClass();
                $std->Title = "Author";
                $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
                $std->Options = $users;
                return $std;
            }:false,
            "EditorID"=>$access?function($t, $v) use($users){
                $std = new stdClass();
                $std->Title = "Editor";
                $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
                $std->Options = $users;
                return $std;
            }:false,
            "ProductID" => $access? function(){
                $std = new stdClass();
                $std->Title = "Product";
                $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
                $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."Product", "ID", "Title");
                return $std;
            }:false,
            "ToolIDs" => function($t, $v){
                $std = new stdClass();
                $std->Title="Used Tools";
                $std->Type="array";
                $std->Options = [
                    "add"=>false, "remove"=>false, "edit"=>false,
                    "type"=>"select", "key"=>"ToolIDs",
                    "options"=> DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."Tool", "ID", "Title")
                ];
                return $std;
            },
            "UserGroupID" =>function() use($usergroups){
                $std = new stdClass();
                $std->Title = "Source Unit";
                $std->Type = "select";
                $std->Options = $usergroups;
                return $std;
            },
            "UserID" => function() use($users){
                $std = new stdClass();
                $std->Title = "Source Person";
                $std->Type = "select";
                $std->Options = $users;
                return $std;
            },
            "TargetUserGroupID" => function()use($usergroups){
                $std = new stdClass();
                $std->Title = "Destination Unit";
                $std->Type = "select";
                $std->Options = $usergroups;
                return $std;
            },
            "TargetUserID" => function() use($users){
                $std = new stdClass();
                $std->Title = "Destination Person";
                $std->Type = "select";
                $std->Options = $users;
                return $std;
            },
            "Status"=> function() {
                $std = new stdClass();
                $std->Type = "select";
                $std->Options = ['Input'=>'Input', 'Processing'=>'Processing', 'Output'=>'Output',
                'Added'=>'Added','Subtracted'=>'Subtracted', 'Done'=>'Done','Damaged'=>'Damaged',
                'DamagedByUnit'=>'DamagedByUnit', 'DamagedByPerson'=>'DamagedByPerson','DamagedByProduct'=>'DamagedByProduct','DamagedByTool'=>'DamagedByTool','Lost'=>'Lost', 'Completed'=>'Completed'];
                return $std;
            },
            "Title"=> false,
            "Image"=>false,
            "Description"=>false,
            "Count"=> function(){
                $std = new stdClass();
                $std->Title = "Numbers (".\_::$INFO->CountUnit.")";
                return $std;
            },
            "Weight"=> function(){
                $std = new stdClass();
                $std->Title = "Weight (".\_::$INFO->WeightUnit.")";
                return $std;
            },
            "Time"=> function(){
                $std = new stdClass();
                $std->Title = "Time (".\_::$INFO->TimeUnit.")";
                return $std;
            },
            "MetaData"=> $access?"json":$access,
            "CreateTime"=>"disabled",
            "UpdateTime"=>"disabled"
        ];
        echo $mod->DoAction($path);
    };
$templ->Draw();
?>