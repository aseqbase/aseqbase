<?php
use MiMFa\Library\DataBase;
use MiMFa\Module\Form;
$path = \_::$PAGE;
TEMPLATE("Main");
$templ = new \MiMFa\Template\Main();
if(!isValid($path))
    $templ->Content = function(){
        PAGE("home");
    };
else
    $templ->Content = function()use($path){
        ACCESS(\_::$CONFIG->UserAccess);
        MODULE("Form");
        $record = DataBase::DoSelectRow(\_::$CONFIG->DataBasePrefix."Draft", "*", "ID=:ID",[":ID"=>$path]);
        if(isEmpty($record)) return null;
        $mod = new Form(
            title:$record["Title"],
            description:$record["Description"],
            image:$record["Image"],
            children:$record,
            method:null
            );
        $mod->Template = 't';
        $userId = \_::$INFO->User->ID;
        $groupId = \_::$INFO->User->GroupID;
        $access = getAccess($mod->UpdateAccess = \_::$CONFIG->AdminAccess);
        $users = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
        $usergroups = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title");
        $mod->FieldsTypes = [
            "ParentID" => function($t, $v){
                $std = new stdClass();
                $std->Title = "Parent";
                $std->Description = "The parent Draft which is related";
                $std->Type =  isValid($v)?"link":false;
                $std->Value =  "/drafts/$v";
                return $std;
            },
            "ID"=>"number",
            "ProductID" => function(){
                $std = new stdClass();
                $std->Title = "Product";
                $std->Description = "The target Product to Process";
                $std->Type = "select";
                $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."Product", "ID", "Title");
                return $std;
            },
            "Count"=> function($t, $v){
                $std = new stdClass();
                $std->Title = "Numbers ('".\_::$INFO->CountUnit."')";
                $std->Type = "int";
                $std->Description = "Numbers of this Work Pieces ('".\_::$INFO->CountUnit."')";
                return $std;
            },
            "Weight"=> function(){
                $std = new stdClass();
                $std->Title = "Weight ('".\_::$INFO->WeightUnit."')";
                $std->Type = "float";
                $std->Description = "Weight of this Work ('".\_::$INFO->WeightUnit."')";
                $std->Attributes = ["step"=>"".(1/pow(10,\_::$INFO->WeightPrecision))];
                return $std;
            },
            "UserGroupID" => function($t, $v) use($usergroups){
                $std = new stdClass();
                $std->Title = "Source Unit";
                $std->Description = "Responsible Unit";
                $std->Type = getAccess(\_::$CONFIG->AdminAccess)?"select":"hidden";
                $std->Options = $usergroups;
                return $std;
            },
            "UserID" => function($t, $v) use($users){
                $std = new stdClass();
                $std->Title = "Source Person";
                $std->Description = "Responsible Person";
                $std->Type = getAccess(\_::$CONFIG->AdminAccess)?"select":"hidden";
                $std->Options = $users;
                return $std;
            },
            "TargetUserGroupID" =>function($t, $v) use($groupId,$usergroups){
                $std = new stdClass();
                $std->Title = "Dest Unit";
                $std->Description = "Target Unit Output";
                $std->Type = "select";
                $val = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."UserGroup", "TargetIDs", "`ID`=:ID",[":ID"=>$groupId]);
                $val = isEmpty($val)?$usergroups:json_decode($val);
                $std->Options = array_filter($usergroups, function($v,$k)use($val){ return in_array($k, $val);},ARRAY_FILTER_USE_BOTH);
                return $std;
            },
            "TargetUserID" => function($t, $v) use($groupId){
                $std = new stdClass();
                $std->Title = "Dest Person";
                $std->Description = "Target Person Output";
                $std->Type = "select";
                $val = DataBase::DoSelectValue(\_::$CONFIG->DataBasePrefix."UserGroup", "TargetIDs", "`ID`=:ID",[":ID"=>$groupId]);
                $val = isEmpty($val)?null:"GroupID IN (".join(", ", json_decode($val)).")";
                $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name", $val);
                return $std;
            },
            "Status"=> function(){
                $std = new stdClass();
                $std->Type = "select";
                $std->Options = ['Transfer'=>'Transfer', 'Processing'=>'Processing', 'Paused'=>'Paused',
                'Changed'=>'Changed', 'Done'=>'Done', 'Swarfed'=>'Swarfed', 'Damaged'=>'Damaged',
                'DamagedByUnit'=>'DamagedByUnit', 'DamagedByPerson'=>'DamagedByPerson','DamagedByProduct'=>'DamagedByProduct','DamagedByTool'=>'DamagedByTool','Lost'=>'Lost', 'Completed'=>'Completed'];
                return $std;
            },
            "Time"=> $access? function(){
                $std = new stdClass();
                $std->Title = "Time ('".\_::$INFO->TimeUnit."')";
                $std->Description = "Elapsed Time for this Work ('".\_::$INFO->TimeUnit."')";
                return $std;
            }:false,
            "Delay"=> $access? function(){
                $std = new stdClass();
                $std->Title = "Delay ('".\_::$INFO->TimeUnit."')";
                $std->Description = "Elapsed Delay for this Work ('".\_::$INFO->TimeUnit."')";
                return $std;
            }:false,
            "Score"=> $access?function(){
                $std = new stdClass();
                $std->Type = "float";
                $std->Attributes = ["min"=>0,"max"=>5];
                return $std;
            }:false,
            "ToolIDs" => $access? function($t, $v)use($access, $record){
                $std = new stdClass();
                $std->Title="Used Tools";
                $std->Description="Indicate all used Tools for this Draft";
                $std->Type = getValid($record,"Status")=="Processing"?"array":($access?"array":false);
                $std->Options = [
                    "type"=>"select", "key"=>"ToolIDs",
                    "options"=> DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."Tool", "ID", "Title")
                ];
                return $std;
            }:false,
            "ChangeCount"=> $access,
            "AuthorID"=>$access?function($t, $v) use($users){
                $std = new stdClass();
                $std->Title = "Author";
                $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
                $std->Options = $users;
                return $std;
            }:false,
            "EditorID"=>$access?function($t, $v) use($users){
                $std = new stdClass();
                $std->Title = "Editor";
                $std->Type = getAccess(\_::$CONFIG->SuperAccess)?"select":"hidden";
                $std->Options = $users;
                return $std;
            }:false,
            "MetaData"=> $access?function(){
                $std = new stdClass();
                $std->Type = "json";
                return $std;
            }:false,
            "UpdateTime"=> "calendar",
            "CreateTime"=> "calendar"
        ];
        return MiMFa\Library\HTML::Container($mod->Capture());
    };
$templ->Draw();
?>