<?php
use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
$path = \_::$PAGE;
TEMPLATE("Main");
$templ = new \MiMFa\Template\Main();
if(!isValid($path))
    $templ->Content = function(){
        PAGE("home");
    };
else
    $templ->Content = function() use($path){
        ACCESS(\_::$CONFIG->UserAccess);
        MODULE("Table");
        $mod = new Table(\_::$CONFIG->DataBasePrefix."UserGroup");
        $table1 = \_::$CONFIG->DataBasePrefix."User";
        $mod->KeyColumn = "Name";
        $mod->SelectQuery = "
            SELECT A.{$mod->KeyColumn}, A.Name AS 'UnitName', A.Title, A.Description, A.Access, COUNT(B.ID) AS 'Users'
            FROM $table1 AS B
            RIGHT OUTER JOIN {$mod->Table} AS A
            ON A.ID=B.GroupID
            GROUP BY A.ID
        ";
        $mod->Updatable = false;
        $access = getAccess($mod->UpdateAccess = \_::$CONFIG->AdminAccess);
        $mod->ColumnsTypes = [
            "ID"=>false,
            "Title"=> false,
            "Image"=>false,
            "Description"=>false,
            "Status"=>$access,
            "Path"=>$access,
            "TargetIDs"=>$access?function($t, $v){
                $std = new stdClass();
                $std->Title="Destination Units";
                $std->Type="array";
                $std->Options = ["add"=>false, "remove"=>false, "edit"=>false,"type"=>"select", "key"=>"TargetIDs", "options"=> DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title")];
                return $std;
            }:$access,
            "Access"=>function(){
                $std = new stdClass();
                $std->Type="number";
                $std->Attributes=["min"=>\_::$CONFIG->BanAccess,"max"=>\_::$CONFIG->UserAccess];
                return $std;
            },
            "MetaData"=> $access?"json":$access,
            "CreateTime"=>$access,
            "UpdateTime"=>$access
        ];
        echo $mod->DoAction($path);
    };
$templ->Draw();
?>