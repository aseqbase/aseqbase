<?php
RUN("MSTemplate");
class Template extends MSTemplate{
	public $ForeColorPalette = array("#252525", "#151515","#209980");
	public $BackColorPalette = array("#fefefe","#fbfbfb","#fcfcfc");
	public $FontPalette = array("'b yekan', 'dubai', 'tahoma', sans-serif");
	public $SizePalette = array("12pt","15pt","19pt","25pt","32pt","40pt","50pt");
    public $ShadowPalette = array("none","4px 7px 20px #00000005","4px 7px 20px #00000015","4px 7px 20px #00000025","5px 10px 25px #00000030","0px 0px 20px #00000030","0px 0px 20px #00000050");
}
?>