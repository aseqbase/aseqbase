<?php
if(RECEIVE(null,"post") || RECEIVE(\_::$CONFIG->ViewHandlerKey)) return;
ACCESS(\_::$CONFIG->AdminAccess);
PART("report/drafts");
PART("report/units");
PART("report/users");
PART("report/goods");
PART("report/vocations");
?>