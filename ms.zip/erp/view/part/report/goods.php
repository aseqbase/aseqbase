<?php
if(RECEIVE(null,"post") || RECEIVE(\_::$CONFIG->ViewHandlerKey)) return;
ACCESS(\_::$CONFIG->AdminAccess);
?>