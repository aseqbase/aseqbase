<?php
use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
$path = \_::$PAGE;
TEMPLATE("Main");
$templ = new \MiMFa\Template\Main();
if(!isValid($path))
    $templ->Content = function(){
        PAGE("home");
    };
else
    $templ->Content = function() use($path){
        ACCESS(\_::$CONFIG->UserAccess);
        MODULE("Table");
        $mod = new Table(\_::$CONFIG->DataBasePrefix."Tool");
        $mod->KeyColumn = "Name";
        $table1 = \_::$CONFIG->DataBasePrefix."UserGroup";
        $table2 = \_::$CONFIG->DataBasePrefix."User";
        $mod->SelectQuery = "
            SELECT A.Name As 'ToolName', B.Name As 'UnitName', C.Signature As 'Signature', A.{$mod->KeyColumn}, B.Title AS 'Unit', C.Name AS 'Person', A.Image, A.Title, A.Description,
                LEAST(0,(100 * A.UsedWorkCount) / A.UsageWorkCount) AS 'Used Count (%)',
                LEAST(0,(100 * A.UsedWorkWeight) / A.UsageWorkWeight) AS 'Used Weight (%)',
                LEAST(0,(100 * A.UsedWorkTime) / A.UsageWorkTime) AS 'Used Time (%)',
                A.UpdateTime
            FROM {$mod->Table} AS A
            LEFT OUTER JOIN $table1 AS B ON A.UserGroupID=B.ID
            LEFT OUTER JOIN $table2 AS C ON A.UserID=C.ID
        ";
        $mod->Updatable = false;
        $access = getAccess($mod->UpdateAccess = \_::$CONFIG->AdminAccess);
        $users =  DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
        $mod->ColumnsTypes = [
            "AuthorID"=>$access?function($t, $v) use($users){
                $std = new stdClass();
                $std->Title = "Author";
                $std->Type = "select";
                $std->Options = $users;
                return $std;
            }:false,
            "EditorID"=>$access?function($t, $v) use($users){
                $std = new stdClass();
                $std->Title = "Editor";
                $std->Type = "select";
                $std->Options = $users;
                return $std;
            }:false,
            "ID"=>false,
            "TagIDs"=>false,
            "Title"=> false,
            "Image"=>false,
            "Description"=>false,
            "UserGroupID" => function(){
                $std = new stdClass();
                $std->Title = "Responsible Unit";
                $std->Type = "select";
                $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."UserGroup", "ID", "Title");
                return $std;
            },
            "UserID" => function(){
                $std = new stdClass();
                $std->Title = "Responsible Person";
                $std->Type = "select";
                $std->Options = DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
                return $std;
            },
            "Status"=>$access,
            "Content"=>"div",
            "Count"=> function(){
                $std = new stdClass();
                $std->Title = "Numbers (".\_::$INFO->CountUnit.")";
                return $std;
            },
            "UsageWorkCount"=> function(){
                $std = new stdClass();
                $std->Title = "Numbers of Works (".\_::$INFO->CountUnit.")";
                return $std;
            },
            "UsedWorkCount"=> $access?function(){
                $std = new stdClass();
                $std->Title = "Numbers of Used (".\_::$INFO->CountUnit.")";
                return $std;
            }:$access,
            "Weight"=> function(){
                $std = new stdClass();
                $std->Title = "Weight (".\_::$INFO->WeightUnit.")";
                return $std;
            },
            "UsageWorkWeight"=> function(){
                $std = new stdClass();
                $std->Title = "Weight of Works (".\_::$INFO->WeightUnit.")";
                return $std;
            },
            "UsedWorkWeight"=> $access?function(){
                $std = new stdClass();
                $std->Title = "Weight of Used (".\_::$INFO->WeightUnit.")";
                return $std;
            }:$access,
            "Time"=> function(){
                $std = new stdClass();
                $std->Title = "Time (".\_::$INFO->TimeUnit.")";
                return $std;
            },
            "UsageWorkTime"=> function(){
                $std = new stdClass();
                $std->Title = "Time of Works (".\_::$INFO->TimeUnit.")";
                return $std;
            },
            "UsedWorkTime"=> $access?function(){
                $std = new stdClass();
                $std->Title = "Time of Used (".\_::$INFO->TimeUnit.")";
                return $std;
            }:$access,
            "MetaData"=> $access?"json":$access
        ];
        echo $mod->DoAction($path);
    };
$templ->Draw();
?>