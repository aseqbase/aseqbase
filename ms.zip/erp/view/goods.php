<?php
use MiMFa\Module\Table;
use MiMFa\Library\DataBase;
$path = \_::$PAGE;
TEMPLATE("Main");
$templ = new \MiMFa\Template\Main();
if(!isValid($path))
    $templ->Content = function(){
        PAGE("home");
    };
else
    $templ->Content = function() use($path){
        ACCESS(\_::$CONFIG->UserAccess);
        MODULE("Table");
        $mod = new Table(\_::$CONFIG->DataBasePrefix."Product");
        $mod->KeyColumn = "Name";
        $table1 = \_::$CONFIG->DataBasePrefix."User";
        $mod->SelectQuery = "
            SELECT A.{$mod->KeyColumn}, B.Signature, B.Name AS 'Author', A.Name AS 'ProductName', A.Image, A.Title, A.Description, A.UpdateTime
            FROM {$mod->Table} AS A
            LEFT OUTER JOIN $table1 AS B ON A.AuthorID=B.ID;
        ";
        $mod->Updatable = false;
        $access = getAccess($mod->UpdateAccess = \_::$CONFIG->AdminAccess);
        $users =  DataBase::DoSelectPairs(\_::$CONFIG->DataBasePrefix."User", "ID", "Name");
        $mod->CellsTypes = [
            "AuthorID"=>$access?function($t, $v) use($users){
                $std = new stdClass();
                $std->Title = "Author";
                $std->Type = "select";
                $std->Options = $users;
                return $std;
            }:false,
            "ID"=>false,
            "TagIDs"=>false,
            "Title"=> false,
            "Image"=>false,
            "Description"=>false,
            "Status"=>$access,
            "Path"=>$access,
            "Access"=>$access,
            "Content"=>"div",
            "MetaData"=> $access?"json":$access
        ];
        echo $mod->DoAction($path);
    };
$templ->Draw();
?>