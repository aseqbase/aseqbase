﻿<?php
ACCESS(\_::$CONFIG->AdminAccess);
MODULE("PrePage");
$module = new MiMFa\Module\PrePage();
$module->Title = "Tutorial";
$module->Draw();
MODULE("Collection");
$embed = function($title, $desc, $name){
    $id = getId()."";
    return [
            "Title"=>$title,
            "Description"=>$desc,
            "Content"=>"<div id='".$id."'>
                <script type='text/JavaScript'
                    src='https://www.aparat.com/embed/".$name."?data[rnddiv]=".$id."&data[responsive]=yes'>
                </script>
            </div>"
        ];
};

$module = new MiMFa\Module\Collection();
$module->MoreButtonLabel = "Show";
$module->Items = function() use($embed){
    yield $embed(
            "نحوه استفاده روتین از سامانه",
            "معرفی امکانات اصلی موردنیاز برای استفاده روتین و روزمره از نسخه 1 سامانه برخط(آنلاین) مدیریت کارگاه‌های طلاسازی میم‌فا جی‌ام‌اس",
            "K6mJu"
        );
    yield $embed(
            "معرفی کلیه امکانات سامانه",
            "معرفی کلیه امکانات اولین نسخه سامانه برخط(آنلاین) مدیریت کارگاه‌های طلاسازی میم‌فا جی‌ام‌اس",
            "NmUF9"
        );
};
$module->Draw();
?>