<?php
ACCESS(\_::$CONFIG->AdminAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Edit Vocations";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(PART("table/vocations", print:false));
?>