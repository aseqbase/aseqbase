<?php
ACCESS(\_::$CONFIG->AdminAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Edit Goods";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(PART("table/goods", print:false));
?>