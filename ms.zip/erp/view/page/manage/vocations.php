<?php
ACCESS(\_::$CONFIG->PersonnelAccess);
if(!RECEIVE(null,"post")){
    MODULE("PrePage");
    $module = new MiMFa\Module\PrePage();
    $module->Title = "Vocations Management";
    $module->Draw();
}
echo \MiMFa\Library\HTML::Page(
    PART("table/vocations", print:false).
    PART("report/vocations", print:false));
?>