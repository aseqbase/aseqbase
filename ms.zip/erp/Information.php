<?php
RUN("MSInformation");
class Information extends MSInformation{
	public $Product = "ERP";
	public $FullProduct = "MiMFa Enterprise Resource Planning";
	public $Name = "ERP";
	public $FullName = "MiMFa Enterprise Resource Planning";
	public $Slogan = "A Special Integrated Resources Management System";
	public $FullDescription = "to manage day-to-day business activities such as accounting, procurement, project management, risk management and compliance, and supply chain operations.";


	/**
     * @internal
     */
	public $MainMenus = array(
		array("Name"=>"HOME","Path"=>"/home","Image"=>"/file/symbol/home.png"),
		array("Name"=>"INBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?inbox", "Image"=>"/file/symbol/input.png"),
		array("Name"=>"CURRENTBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?currentbox", "Image"=>"/file/symbol/process.png"),
		array("Name"=>"OUTBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?outbox", "Image"=>"/file/symbol/output.png"),
		"View"=>array("Name"=>"VIEW","Access"=>10,"Path"=>"/view","Image"=>"/file/symbol/achievement.png", "Items"=> array(
				"Statements"=>array("Name"=>"STATEMENTS","Access"=>10,"Path"=>"/view/statements","Image"=>"/file/symbol/operation.png"),
				"Trace"=>array("Name"=>"TRACE","Access"=>10,"Path"=>"/view/trace","Image"=>"/file/symbol/trace.png"),
				"Status"=>array("Name"=>"STATUS","Access"=>10,"Path"=>"/view/status","Image"=>"/file/symbol/status.png")
			)
		),
		"Edit"=>array("Name"=>"EDIT","Access"=>10,"Path"=>"/edit","Image"=>"/file/symbol/edit.png", "Items"=> array(
		    	array("Name"=>"SYSTEM","Access"=>10,"Path"=>"/edit/system","Image"=>"/file/symbol/factory.png"),
		    	array("Name"=>"UNITS","Access"=>10,"Path"=>"/edit/units","Image"=>"/file/symbol/factory-unit.png"),
		    	array("Name"=>"PERSONNEL","Access"=>10,"Path"=>"/edit/users","Image"=>"/file/symbol/factory-worker.png"),
		    	array("Name"=>"GOODS","Access"=>10,"Path"=>"/edit/goods","Image"=>"/file/symbol/product.png"),
		    	array("Name"=>"VOCATIONS","Access"=>10,"Path"=>"/edit/vocations","Image"=>"/file/symbol/tool.png"),
		    	array("Name"=>"DRAFTS","Access"=>10,"Path"=>"/edit/drafts","Image"=>"/file/symbol/operation.png")
		    )),
		"Report"=>array("Name"=>"REPORT","Access"=>10,"Path"=>"/report","Image"=>"/file/symbol/analyze.png", "Items"=> array(
		    	array("Name"=>"SYSTEM","Access"=>10,"Path"=>"/report/system","Image"=>"/file/symbol/factory.png"),
		    	array("Name"=>"UNITS","Access"=>10,"Path"=>"/report/units","Image"=>"/file/symbol/factory-unit.png"),
		    	array("Name"=>"PERSONNEL","Access"=>10,"Path"=>"/report/users","Image"=>"/file/symbol/factory-worker.png"),
		    	//array("Name"=>"VOCATIONS","Access"=>10,"Path"=>"/report/vocations","Image"=>"/file/symbol/product.png"),
		    	array("Name"=>"TOOLS","Access"=>10,"Path"=>"/report/tools","Image"=>"/file/symbol/tool.png"),
		    	array("Name"=>"DRAFTS","Access"=>10,"Path"=>"/report/drafts","Image"=>"/file/symbol/operation.png")
		    )),
		"Draft"=>array("Name"=>"DRAFT","Access"=>1000000,"Path"=>"/manage/drafts","Image"=>"/file/symbol/operation.png", "Items"=> array(
				array("Name"=>"INBOX","Access"=>1000000,"Path"=>"/manage/drafts?inbox", "Image"=>"/file/symbol/input.png"),
				array("Name"=>"CURRENTBOX","Access"=>1000000,"Path"=>"/manage/drafts?currentbox", "Image"=>"/file/symbol/process.png"),
				array("Name"=>"OUTBOX","Access"=>1000000,"Path"=>"/manage/drafts?outbox", "Image"=>"/file/symbol/output.png"),
				array("Name"=>"ADDBOX","Access"=>1000000,"Path"=>"/manage/drafts?addbox", "Image"=>"/file/symbol/greenflag.png"),
				array("Name"=>"SUBTRACTBOX","Access"=>1000000,"Path"=>"/manage/drafts?subtractbox", "Image"=>"/file/symbol/redflag.png"),
				array("Name"=>"FAILBOX","Access"=>1000000,"Path"=>"/manage/drafts?failbox", "Image"=>"/file/symbol/failure.png"),
				array("Name"=>"PARTIALBOX","Access"=>1000000,"Path"=>"/manage/drafts?partialbox", "Image"=>"/file/symbol/partial-process.png"),
				array("Name"=>"COMPLETEBOX","Access"=>1000000,"Path"=>"/manage/drafts?completebox", "Image"=>"/file/symbol/tick.png")
		    )),
		array("Name"=>"ABOUT","Path"=>"/about","Image"=>"/file/symbol/info.png"),
		array("Name"=>"TUTORIAL","Path"=>"/tutorial","Image"=>"/file/symbol/guide.png")
		);

	/**
     * @internal
     */
	public $Services = array(
		array("Name"=>"INBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?inbox", "Image"=>"/file/symbol/input.png"),
		array("Name"=>"OUTBOX","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts?outbox", "Image"=>"/file/symbol/output.png"),
		array("Name"=>"DRAFTS","Access"=>["min"=>11,"max"=>1000000],"Path"=>"/edit/drafts","Image"=>"/file/symbol/operation.png"),
		array("Name"=>"TRACE","Access"=>10,"Path"=>"/report/trace","Image"=>"/file/symbol/trace.png"),
		array("Name"=>"STATUS","Access"=>10,"Path"=>"/report/status", "Image"=>"/file/symbol/status.png"),
		array("Name"=>"SYSTEM","Access"=>10,"Path"=>"/report/system","Image"=>"/file/symbol/factory.png"),
		array("Name"=>"UNITS","Access"=>10,"Path"=>"/report/units","Image"=>"/file/symbol/factory-unit.png"),
		array("Name"=>"PERSONNEL","Access"=>10,"Path"=>"/report/users","Image"=>"/file/symbol/factory-worker.png"),
		array("Name"=>"GOODS","Access"=>10,"Path"=>"/report/goods","Image"=>"/file/symbol/product.png"),
		array("Name"=>"VOCATIONS","Access"=>10,"Path"=>"/report/vocations","Image"=>"/file/symbol/tool.png"),
		array("Name"=>"DRAFTS","Access"=>10,"Path"=>"/report/drafts","Image"=>"/file/symbol/operation.png")
	);
}
?>
